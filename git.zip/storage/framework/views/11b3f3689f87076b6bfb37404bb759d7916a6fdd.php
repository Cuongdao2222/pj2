<?php $__env->startSection('content'); ?>
    <?php  

        $groupProduct = $_GET['groupid'];
       

    ?>

    <style type="text/css">
        
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }

        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }

        tr:nth-child(even) {
          background-color: #dddddd;
        }
    </style>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-12">
                    <h1>Tạo thuộc tính</h1>
                </div>
            </div>
        </div>
    </section>

    <div class="content px-3">

        <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card">

            <?php echo Form::open(['route' => 'filters.store']); ?>


            <input type="hidden" name="group_product_id" value="<?php echo e($_GET['groupid']); ?>">

           

            <div class="card-body">

                <div class="row">
                    <?php echo $__env->make('filters.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>

            <div class="card-footer">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                <a href="<?php echo e(route('groupProducts.index')); ?>" class="btn btn-default">Cancel</a>
            </div>

            <?php echo Form::close(); ?>


        </div>
    </div>

    <h2>Danh sách thuộc tính của nhóm</h2>

    <table>
        <tr>
            <th>Danh sách</th>
            <th>Sửa</th>
            <th>Xóa</th>
        </tr>
        <?php  

            $list = App\Models\filter::where('group_product_id', $groupProduct)->get();
        ?>

        <?php if(isset($list)): ?>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($value->name); ?></td>
            
            <td><a href="<?php echo e(route('filters.edit', [$value->id])); ?>">Sửa</a></td>
            <td>
                <?php echo Form::open(['route' => ['filters.destroy', $value->id], 'method' => 'delete']); ?>

                       
                    <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                
                <?php echo Form::close(); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
       
    </table>

    <h2>Danh sách thuộc tính con của nhóm</h2>
    <a href="<?php echo e(route('filter-property')); ?>?group-product=<?php echo e($groupProduct); ?>&productId=0">xem thuộc tính</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dpwchzpd/public_html/resources/views/filters/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <?php if(isset($product->Meta_id )): ?>

     <?php  

        $products_seo = App\Models\product::select('Meta_id')->where('id',  $product->Meta_id)->first();

        print_r($product->Meta_id);


    ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-12">
                    <h1>Edit Product</h1>
                </div>
            </div>
        </div>
    </section>

    <div class="btn btn-warning"><a href="<?php echo e(route('metaSeos.edit', 1)); ?>"></a>Seo</div>
    <div class="btn btn-warning"><a href="#mo-ta"></a>Mô tả</div>
    <div class="btn btn-warning" >Thông số</div>
    <div class="btn btn-warning">Ảnh</div>


    
     <?php if(!empty($products_seo)): ?>
    <div class="btn btn-info seo-click"> Dùng cho SEO </div>


   
   
     

   
    <div class="content px-3">

        <?php $metaSeo = App\Models\metaSeo::find($products_seo->Meta_id); ?>

        <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card seo">

            <?php echo Form::model($metaSeo, ['route' => ['metaSeos.update', $metaSeo->id], 'method' => 'patch']); ?>


            <div class="card-body">
                <div class="row">
                    <?php echo $__env->make('meta_seos.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="card-footer">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                <a href="<?php echo e(route('metaSeos.index')); ?>" class="btn btn-default">Cancel</a>
            </div>

            <?php echo Form::close(); ?>


        </div>
    </div>
    <?php endif; ?>

    <?php endif; ?>

    <div class="content px-3">

        <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card">

            <?php echo Form::model($product, ['route' => ['products.update', $product->id], 'method' => 'patch', 'files' => true]); ?>


           

            <div class="card-body">
                <div class="row">
                    <?php echo $__env->make('products.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="card-footer">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-default">Cancel</a>
            </div>

            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dpwchzpd/public_html/resources/views/products/edit.blade.php ENDPATH**/ ?>
<!-- Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($product->id); ?></p>
</div>

<!-- Image Field -->
<div class="col-sm-12">
    <?php echo Form::label('Image', 'Image:'); ?>

    <p><?php echo e($product->Image); ?></p>
</div>

<!-- Product Field -->
<div class="col-sm-12">
    <?php echo Form::label('Product', 'Product:'); ?>

    <p><?php echo e($product->Product); ?></p>
</div>

<!-- Productsku Field -->
<div class="col-sm-12">
    <?php echo Form::label('ProductSku', 'Productsku:'); ?>

    <p><?php echo e($product->ProductSku); ?></p>
</div>

<!-- Link Field -->
<div class="col-sm-12">
    <?php echo Form::label('Link', 'Link:'); ?>

    <p><?php echo e($product->Link); ?></p>
</div>

<!-- Detail Field -->
<div class="col-sm-12">
    <?php echo Form::label('Detail', 'Detail:'); ?>

    <p><?php echo e($product->Detail); ?></p>
</div>

<!-- Salient Features Field -->
<div class="col-sm-12">
    <?php echo Form::label('Salient_Features', 'Salient Features:'); ?>

    <p><?php echo e($product->Salient_Features); ?></p>
</div>

<!-- Specifications Field -->
<div class="col-sm-12">
    <?php echo Form::label('Specifications', 'Specifications:'); ?>

    <p><?php echo e($product->Specifications); ?></p>
</div>

<!-- Quantily Field -->
<div class="col-sm-12">
    <?php echo Form::label('Quantily', 'Quantily:'); ?>

    <p><?php echo e($product->Quantily); ?></p>
</div>

<!-- Maker Field -->
<div class="col-sm-12">
    <?php echo Form::label('Maker', 'Maker:'); ?>

    <p><?php echo e($product->Maker); ?></p>
</div>

<!-- Group Field -->
<div class="col-sm-12">
    <?php echo Form::label('Group', 'Group:'); ?>

    <p><?php echo e($product->Group_id); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($product->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($product->updated_at); ?></p>
</div>

<?php /**PATH /home/dpwchzpd/public_html/resources/views/products/show_fields.blade.php ENDPATH**/ ?>
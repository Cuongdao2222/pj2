
<!-- <li class="nav-item">
    <a href="<?php echo e(route('banners.index')); ?>"
       class="nav-link <?php echo e(Request::is('banners*') ? 'active' : ''); ?>">
        <p>Banners</p>
    </a>
</li> -->

<style type="text/css">
    
    .child-nav{
        margin-left: 15px;
    }
</style>



<li>
     <a href="<?php echo e(route('home-admin')); ?>"
       class="nav-link <?php echo e(Request::is('home-admin') ? 'active' : ''); ?>" style="width: 68%;">
        <p>Trang chủ</p>
        
    </a>
</li>



<li class="nav-item"  >
    <div style="display:flex;">
        <a href="<?php echo e(route('pop-up-show')); ?>"
           class="nav-link <?php echo e(Request::is('groupProducts*') ? 'active' : ''); ?>" style="width: 68%;">
            <p>Hiển thị</p>
            
        </a>
       
        <span class="btn btn-link opens-fe" style="width: 12%;">+</span>
    </div>    
        

   <!--  <ul style="width: 68%">
        
        <li class="child-navs" style="">
            <a href="<?php echo e(route('pop-up-show')); ?>" class="nav-link">
                <p>Popup-toàn trang</p>
            </a>
        </li>

        <li class="child-navs" style="">
            <a href="#" class="nav-link">
                <p>Tìm kiếm nhiều cuối trang</p>
            </a>
        </li>

        <li class="child-navs" style="">
            <a href="#" class="nav-link">
                <p>Đổi hình nền toàn trang</p>
            </a>
        </li>
        
    </ul> -->
    
</li>


<li class="nav-item" style="display: flex; height:44px;"  >

   

    <a href="<?php echo e(route('groupProducts.index')); ?>"
       class="nav-link <?php echo e(Request::is('groupProducts*') ? 'active' : ''); ?>" style="width: 68%;">
        <p>Nhóm sản phẩm</p>
        
    </a>

    <?php
        $listGroup = App\Models\groupProduct::select('name','id')->get();

    ?>

    <?php if(count($listGroup)>0): ?>
     <span class="btn btn-link open" style="width: 12%;">+</span>
     <?php endif; ?> 
    
    
</li>

<ul style="width: 68%;">
    <?php if(count($listGroup)>0): ?>
    <?php $__currentLoopData = $listGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="child-nav">
        <a href="<?php echo e(route('select-category',[$value->id])); ?>"
           class="nav-link">
            <p><?php echo e($value->name); ?></p>
        </a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</ul>


<li class="nav-item">
    <a href="<?php echo e(route('makers.index')); ?>"
       class="nav-link <?php echo e(Request::is('makers*') ? 'active' : ''); ?>">
        <p>Hãng phân phối</p>
    </a>
</li>

<li class="nav-item">
    <a href="#"
       class="nav-link <?php echo e(Request::is('makers*') ? 'active' : ''); ?>">
        <p>Sửa css trang</p>
    </a>
</li>


<?php if(Auth::user()->id==2 || Auth::user()->id==1): ?>

<li class="nav-item">
    <a href="<?php echo e(route('products.index')); ?>"
       class="nav-link <?php echo e(Request::is('products*') ? 'active' : ''); ?>">
        <p>Sản phẩm</p>
    </a>
</li>

<?php endif; ?>

<?php if(Auth::user()->id==1): ?>

<li class="nav-item">
    <a href="<?php echo e(route('view-user')); ?>"
       class="nav-link <?php echo e(Request::is('products*') ? 'active' : ''); ?>">
        <p>Quản trị người dùng</p>
    </a>
</li>

<?php endif; ?>

<li class="nav-item">
    <a href="<?php echo e(route('banners.index')); ?>"
       class="nav-link <?php echo e(Request::is('banners*') ? 'active' : ''); ?>">
        <p>Banner</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('order_list')); ?>"
       class="nav-link <?php echo e(Request::is('order_list') ? 'active' : ''); ?>">
        <p>Order</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('posts.index')); ?>"
       class="nav-link <?php echo e(Request::is('order_list') ? 'active' : ''); ?>">
        <p>Bài viết </p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('landing')); ?>"
       class="nav-link <?php echo e(Request::is('landing') ? 'active' : ''); ?>">
        <p>Landing-page </p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('rate-client')); ?>"
       class="nav-link <?php echo e(Request::is('order_list') ? 'active' : ''); ?>">
        <p>Đánh giá sản phẩm </p>
    </a>
</li>

<style type="text/css">
    
    .child-nav a{
        width: 100%;
    }
</style>

<script type="text/javascript">
    $('.child-nav').hide();

    $('.child-navs').hide();

    $(".open").bind("click", function(){

        var acction = $(".open").text();

        if(acction =='+'){
            $('.child-nav').show();
            $('.open').text('-');
        }
        else{
            $('.child-nav').hide();
            $('.open').text('+');
        }
    });

    $(".opens-fe").bind("click", function(){

        var acction = $(this).text();

        if(acction =='+'){
            
            $(".opens-fe").text('-');
            $('.child-navs').show();
        }
        else{
            
            $(this).text('+');
            $('.child-navs').hide();
        }
    });
    
</script>


<li class="nav-item">
    <a href="<?php echo e(route('gifts.index')); ?>"
       class="nav-link <?php echo e(Request::is('gifts*') ? 'active' : ''); ?>">
        <p>Gifts</p>
    </a>
</li>


<?php /**PATH /home/dpwchzpd/public_html/resources/views/layouts/menu.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<style type="text/css">
    
    .btn-red{
        background: yellow;
    }
</style>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <!-- Search form -->
                    <form class="form-inline active-pink-3 active-pink-4 " method="post" action="<?php echo e(Route('find-product')); ?>">
                        <?php echo csrf_field(); ?>
                        <button><i class="fas fa-search" aria-hidden="true"></i></button>
                        <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
                            aria-label="Search" name="search">
                    </form>
                </div>
                <div class="col-sm-6">
                    <a class="btn btn-primary float-right"
                       href="<?php echo e(route('products.create')); ?>">
                        Add New
                    </a>
                </div>

                <div class="btn btn-red"><a href="<?php echo e(route('deal')); ?>">deal sản phẩm</a></div>
            </div>
        </div>
    </section>

    <div class="content px-3">

        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="clearfix"></div>

        <div class="card">
            <div class="card-body p-0">
                <?php echo $__env->make('products.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card-footer clearfix">
                    <div class="float-right">
                        <?php echo $__env->make('adminlte-templates::common.paginate', ['records' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dpwchzpd/public_html/resources/views/products/index.blade.php ENDPATH**/ ?>
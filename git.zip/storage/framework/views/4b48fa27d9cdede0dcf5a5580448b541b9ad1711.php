<!-- Maker Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('maker', 'Maker:'); ?>

    <?php echo Form::text('maker', null, ['class' => 'form-control','maxlength' => 500]); ?>

</div><?php /**PATH /home/dpwchzpd/public_html/resources/views/makers/fields.blade.php ENDPATH**/ ?>
<div class="table-responsive">
    <table class="table" id="filters-table">
        <thead>
        <tr>
            <th>Name</th>
        <th>Code</th>
        <th>Group Product Id</th>
            <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($filter->name); ?></td>
            <td><?php echo e($filter->code); ?></td>
            <td><?php echo e($filter->group_product_id); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['filters.destroy', $filter->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('filters.show', [$filter->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('filters.edit', [$filter->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                       
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/dpwchzpd/public_html/resources/views/filters/table.blade.php ENDPATH**/ ?>
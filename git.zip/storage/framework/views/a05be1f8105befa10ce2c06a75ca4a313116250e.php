<div class="table-responsive">
    <div>
        <button class="groupProduct">Xem toàn bộ danh mục liên quan</button>

    </div>

    <?php  

        function recursiveMenu($data, $parent_id=0, $sub=true){
            echo $sub ? '<ul>': '<ul class="sub-menu">';
            foreach ($data as $key => $item) {
                 if($item['group_product_id'] == $parent_id){
                    unset($data[$key]);
                  ?>    
             <li>
              <a href="<?php echo $item['slug']?>"><?php echo $item['name']?></a>
              
              <?php recursiveMenu($data, $item['id'], false); ?>
             </li>
                <?php }} 
             echo "</ul>";
        }

        
        

    ?>
    <table class="table" id="groupProducts-table">
        <thead>
        <tr>
            <th>Name</th>
            <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $groupProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($groupProduct->name); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['groupProducts.destroy', $groupProduct->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('groupProducts.show', [$groupProduct->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('groupProducts.edit', [$groupProduct->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                         <a href="<?php echo e(route('filters.create')); ?>?groupid=<?php echo e($groupProduct->id); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="fa fa-filter"></i>
                        </a>
                       


                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="modal fade" id="modals-product" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nhóm danh mục</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    

                     <?php   recursiveMenu($groupProducts); ?>

                </div>
                
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $('.groupProduct').click(function () {
           
           $('#modals-product').modal('show');

        })

    </script>
</div>
<?php /**PATH /home/dpwchzpd/public_html/resources/views/group_products/table.blade.php ENDPATH**/ ?>
<!-- Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($groupProduct->id); ?></p>
</div>

<!-- Name Field -->
<div class="col-sm-12">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($groupProduct->name); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($groupProduct->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($groupProduct->updated_at); ?></p>
</div>

<?php /**PATH /home/dpwchzpd/public_html/resources/views/group_products/show_fields.blade.php ENDPATH**/ ?>
<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH /home/dpwchzpd/public_html/resources/views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>


    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-12">
                    <h1>Create Product</h1>
                </div>
            </div>
        </div>
    </section>





    <?php if(Session::get('id')): ?>   

     <?php $id = Session::get('id') ?>
    <div class="btn btn-info"><a href="<?php echo e(route('images.create', $id)); ?>" style="color:red"> thêm ảnh chi tiết cho sản phẩm</a></div>

    <div class="btn btn-info seo-click"> Dùng cho SEO </div>
   
    <?php  

        $products_seo = App\Models\product::select('Meta_id')->where('id',  $id)->first();


    ?>
    <div class="content px-3">

        <?php $metaSeo = App\Models\metaSeo::find($products_seo->Meta_id); ?>

        <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card seo">

            <?php echo Form::model($metaSeo, ['route' => ['metaSeos.update', $metaSeo->id], 'method' => 'patch']); ?>


            <div class="card-body">
                <div class="row">
                    <?php echo $__env->make('meta_seos.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div class="card-footer">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                <a href="<?php echo e(route('metaSeos.index')); ?>" class="btn btn-default">Cancel</a>
            </div>

            <?php echo Form::close(); ?>


        </div>
    </div>
     

    <?php else: ?> 

    <div class="content px-3">

        <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card">

            <?php echo Form::open(['route' => 'products.store', 'files' => true]); ?>


            <div class="card-body">

                <div class="row">
                    <?php echo $__env->make('products.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>

            <div class="card-footer">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-default">Cancel</a>
            </div>

            <?php echo Form::close(); ?>


        </div>
    </div>

    <?php endif; ?>
     
   <!--  <script type="text/javascript">
        
        $('.seo').hide();

        $(".seo-click").click(function(){
           $('.seo').show();
        });
    </script> -->

    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dpwchzpd/public_html/resources/views/products/create.blade.php ENDPATH**/ ?>
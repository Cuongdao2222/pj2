<?php $__env->startSection('content'); ?> 
    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/category.css')); ?>"> 

        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/categories.css')); ?>"> 

        <style type="text/css">
            
            .box-filter .form-control{
                width: 100%;
            }
        </style>

    
    <?php $__env->stopPush(); ?>

        <div class="locationbox__overlay"></div>
        <!-- <div class="locationbox">
            <div class="locationbox__item locationbox__item--right" onclick="OpenLocation()">
                <p>Chọn địa chỉ nhận hàng</p>
                <a class="cls-location" href="javascript:void(0)">Đóng</a>
            </div>
            <div class="locationbox__item" id="lc_title"><i class="icondetail-address-white"></i><span> Vui lòng đợi trong giây lát...</span></div>
            <div class="locationbox__popup" id="lc_pop--choose">
                <div class="locationbox__popup--cnt locationbox__popup--choose">
                    <div class="locationbox__popup--chooseDefault">
                        <div class="lds-ellipsis">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                </div>
            </div>
            <b id="h-provincename" style="display:none!important" data-provinceid="3">Hồ Chí Minh</b>
        </div> -->
        <div class="locationbox__popup new-popup hide" id="lc_pop--sugg">
            <div class="locationbox__popup--cnt locationbox__popup--suggestion new-locale">
                <div class="flex-block">
                    <i class="icon-location"></i>
                    <p>Hãy chọn <b>địa chỉ cụ thể</b> để chúng tôi cung cấp <b>chính xác</b> th&#x1EDD;i gian giao h&#xE0;ng v&#xE0; t&#xEC;nh tr&#x1EA1;ng h&#xE0;ng.</p>
                </div>
                <div class="btn-block">
                    <a href="javascript:;" class="btn-location" onclick="OpenLocation()"><b>Chọn địa chỉ</b></a>
                    <a href="javascript:;" class="btn-location gray" onclick="SkipLocation()"><b>Đóng</b></a>
                </div>
            </div>
        </div>

        <div class="bsc-block">
            <section>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('homeFe')); ?>">Trang chủ</a></li>

                    <?php if(isset($ar_list)): ?>
                    <?php $__currentLoopData = $ar_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <li>
                        <a href="<?php echo e(route('details', @$val['link'])); ?>"><?php echo e(@$val['name']); ?></a>
                    </li>

                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </section>
        </div>
        <div class="top-banner">
            <section>
                <div class="slider-bannertop owl-carousel owl-theme">
                    <div class="item">
                        <a aria-label="slide" data-cate="1942" data-place="1537"><img width=800  src="https://cdn.tgdd.vn/2022/01/banner/800-200-800x200-38.png" alt="tivi chung"  ></a>
                    </div>
                    
                </div>
                <!-- <div class="promote-banner ">
                    <a href="/Banner C&#x1ED1; &#x110;&#x1ECB;nh" class="promote-item">
                    <a aria-label="slide" data-cate="1942" data-place="1538" href="#" onclick="jQuery.ajax({ url: '/bannertracking?bid=43621&r='+ (new Date).getTime(), async: true, cache: false });"><img  src="https://cdn.tgdd.vn/2021/07/banner/TraGop390-97-390x97-1.png" alt="Banner Cố Định"  ></a>
                    </a>
                    <a href="/tivi tr&#x1B0;ng b&#xE0;y" class="promote-item">
                    <a aria-label="slide" data-cate="1942" data-place="1538" href="https://www.dienmayxanh.com/may-doi-tra/tivi?type=7#" onclick="jQuery.ajax({ url: '/bannertracking?bid=45610&r='+ (new Date).getTime(), async: true, cache: false });"><img  src="https://cdn.tgdd.vn/2021/08/banner/390-97-390x97-4.png" alt="tivi trưng bày"  ></a>
                    </a>
                </div> -->
            </section>

        </div>
       
 
        <div class="box-filter top-box  block-scroll-main cate-1942">

            <section>
                <div class="jsfix scrolling_inner scroll-right">
                    <div><h4>Điện máy nguời việt là địa chỉ bán tivi chính hãng uy tín tại Hà Nội. Chúng tôi cam kết tất cả sản phẩm đều là hàng chính hãng, nguyên đai, nguyên kiện, mới 100%.</h4></div>
                    <div class="box-filter block-scroll-main scrolling">
                        <?php if(isset($filter)): ?>
                        <?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php
                            $propertyId =  App\Models\property::where('filterId', $filters->id)->get();
                        ?>

                        <div class="filter-item block-manu ">
                            <select class="form-control" id="selectfilter<?php echo e($filters->id); ?>" name="selectfilter" onchange='mySelectHandler("<?php echo e($filters->id); ?>")'>
                                <option value="0"><?php echo e($filters->name); ?></option>
                                <?php if(isset($propertyId)): ?>
                                <?php $__currentLoopData = $propertyId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($property->id); ?>"> <?php echo e($property->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>    
                </div>       
            </section>
        </div>
        <section id="categoryPage" class="desktops" data-id="1942" data-name="Tivi" data-template="cate">

            

            <div class="box-sort ">
                <?php if(isset($data)): ?>
                <p class="sort-total"><b><?php echo e(count($data)); ?></b> Sản phẩm <strong class="manu-sort"></strong></p>

                <?php endif; ?>
                <div class="sort-select ">
                    <label for="standard-select">Xếp theo</label>
                    <div class="select">
                      <select id="sort-by-option">
                        <option value="id">Nổi bật</option>
                        <option value="asc">Giá tăng dần</option>
                        <option value="desc">Giá giảm dần</option>
                      </select>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="container-productbox">
                <!-- <div id="preloader">
                    <div id="loader"></div>
                </div> -->
                <div class="row list-pro">
                    <?php if(isset($data)): ?>
                    <?php $arr_id_pro = []; ?>
                   
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value->active==1): ?>
                            <?php   

                                $id_product = $value->id;
                                array_push($arr_id_pro, $id_product);
                            ?>

                        <div class="col-md-3 col-6 lists">
                            <div class="item  __cate_1942">
                                <a href='<?php echo e(route("details", $value->Link )); ?>' data-box="BoxCate" class="main-contain">
                                    <div class="item-label">
                                        <span class="lb-tragop">Trả góp 0%</span>
                                    </div>
                                    <div class="item-img item-img_1942">
                                        <img class="lazyload thumb" data-src="<?php echo e(asset($value->Image)); ?>" alt="<?php echo e(asset($value->Name)); ?>" style="width:100%"> 
                                    </div>
                                    <div class="items-title">
                                        <p class='result-label temp1'><img width='20' height='20' class='lazyload' alt='Giảm Sốc' data-src=''><span>Giảm Sốc</span></p>
                                        <h3 >
                                            <?php echo e($value->Name); ?>

                                        </h3>

                                        <?php

                                        if($id_cate ==1){

                                        
                                            $number_cut = strpos($value->Name, 'inch')-3;

                                            $result_cut  = substr($value->Name, $number_cut);

                                            $display  = substr($result_cut, -2);
                                        }


                                        ?>
                                        <?php if($id_cate ==1): ?>
                                        <div class="item-compare">
                                            <span><?php echo e(str_replace($display, '', $result_cut)); ?></span>
                                            <span><?php echo e($display); ?></span>
                                        </div>

                                        <?php endif; ?>
                                        <!-- <div class="box-p">
                                            <p class="price-old black">20.900.000&#x20AB;</p>
                                        </div> -->
                                        
                                        <strong class="price"><?php echo e(number_format($value->Price , 0, ',', '.')); ?></strong>
                                        <!-- <p class="item-gift">Quà <b>1.500.000₫</b></p> -->
                                        <div class="item-rating">
                                            <p>
                                                <i class="icon-star"></i>
                                                <i class="icon-star"></i>
                                                <i class="icon-star"></i>
                                                <i class="icon-star"></i>
                                                <i class="icon-star"></i>
                                            </p>
                                           <!--  <p class="item-rating-total">56</p> -->
                                        </div>

                                    </div>
                                    
                                </a>
                                <div class="item-bottom">
                                    <a href="#" class="shiping"></a>
                                </div>
                               <!--  <a href="javascript:void(0)" class="item-ss">
                                    <i></i>
                                    So sánh
                                </a> -->
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                     <span class="lists-id"><?php echo e(json_encode($arr_id_pro)); ?></span>
                      
                   
                   <?php else: ?>   

                    <div style="margin-left: 20px;">
                        <h2>Không tìm thấy sản phẩm</h2>
                    </div>
                    
                    <?php endif; ?>


                </div>
                <!-- <div class="view-more ">
                    <a href="javascript:;">Xem thêm <span class="remain">133</span> Tivi</a>
                </div> -->
            </div>


          
            <div class="errorcompare" style="display:none;"></div>
           <!--  <div class="block__banner banner__topzone">
                <a data-cate="0" data-place="1919" href="https://www.topzone.vn/" onclick="jQuery.ajax({ url: '/bannertracking?bid=48557&r='+ (new Date).getTime(), async: true, cache: false });"><img style="cursor:pointer" src="https://cdn.tgdd.vn/2021/12/banner/Frame4879-1200x120.jpg" alt="Promote Topzone" width="1200" height="120"></a>
            </div> -->
            <div class="watched"></div>
            <div class="overlay"></div>

           
            <?php if(\Request::route()->getName()!='search-product-frontend'): ?>
            <?php echo e(@$data->links()); ?>


            <?php endif; ?>
        </section>
        <?php $__env->startPush('script'); ?>
        <script type="text/javascript">
            filter = [];

            propertys = [];

             $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            
            function mySelectHandler(filters){

                property = $('#selectfilter'+filters).val();


                // kiểm tra filter có bị trùng không xóa filter trước + xóa property cùng filter

                if(filter.indexOf(filters)>-1){
                    filter.splice(filter.indexOf(filters),1);
                    propertys.splice(filter.indexOf(filters),1);
                }

                //chỉ lấy giá trị 
                if(property !=0){

                    filter.push(filters);

                    propertys.push(property);

                }
                
                // var filterss['code'] = property; 


                // khi người dùng select option thì gọi hàm
                if(filter.length>0){

                    filter = filter.join(',');

                    propertys = propertys.join(',');


                    window.location.href = '<?php echo e(route('details',$link)); ?>?filter=,'+filter+'&group_id=<?php echo e(@$id_cate); ?>&property=,'+propertys+'&link=<?php echo e($link); ?>';

                }

            }

            $( "#sort-by-option" ).bind( "change", function() {

                $.ajax({
       
                type: 'GET',
                    url: "<?php echo e(route('filter-option')); ?>",
                    data: {
                        json_id_product: $('.lists-id').text(),
                        action:$(this).val(),
                        
                    },
                    success: function(result){

                        $('#categoryPage').html('');

                        $('#categoryPage').html(result);

                        console.log(json_id_product)

                    }
                });

            });

        
        </script>
        <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 

        
<?php echo $__env->make('frontend.layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dpwchzpd/public_html/resources/views/frontend/category.blade.php ENDPATH**/ ?>
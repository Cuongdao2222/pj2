<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class saleProduct extends Model
{
    public $table = 'sale_product';
}

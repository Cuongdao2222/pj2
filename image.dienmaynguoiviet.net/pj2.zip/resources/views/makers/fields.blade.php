<!-- Maker Field -->
<div class="form-group col-sm-6">
    {!! Form::label('maker', 'Maker:') !!}
    {!! Form::text('maker', null, ['class' => 'form-control','maxlength' => 500]) !!}
</div>
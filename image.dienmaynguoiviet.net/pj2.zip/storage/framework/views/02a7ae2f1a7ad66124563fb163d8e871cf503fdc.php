


<?php $__env->startSection('content'); ?>
<?php 
    $image = new App\Models\banner();

    $image = $image->get();


    $news =  new \App\Models\post();

    $news = $news->orderBy('id')->take(6)->get(); 

?>

<div class="box_bxslider hidden-xs" id="box_bxslider">
            <div class="box_content">
                <ul class="bxslider">
                    <?php if(count($image)>0): ?>
                    <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href=""><img src="<?php echo e(url( $banner->banner_image )); ?>" alt="D'media - Thành công từ những nụ cười"></a></li>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <div class="box_bxslider_mobile hidden-sm hidden-md hidden-lg" id="box_bxslider_mobile">
            <div class="box_content">
                <ul class="bxslider">
                     <?php if(count($image)>0): ?>
                    <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href=""><img src="<?php echo e(url( $banner->banner_image )); ?>" alt="D'media - Thành công từ những nụ cười"></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <div class="box_defaultHighlightCategory">
            <div class="container">
                <div class="wrapper">
                    <div class="box_wrap">
                        <div class="box_title">
                            <h1 class="title"><a href="javascript:void(0)" title="Về D'media">Về D’ Dental</a></h1>
                        </div>
                        <div class="box_content">
                            <p>Được thành lập vào năm 2021 bởi đội ngũ Y Bác Sĩ giàu kinh nghiệm, nhiệt huyết với nghề, Nha khoa D’ Dental mang trong mình sứ mệnh đem đến nụ cười hạnh phúc và tự tin cho khách hàng. Hai yếu tố sức khoẻ và tính thẩm mỹ luôn được đội ngũ của D’ Dental đặt lên hàng đầu trong mọi dịch vụ của phòng khám đẻ đem đến cho khách hàng những trải nghiệm hài lòng nhất tại mọi cơ sở phòng khám của D’ Dental.
                            </p>
                            <div class="controls">
                                <a href="javascript:void(0)" class="view btn_yellow register-book">Đặt lịch khám</a>
                                
                            </div>
                        </div>
                    </div>
                    <div class="image"><img src="<?php echo e(asset('public/files/upload/default/images/bai-viet/gioithieu.png')); ?>" style="
    width: 90%;"></div>
                </div>
            </div>
        </div>
        <div class="box_productCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/rang-su-tham-my" title="Răng sứ thẩm mỹ">Răng sứ thẩm mỹ</a></h2>
                    <a href="/rang-su-tham-my" class="view_all">Xem tất cả</a>
                </div>
                <div class="box_desc">D'media tập trung cung cấp các dịch vụ nha khoa thẩm mỹ trong môi trường nhẹ nhàng, chu đáo, chuyên nghiệp. Đảm bảo mọi khách hàng tới D'media đều có những trải nhiệm nha khoa đẳng cấp, ưng ý nhất cho đường cười của chính mình. </div>
                <div class="box_content">
                    <div class="row productGrid">
                         <?php 

                    		$feedback = App\Models\post::where('category', 6)->take(8)->get();
                    	?>
                    	<?php if(count($feedback)>0): ?>
                    	<?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><img src="<?php echo e(@url($newss['image'])); ?>" alt="<?php echo e(@$newss['title']); ?>"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><?php echo e(@$newss['title']); ?></a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="<?php echo e(route('single', @$newss['link'])); ?>" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                       
                    </div>
                </div>
                <div class="control"><a href="/rang-su-tham-my" class="btn_yellow">Xem tất cả dịch vụ </a></div>
            </div>
        </div>
        <div class="box_serviceCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/doi-ngu-bac-si" title="Đội ngũ bac sĩ">Đội ngũ bác sĩ</a></h2>
                    <a href="/nha-khoa-benh-ly" class="view_all">Xem tất cả</a>
                </div>
                <div class="box_desc">D' Dental quy tụ hơn 20 bác sĩ có chứng chỉ hành nghề, nhiều năm kinh nghiệm, tốt nghiệp Răng Hàm Mặt trong và ngoài nước, đã từng học tập cũng như tu nghiệp nhiều năm tại các nước có nền nha khoa phát triển trên thế giới.</div>
                <div class="box_content">
                    <div class="slide">
                        <?php 
                            $doctor = App\Models\post::where('category', 20)->take(8)->get();
                           

                        ?>

                        <?php if(count($doctor)>0): ?>
                        <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="image">
                               <img src="<?php echo e(@url($newss['image'])); ?>" alt="<?php echo e(@$newss['title']); ?>">
                            </div>
                            <div class="info">
                                <h3 class="title"><?php echo e(@$newss['title']); ?>

                            </div>
                        </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                       
                    </div>
                </div>
            </div>
        </div>
        <div class="box_defaultCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/tin-tuc-su-kien" title="Tin Tức / Sự Kiện">Tin Tức / Sự Kiện</a></h2>
                </div>
                <div class="box_desc">Các Tin Tức / Sự Kiện nổi bật của hệ thống Nha Khoa Thẩm Mỹ Quốc Tế D'media.</div>
                <div class="box_content">
                    <div class="row">


                        <?php if(count($news)>=6): ?>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-xs-12">
                            <div class="item">
                                <div class="image">
                                    <a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><img src="<?php echo e(@url($newss['image'])); ?>" alt="<?php echo e(@$newss['title']); ?>"></a>
                                </div>


                                <div class="info">
                                    <h3 class="title"><a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"> <?php echo e($newss['title']); ?></a></h3>
                                    <div class="desc"> <?php echo _substrs(@$newss['content'],150); ?><a href="<?php echo e(route('single', @$newss['link'])); ?>">Xem thêm</a></div>
                                    <span class="date">Ngày <?php echo e(date('d/m/Y',strtotime( $newss['created_at']))); ?>   </span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                       
                       
                    </div>
                </div>
                <div class="control"><a href="/tin-tuc-su-kien" class="btn_yellow">Xem thêm các tin tức mới</a></div>
            </div>
        </div>
       <?php echo $__env->make('frontend.khachhangdanhgia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/frontend/home.blade.php ENDPATH**/ ?>
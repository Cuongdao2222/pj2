 <div class="box_feedbackCategoryHome">
    <div class="container">
        <div class="box_title">
            <h2 class="title"><a href="/cam-nhan-khach-hang" title="Khách hàng nói gì về D'media?">Khách hàng nói gì về D'media?</a></h2>
            <a href="/cam-nhan-khach-hang" class="view_all">Xem tất cả</a>
        </div>
        <div class="box_desc"></div>
        
       
        <div class="box_content">
            <div class="slide">
                 <?php 

            		$feedback = App\Models\post::where('category', 23)->take(5)->get();
            	?>
            	<?php if(count($feedback)>0): ?>
            	<?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="item_content"><?php echo @$newss['content']; ?></div>
                    <div class="item_info">
                        <div class="image">
                            <a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><img src="<?php echo e(@url($newss['image'])); ?>" alt="<?php echo e(@$newss['title']); ?>"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><?php echo e(@$newss['title']); ?></a></h3>
                            <div class="desc">Diễn viên <span></span></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
               
            </div>
        </div>
    </div>
</div><?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/frontend/khachhangdanhgia.blade.php ENDPATH**/ ?>
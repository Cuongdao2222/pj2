
<!DOCTYPE html><html>
<head>
    <title>Nha khoa bệnh lý</title><meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="author" content="">
<meta name="description" content="">
<meta name="keywords" content="">
<meta property="og:type" content="website">
<meta property="og:title" content="Nha khoa bệnh lý">
<meta property="og:description" content="">
<link href="<?php echo e(asset('public/files/upload/default/images/he-thong/favicon.png')); ?>" rel="icon" type="image/x-icon">
<link href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css')}}" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/template/frontend/css/bootstrap.min.css')); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/template/frontend/css/fontawesome-all.min.css')); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/template/frontend/plugins/fancybox/source/jquery.fancybox.css')); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/template/frontend/plugins/fancybox/source/jquery.fancybox-thumbs.css')); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/template/frontend/plugins/bxslider/jquery.bxslider.css')); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/template/frontend/css/font.css?v=24112021014725')); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/template/frontend/css/style.css?v=24112021014725')); ?>" media="screen" rel="stylesheet" type="text/css">  
<!-- Facebook Pixel Code -->

<body class="body">
    
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-49393751-2"></script>


<!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
    

      <!-- Your Chat Plugin code -->
      <div class="fb-customerchat"
        attribution=setup_tool
        page_id="728036117400680"
  theme_color="#eac470"
  logged_in_greeting="Bác sĩ nha khoa có thể giúp gì cho bạn?"
  logged_out_greeting="Bác sĩ nha khoa có thể giúp gì cho bạn?">
      </div>

<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>


<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P3BBXGG"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    
    <div class="box_top hidden-xs">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
            	<div class="hotline">
            		<span class="item">Hà Nội: <a href="tel:0966688234">0966.688.234</a></span>
            		<span class="item">TP.Hồ Chí Minh: <a href="tel:0966688234">0966 688 234</a></span>
            	</div>
        	</div>
            <div class="col-sm-6">
                <div class="social">
                    <a href="https://www.facebook.com/nhakhoaquoctewinsmile" target="_blank"><img src="public/template/frontend/img/icon_2.png')}}"></a>
                    <a href="" target="_blank"><img src="public/template/frontend/img/icon_3.png')}}"></a>
                    <a href="https://www.youtube.com/channel/UCuhJRuawEhoFPDMZkzts7og" target="_blank"><img src="public/template/frontend/img/icon_4.png')}}"></a>
                </div>
                <div class="open">
                    <span class="item">Giờ mở cửa: <span>8h00 - 20h00</span></span>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="box_header" id="box_header">
    <div class="container">
        <div class="box_content">
            <div class="item menu"><div class="box_menuMain2 left">
                    <ul><li class="dropdown" data-level="2"><a href="/rang-su-tham-my" target="_self" class=""><span class="title">Răng sứ</span></a><div class="dropdown_wrap"><ul><li class="dropdown" data-level="3"><a href="/dan-su" target="_self" class=""><span class="title">Dán sứ</span></a><div class="dropdown_wrap"><ul><li data-level="4" data-max="3" data-key="3"><a href="/dan-su-veneer-lisi" target="_self" class=""><span class="title">Dán sứ Veneer Lisi</span></a></li><li data-level="4" data-max="3" data-key="4"><a href="/dan-su-veneer" target="_self" class=""><span class="title">Dán sứ Veneer Emax Laminate</span></a></li><li data-level="4" data-max="3" data-key="5"><a href="/dan-su-suon-ziconia" target="_self" class=""><span class="title">Dán sứ sườn Ziconia</span></a></li></ul></div></li><li class="dropdown" data-level="3"><a href="/boc-su" target="_self" class=""><span class="title">Bọc sứ</span></a><div class="dropdown_wrap"><ul><li data-level="4" data-max="3" data-key="7"><a href="/rang-su-orodent" target="_self" class=""><span class="title">Răng sứ Orodent</span></a></li><li data-level="4" data-max="3" data-key="8"><a href="/rang-su-biodiamond" target="_self" class=""><span class="title">Răng sứ Biodiamond</span></a></li><li data-level="4" data-max="3" data-key="9"><a href="/rang-su-lava-3m" target="_self" class=""><span class="title">Răng sứ Lava 3M</span></a></li><li data-level="4" data-max="3" data-key="10"><a href="/rang-su-nacera-q3" target="_self" class=""><span class="title">Răng sứ Nacera Q3</span></a></li><li data-level="4" data-max="3" data-key="11"><a href="/rang-su-nacera" target="_self" class=""><span class="title">Răng sứ Nacera</span></a></li><li data-level="4" data-max="3" data-key="12"><a href="/rang-su-ht-smile" target="_self" class=""><span class="title">Răng sứ HT Smile</span></a></li><li data-level="4" data-max="3" data-key="13"><a href="/rang-su-ceramill" target="_self" class=""><span class="title">Răng sứ Ceramill</span></a></li><li data-level="4" data-max="3" data-key="14"><a href="/rang-su-venus" target="_self" class=""><span class="title">Răng sứ Venus</span></a></li><li data-level="4" data-max="3" data-key="15"><a href="/rang-su-katana" target="_self" class=""><span class="title">Răng sứ Katana</span></a></li><li data-level="4" data-max="3" data-key="16"><a href="https://winsmile.vn/boc-rang-su" target="_self" class=""><span class="title">Bọc răng sứ</span></a></li></ul></div></li></ul></div></li><li class="dropdown" data-level="2"><a href="/chinh-nha" target="_self" class=""><span class="title">Niềng răng</span></a><div class="dropdown_wrap"><ul><li data-level="3" data-max="3" data-key="18"><a href="https://winsmile.vn/nieng-rang" target="_self" class=""><span class="title">Niềng răng</span></a></li><li data-level="3" data-max="3" data-key="19"><a href="/nieng-rang-mac-cai-kim-loai" target="_self" class=""><span class="title">Niềng răng mắc cài kim loại</span></a></li><li data-level="3" data-max="3" data-key="20"><a href="/nieng-rang-mac-cai-kim-loai-tu-buoc" target="_self" class=""><span class="title">Niềng răng mắc cài kim loại tự buộc</span></a></li><li data-level="3" data-max="3" data-key="21"><a href="/nieng-rang-mac-cai-su" target="_self" class=""><span class="title">Niềng răng mắc cài sứ</span></a></li><li data-level="3" data-max="3" data-key="22"><a href="/nieng-rang-mac-cai-su-tu-buoc" target="_self" class=""><span class="title">Niềng răng mắc cài sứ tự buộc</span></a></li><li data-level="3" data-max="3" data-key="23"><a href="/nieng-rang-mac-cai-pha-le" target="_self" class=""><span class="title">Niềng răng mắc cài Pha Lê</span></a></li><li data-level="3" data-max="3" data-key="24"><a href="/nieng-rang-mat-luoi" target="_self" class=""><span class="title">Niềng răng mặt lưỡi</span></a></li><li data-level="3" data-max="3" data-key="25"><a href="/nieng-rang-invisalign-tham-my" target="_self" class=""><span class="title">Niềng răng invisalign thẩm mỹ</span></a></li></ul></div></li><li class="dropdown" data-level="2"><a href="/trong-rang" target="_self" class=""><span class="title">Trồng răng</span></a><div class="dropdown_wrap"><ul><li data-level="3" data-max="3" data-key="27"><a href="/trong-rang-implant-straumann" target="_self" class=""><span class="title">Trồng răng Implant Straumann</span></a></li><li data-level="3" data-max="3" data-key="28"><a href="/trong-rang-implant-dentium-usa" target="_self" class=""><span class="title">Trồng răng Implant Dentium USA</span></a></li><li data-level="3" data-max="3" data-key="29"><a href="/trong-rang-implant-osstem-tekka-global-d" target="_self" class=""><span class="title">Trồng răng Implant Tekka Global D</span></a></li><li data-level="3" data-max="3" data-key="30"><a href="/trong-rang-implant-osstem" target="_self" class=""><span class="title">Trồng răng Implant Osstem</span></a></li><li data-level="3" data-max="3" data-key="31"><a href="/trong-rang-implant-biotem" target="_self" class=""><span class="title">Trồng răng Implant Biotem</span></a></li><li data-level="3" data-max="3" data-key="32"><a href="/trong-rang-implant-toan-ham-all-on-six" target="_self" class=""><span class="title">Implant toàn hàm All-on-six</span></a></li><li data-level="3" data-max="3" data-key="33"><a href="/trong-rang-implant-toan-ham-all-on-four" target="_self" class=""><span class="title">Implant toàn hàm All-on-four</span></a></li><li data-level="3" data-max="3" data-key="34"><a href="/cau-rang-su" target="_self" class=""><span class="title">Cầu răng sứ</span></a></li></ul></div></li><li class="dropdown" data-level="2"><a href="/nha-khoa-benh-ly" target="_self" class="active"><span class="title">bệnh lý</span></a><div class="dropdown_wrap"><ul><li data-level="3" data-max="3" data-key="36"><a href="/quy-trinh-tham-kham-tu-van-tai-nha-khoa-win-smile" target="_self" class=""><span class="title">Quy trình thăm khám</span></a></li><li data-level="3" data-max="3" data-key="37"><a href="/tay-trang-rang" target="_self" class=""><span class="title">Tẩy trắng răng</span></a></li><li data-level="3" data-max="3" data-key="38"><a href="/nho-rang-khon" target="_self" class=""><span class="title">Nhổ răng khôn</span></a></li><li data-level="3" data-max="3" data-key="39"><a href="/han-tram-rang" target="_self" class=""><span class="title">Hàn trám răng</span></a></li><li data-level="3" data-max="3" data-key="40"><a href="/dieu-tri-tuy-rang" target="_self" class=""><span class="title">Điều trị tủy răng</span></a></li><li data-level="3" data-max="3" data-key="41"><a href="/dieu-tri-rang-sau" target="_self" class=""><span class="title">Điều trị răng sâu</span></a></li><li data-level="3" data-max="3" data-key="42"><a href="/dieu-tri-nha-chu" target="_self" class=""><span class="title">Điều trị nha chu</span></a></li><li data-level="3" data-max="3" data-key="43"><a href="/dieu-tri-cuoi-ho-loi" target="_self" class=""><span class="title">Điều trị cười hở lợi</span></a></li></ul></div></li></ul>
                </div></div>
            <div class="item logo"><a href="/"><img src="<?php echo e(('public/files/upload/default/images/he-thong/logo.png')); ?>"></a></div>
            <div class="item menu"><div class="box_menuMain2 right">
                    <ul><li data-level="2" data-max="1" data-key="1"><a href="/ve-winsmile" target="_self" class=""><span class="title">Về WinSmile</span></a></li><li data-level="2" data-max="1" data-key="2"><a href="/tin-tuc-su-kien" target="_self" class=""><span class="title">Sự kiện / Blog</span></a></li><li data-level="2" data-max="1" data-key="3"><a href="/cam-nhan-khach-hang" target="_self" class=""><span class="title">Cảm nhận khách hàng</span></a></li><li data-level="2" data-max="1" data-key="4"><a href="/lien-he" target="_self" class=""><span class="title">Liên hệ</span></a></li></ul>
                </div></div>
        </div>
    </div>
    <a href="/" class="logo_mobile"><img src="<?php echo e(('public/files/upload/default/images/he-thong/logo-white.png')); ?>"></a>
    <a href="javascript:;" class="toggle" id="menu_toggle">
        <span class="line"></span>
        <span class="line"></span>
        <span class="line"></span>
        <span class="line"></span>
    </a>
</div>
    <div class="container">
        <div class="wrapper">
            <div class="row">
            	<div class="col-sm-9 col-sm-push-3">
              		<div class="container">
    <div class="box_module">
        <div class="box_title"><h1 class="title"><a href="/nha-khoa-benh-ly" title="Nha khoa bệnh lý">Nha khoa bệnh lý</a></h1></div>
        <div class="box_content">
            <div class="layout_category_product">
                <div class="productGrid service">
                    <div class="row">
                        <div class="col-sm-3 col-xs-6">
                                    <div class="item">
                                        <div class="image">
                                            <a href="/quy-trinh-tham-kham-tu-van-tai-nha-khoa-win-smile" title="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile"><img src="<?php echo e(('public/files/upload/default/medium/images/dich-vu/tay-trang-rang.jpg')); ?>" alt="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile"><span>Xem thêm</span></a>
                                        </div>
                                        <div class="info">
                                            <h3 class="title"><a href="/quy-trinh-tham-kham-tu-van-tai-nha-khoa-win-smile" title="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile">Quy trình thăm khám tư vấn tại Nha Khoa Win Smile</a></h3>
                                        </div>
                                    </div>
                                </div><div class="col-sm-3 col-xs-6">
                                    <div class="item">
                                        <div class="image">
                                            <a href="/dieu-tri-cuoi-ho-loi" title="Điều trị cười hở lợi"><img src="<?php echo e(('public/files/upload/default/medium/images/dich-vu/dieu-tri-cuoi-hoi-loi.jpg')); ?>" alt="Điều trị cười hở lợi"><span>Xem thêm</span></a>
                                        </div>
                                        <div class="info">
                                            <h3 class="title"><a href="/dieu-tri-cuoi-ho-loi" title="Điều trị cười hở lợi">Điều trị cười hở lợi</a></h3>
                                        </div>
                                    </div>
                                </div><div class="col-sm-3 col-xs-6">
                                    <div class="item">
                                        <div class="image">
                                            <a href="/dieu-tri-nha-chu" title="Điều trị nha chu"><img src="<?php echo e(('public/files/upload/default/medium/images/dich-vu/dieu-tri-nha-chu-1.jpg')); ?>" alt="Điều trị nha chu"><span>Xem thêm</span></a>
                                        </div>
                                        <div class="info">
                                            <h3 class="title"><a href="/dieu-tri-nha-chu" title="Điều trị nha chu">Điều trị nha chu</a></h3>
                                        </div>
                                    </div>
                                </div><div class="col-sm-3 col-xs-6">
                                    <div class="item">
                                        <div class="image">
                                            <a href="/dieu-tri-rang-sau" title="Điều trị răng sâu"><img src="<?php echo e(('public/files/upload/default/medium/images/dich-vu/dieu-tri-rang-sau.jpeg')); ?>" alt="Điều trị răng sâu"><span>Xem thêm</span></a>
                                        </div>
                                        <div class="info">
                                            <h3 class="title"><a href="/dieu-tri-rang-sau" title="Điều trị răng sâu">Điều trị răng sâu</a></h3>
                                        </div>
                                    </div>
                                </div><div class="col-sm-3 col-xs-6">
                                    <div class="item">
                                        <div class="image">
                                            <a href="/dieu-tri-tuy-rang" title="Điều trị tủy răng"><img src="<?php echo e(('public/files/upload/default/medium/images/dich-vu/dieu-tri-tuy-rang.jpg')); ?>" alt="Điều trị tủy răng"><span>Xem thêm</span></a>
                                        </div>
                                        <div class="info">
                                            <h3 class="title"><a href="/dieu-tri-tuy-rang" title="Điều trị tủy răng">Điều trị tủy răng</a></h3>
                                        </div>
                                    </div>
                                </div><div class="col-sm-3 col-xs-6">
                                    <div class="item">
                                        <div class="image">
                                            <a href="/tay-trang-rang" title="Tẩy trắng răng"><img src="<?php echo e(('public/files/upload/default/medium/images/dich-vu/tay-trang-rang.jpg')); ?>" alt="Tẩy trắng răng"><span>Xem thêm</span></a>
                                        </div>
                                        <div class="info">
                                            <h3 class="title"><a href="/tay-trang-rang" title="Tẩy trắng răng">Tẩy trắng răng</a></h3>
                                        </div>
                                    </div>
                                </div><div class="col-sm-3 col-xs-6">
                                    <div class="item">
                                        <div class="image">
                                            <a href="/han-tram-rang" title="Hàn trám răng"><img src="<?php echo e(('public/files/upload/default/medium/images/dich-vu/han-tram-rang')); ?>" alt="Hàn trám răng"><span>Xem thêm</span></a>
                                        </div>
                                        <div class="info">
                                            <h3 class="title"><a href="/han-tram-rang" title="Hàn trám răng">Hàn trám răng</a></h3>
                                        </div>
                                    </div>
                                </div><div class="col-sm-3 col-xs-6">
                                    <div class="item">
                                        <div class="image">
                                            <a href="/nho-rang-khon" title="Nhổ răng khôn"><img src="<?php echo e(('public/files/upload/default/medium/images/san-pham/nho-rang-khon-tai-winsmile.png')); ?>" alt="Nhổ răng khôn"><span>Xem thêm</span></a>
                                        </div>
                                        <div class="info">
                                            <h3 class="title"><a href="/nho-rang-khon" title="Nhổ răng khôn">Nhổ răng khôn</a></h3>
                                        </div>
                                    </div>
                                </div>                    </div>
                </div>
            </div>
                    </div>
    </div>
</div>
              	</div>
              	<div class="col-sm-3 col-sm-pull-9">
              	    
<div class="box_support" id="box_support">
                    <div class="box_title"><div class="title">Hỗ trợ trực tuyến</div></div>
                    <div class="box_content">
            		    
            <div class="item">
                <div class="name"><i class="fa fa-user" aria-hidden="true"></i> Hỗ trợ trực tuyến 24/7</div>
                <div class="phone"><i class="fas fa-mobile-alt"></i> 0966 688 234 - 0977 688 234</div>
                <div class="zalo"><i class="far fa-zalo">Z</i> 0966 688 234 - 0977 688 234</div>
                <div class="email"><i class="far fa-envelope"></i> </div>
            </div>
                    </div>
                </div>              	</div>
            </div>
        </div>
    </div>
    <div class="box_book" id="box_book">
    <div class="container">
        <div class="row">
            <div class="col-sm-5 hidden-xs">
                <img class="image" src="public/template/frontend/img/book.png')}}">
            </div>
            <div class="col-sm-7 col-xs-12">
                <div class="box_wrap">
                    <div class="box_title">Đặt lịch khám tại WinSmile</div>
                    <div class="box_content">
                        <form name="frmBook" id="frmBook">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group" id="input-name">
                                        <input type="text" name="name" class="form-control" placeholder="Họ tên khách hàng *">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group" id="input-phone">
                                        <input type="text" name="phone" class="form-control" placeholder="Số điện thoại liên hệ *">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group" id="input-day">
                                        <input type="text" name="day" class="form-control datepicker" placeholder="Ngày đặt lịch *">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group" id="input-location">
                                        <select name="location" class="form-control">
                                            <option value="">Chọn cơ sở gần bạn *</option>
                                            <option value="WinSmile Hà Nội">WinSmile Hà Nội</option><option value="WinSmile Hồ Chí Minh">WinSmile Hồ Chí Minh</option>                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="note">* Thông tin của bạn sẽ được bảo mật!</div>
                                    <div class="btnSuccess">
                                        <input type="hidden" name="form_id" value="1574996192843n19215gc8">
                                        <div class="control">
                                            <a href="javascript:;" onclick="javascript:formRegister('frmBook');" class="btn_yellow submit">Đặt lịch</a>
                                            <span class="open">Giờ làm việc: <br><span>8h00 đến 20h00</span></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><div class="box_tuvan hidden-xs" id="box_tuvan">
    <div class="box_content">
        <div class="col col-1">
            <img class="image" src="public/template/frontend/img/icon_17.png')}}">
            <div>Đăng</div>
            <div>Ký</div>
            <div>Nhận</div>
            <div>Tư</div>
            <div>Vấn</div>
        </div>
        <div class="col col-2">
            <form name="frmTuvan" id="frmTuvan">
                <div class="form-group" id="input-name">
                    <input type="text" name="name" class="form-control" placeholder="Họ tên khách hàng *">
                </div>
                <div class="form-group" id="input-phone">
                    <input type="text" name="phone" class="form-control" placeholder="Số điện thoại liên hệ *">
                </div>
                <div class="form-group" id="input-email">
                    <input type="text" name="email" class="form-control" placeholder="Email liên hệ *">
                </div>
                <div class="form-group" id="input-location">
                    <select name="location" class="form-control">
                        <option value="">Chọn cơ sở gần bạn *</option>
                        <option value="WinSmile Hà Nội">WinSmile Hà Nội</option><option value="WinSmile Hồ Chí Minh">WinSmile Hồ Chí Minh</option>                    </select>
                </div>
                <input type="hidden" name="form_id" value="1575130813q7ja36311m0f">
            </form>
        </div>
        <div class="col col-3" onclick="javascript:formRegister('frmTuvan');">
            <div class="btnSuccess">
                <img class="image" src="public/template/frontend/img/icon_18.png')}}">
                <div>Gửi</div>
            </div>
        </div>
    </div>
</div><div class="box_footer">
    <div class="container">
        <div class="logo">
            <img src="<?php echo e(('public/files/upload/default/images/he-thong/logo.png')); ?>">
        </div>
        <div class="row">
            <div class="col-sm-5">
                <div class="box_title">Win Smile Lê Duẩn</div>
                <div class="box_content">
                    <p>Địa chỉ: 51B L&ecirc; Duẩn, Ho&agrave;n Kiếm, H&agrave; Nội<br />
Điện thoại: 0966.688.234</p>
                </div>
                <div class="box_title">WinSmile Đường Láng</div>
                <div class="box_content">
                    <p>Địa chỉ: Số 10/1194 đường L&aacute;ng, Đống Đa, H&agrave; Nội<br />
Điện thoại: 0967.688.234</p>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="box_title">Hotline</div>
                <div class="box_content">
                    <div class="hotline">0966 688 234</div>
                </div>
                <div class="box_title">Liên kết</div>
                <div class="box_content">
                    <div class="box_menuFooter"><ul><li data-level="2" data-max="2" data-key=""><a href="/ve-winsmile" target="_self" class=""><span class="title">Về WinSmile</span></a></li><li data-level="2" data-max="2" data-key=""><a href="/blog" target="_self" class=""><span class="title">Blog</span></a></li><li data-level="2" data-max="2" data-key=""><a href="/cam-nhan-khach-hang" target="_self" class=""><span class="title">Cảm nhận khách hàng</span></a></li><li data-level="2" data-max="2" data-key=""><a href="/lien-he" target="_self" class=""><span class="title">Liên hệ</span></a></li></ul></div>                </div>
            </div>
            <div class="col-sm-4">
                <div class="box_content">
                    <div class="box_page">
    <div class="fb-page" data-href="https://www.facebook.com/nhakhoaquoctewinsmile" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
</div>                </div>
            </div>
        </div>
    </div>
</div>
<div class="box_copyright">
    <div class="container">
        Bản quyền thuộc về Win Smile. All Rights Reserved @2019        </div>
</div>
<div class="box_cart hidden" id="box_cart">
    <a href="/product/cart/"><i class="fa fa-shopping-cart"></i> <span class="cart_amount">0</span></a>
</div>
<div class="box_controls_mobile hidden-sm hidden-md hidden-lg" id="box_controls_mobile">
    <div class="wrap">
        <a href="javascript:;" class="btn_register">Đăng ký ngay</a>
        <a href="tel:0966688234" class="btn_hotline">Gọi tư vấn</a>
    </div>
</div>
<div class="box_popup_tuvan" id="box_popup_tuvan">
    <div class="wrap">
        <div class="cover"><img src="<?php echo e(('public/files/upload/default/images/he-thong/logo-white.png')); ?>"></div>
        <div class="content">
            <form name="frmTuvanPopup" id="frmTuvanPopup">
                <div class="form-group" id="input-name">
                    <input type="text" name="name" class="form-control" placeholder="Họ tên khách hàng *">
                </div>
                <div class="form-group" id="input-phone">
                    <input type="text" name="phone" class="form-control" placeholder="Số điện thoại *">
                </div>
                <div class="form-group" id="input-email">
                    <input type="text" name="email" class="form-control" placeholder="Email">
                </div>
                <div class="form-group" id="input-content">
                    <textarea type="text" name="content" class="form-control" placeholder="Nhu cầu tư vấn"></textarea>
                </div>
                <div class="form-group">
                    <button type="button" class="form-control btn_submit" onclick="javascript:formRegister('frmTuvanPopup');">Hoàn thành</button>
                </div>
                <div class="form-group">
                    <div class="hotline">Hotline tư vấn: <a href="tel:0966688234">0966 688 234</a></div>
                </div>
                <div class="form-group">
                    <div class="text">Đăng ký tư vấn miễn phí!</div>
                </div>
                <input type="hidden" name="form_id" value="1575130813q7ja36311m0f">
            </form>
        </div>
        <span class="close_popup"></span>
    </div>
</div>
   <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/fancybox/source/jquery.fancybox.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/fancybox/source/jquery.fancybox-thumbs.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/bxslider/jquery.bxslider.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/hover-dropdown.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/numeric.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/js/app.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/js/me.js?v=24112021014725')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
          App.init();
        });
    </script>

<script type="text/javascript">
    //<!--
        $('#menu_toggle').click(function() {
        let menu = '';
        $('.box_menuMain2').each(function() {
            menu += $(this).html();
        });
        let xhtml = '<div class="bg_menu_mobile" onclick="close_menu_mobile()"></div><div class="box_menuMobile">'+ menu +'</div>';
        $('body').append(xhtml);
    });

    function close_menu_mobile() {
        $('.bg_menu_mobile').remove();
        $('.box_menuMobile').remove();
    }

    $('.box_menuMain2>ul>li').each(function() {
        var level = 1;
        $('ul>li', this).each(function() {
            if($('ul', this).length > 0) {
                level = 2;
            }
        });
        $(this).addClass('level_' + level);
    });

    $(document).ready(function() {
        $('#box_menuMain .header .toggle').click(function() {
            var xhtmlMenu = $('#box_menuMain .menu').html();
            $('body').append('<div class="box_menuMobile">'+ xhtmlMenu +'</div>');
            $('body').append('<div class="bg_menu_mobile" onclick="close_menu_mobile()"></div>');
        });
    });

    //-->
</script>
<script type="text/javascript">
    //<!--
    	$(document).ready(function() {
	    $("#box_category ul li.seletced").parents("li").addClass("selected active");
		$("#box_category ul li.dropdown>a").click(function() {
		    $("li", $(this).parent().parent()).removeClass('active');
		    $($(this).parent()).addClass('active');
		    $(">li ul.children", $(this).parent().parent()).slideUp();
		    $('>ul.children:first', $(this).parent()).slideDown();
		});
	});

    //-->
</script>    <script>
    function addCart(id) {
        var number = 1;
        if($('input[name="number"]').size() > 0) {
            number = parseInt($('input[name="number"]').val());
        }
        $.ajax({
            type: "POST",
            url: '/product/add-cart/',
            data: {
                id: id,
                number: number
            },
            dataType: "json",
            cache: false,
            beforeSend: function() {
                $('body').append('<div class="submit_loading"></div>');
            },
            success: function(result){
                $('#myModal').remove();
                var xhtml = '<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">' +
                                '<div class="modal-dialog" role="document">' +
                                    '<div class="modal-content">' +
                                        '<div class="modal-header">' +
                                            '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                                            '<h4 class="modal-title" id="myModalLabel">Thông báo</h4>' +
                                        '</div>' +
                                        '<div class="modal-body">' +
                                            'Sản phẩm đã được thêm vào giỏ hàng thành công' +
                                        '</div>' +
                                        '<div class="modal-footer">' +
                                            '<button type="button" class="btn btn-default" data-dismiss="modal">Tiếp tục đặt hàng</button>' +
                                            '<a href="/product/cart/" class="btn btn-success">Xem giỏ hàng <b class="text-red">('+ result.total_amount +')</b></a>' +
                                        '</div>' +
                                    '</div>' +
                                '</div>' +
                            '</div>';

                $('.submit_loading').remove();
                $('body').append(xhtml);
                $('#myModal').modal('show');
                viewCart();
            }
        });
    }
</script>
</body>
</html><?php /**PATH C:\Users\cuong123\Desktop\New folder (2)\blog\resources\views/benhly.blade.php ENDPATH**/ ?>
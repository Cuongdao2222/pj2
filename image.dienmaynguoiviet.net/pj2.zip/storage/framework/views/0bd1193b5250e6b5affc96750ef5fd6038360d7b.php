<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
   <head>
      <title>Giao diện web mẫu, template website bán hàng đẹp | Sapo Web</title>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <meta name="description" content="Hơn 400 mẫu web bán hàng, template website bán hàng trực tuyến với giao diện thiết kế đẹp mắt, chuyên nghiệp và đa dạng ngành nghề. Miễn phí 7 ngày dùng thử!" />
      <meta name="keyword" content="" />
      <link rel="canonical" href="" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
      <meta property="og:image" content="<?php echo e(asset('website/Themes/Portal/Default/Styles/images/themes.sapo.vn.png')); ?>" />
      <meta property="og:image:secure_url" content="<?php echo e(asset('website/Themes/Portal/Default/Styles/images/themes.sapo.vn.png')); ?>" />
      <link href="<?php echo e(asset('website/Themes/Portal/Default/Styles/dist/index.min.css?v=637717276887806428')); ?>" rel="stylesheet" />
      <link href="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/dist/popup-register-default.min.css?v=5')); ?>" rel="stylesheet">
      <script src="<?php echo e(asset('website/Themes/Portal/Default/dist/script.js?v=94')); ?>"></script>
     
      <script src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/lib/selectize/selectize.min.js')); ?>"></script>
      <script src="<?php echo e(asset('website/Themes/Portal/Default/stylessv2/lib/intlTelInput/intlTelInput.min.js')); ?>"></script>
      <script src="/variable-trial.js?v=5" async></script>
      <script src="<?php echo e(asset('website/Themes/Portal/Default/Scripts/dist/popup-trial.js?v=5')); ?>" async></script>
      <script>
         $(function () {
             var nua = navigator.userAgent;
             var isAndroid = (nua.indexOf('Mozilla/5.0') > -1 && nua.indexOf('Android ') > -1 && nua.indexOf('AppleWebKit') > -1 && nua.indexOf('Chrome') === -1);
             if (isAndroid) {
                 $('select.form-control').removeClass('form-control').css('width', '100%');
             }
         })
      </script>
      
      <meta name="google-site-verification" content="36MA7koplq0n5vJyJHZgYIfVdwHT2OyosVpdEqK7pJY" />
      <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
      <meta property="og:url" />
      <meta property="og:type" content="website" />
      <meta property="og:title" content="Giao diện web mẫu, template website b&#225;n h&#224;ng đẹp | Sapo Web" />
      <meta property="og:description" content="Hơn 400 mẫu web b&#225;n h&#224;ng, template website b&#225;n h&#224;ng trực tuyến với giao diện thiết kế đẹp mắt, chuy&#234;n nghiệp v&#224; đa dạng ng&#224;nh nghề. Miễn ph&#237; 7 ng&#224;y d&#249;ng thử!" />
      <script type="text/javascript">
         setTimeout(function () {
             var a = document.createElement("script");
             var b = document.getElementsByTagName("script")[0];
             a.src = document.location.protocol + "//script.crazyegg.com/pages/scripts/0041/5407.js?" + Math.floor(new Date().getTime() / 3600000);
             a.async = true; a.type = "text/javascript"; b.parentNode.insertBefore(a, b)
         }, 1);
      </script>
   </head>
   <body>
      <!-- Begin Inspectlet Embed Code -->
      <script type="text/javascript" id="inspectletjs">
         window.__insp = window.__insp || [];
         __insp.push(['wid', 950882958]);
         (function () {
             function ldinsp() { if (typeof window.__inspld != "undefined") return; window.__inspld = 1; var insp = document.createElement('script'); insp.type = 'text/javascript'; insp.async = true; insp.id = "inspsync"; insp.src = ('https:' == document.location.protocol ? 'https' : 'http') + '://cdn.inspectlet.com/inspectlet.js'; var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(insp, x); };
             setTimeout(ldinsp, 500); document.readyState != "complete" ? (window.attachEvent ? window.attachEvent('onload', ldinsp) : window.addEventListener('load', ldinsp, false)) : ldinsp();
         })();
      </script>
      <!-- End Inspectlet Embed Code -->
      <!-- Google Tag Manager -->
      <noscript>
         <iframe src="//www.googletagmanager.com/ns.html?id=GTM-WM8XKV"
            height="0" width="0" style="display:none;visibility:hidden"></iframe>
      </noscript>
      <script>
         (function (w, d, s, l, i) {
             w[l] = w[l] || []; w[l].push({
                 'gtm.start':
                 new Date().getTime(), event: 'gtm.js'
             }); var f = d.getElementsByTagName(s)[0],
             j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
             '//www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
         })(window, document, 'script', 'dataLayer', 'GTM-WM8XKV');
      </script>
      <!-- End Google Tag Manager -->
      <div id="wrapper" class="default-wrapper">
         <div id="header" class="WEB active-child header">
            <div class="main-header d-flex align-items-center flex-wrap">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-2 col-8 d-flex align-items-center">
                        <a id="logo" class="main-logo d-xl-block d-none" href="/">
                        <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/logo/Sapo-logo.svg?v=202111160408')); ?>" alt="Sapo logo" />
                        </a>
                        <a class="main-logo d-block d-xl-none" href="/thiet-ke-website-ban-hang.html?utm_campaign=cpn%3Athemes_Web-plm%3Aheader&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm%3Atext_link-km%3A-sz%3A&utm_term=&campaign=header_theme_sapo">
                        <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/logo/SapoWeb-logo.svg?v=202111160408')); ?>" alt="Sapo logo" />
                        </a>
                     </div>
                     <!--<div class="col-xl-10 col-4 d-flex justify-content-end">-->
                     <!--   <ul class="main-menu d-none d-xl-flex align-items-center">-->
                     <!--      <li class="hasChild">-->
                     <!--         <a href="javascript:;">Sản phẩm <i class="fa fa-angle-down"></i></a>-->
                     <!--         <ul class="childMenu product">-->
                     <!--            <li>-->
                     <!--               <a href="/phan-mem-quan-ly-ban-hang.html?utm_campaign=cpn:themes_pos-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-pos"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo POS</strong>-->
                     <!--                     <p>Phần mềm quản lý bán hàng tốt nhất cho cửa hàng & bán online</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/phan-mem-quan-ly-nha-hang.html?utm_campaign=cpn:themes_fnb-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-fnb"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo FnB</strong>-->
                     <!--                     <p>Phần mềm quản lý nhà hàng, quán cafe toàn diện</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/quan-ly-ban-hang-online.html?utm_campaign=cpn:themes_go-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-go"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo GO</strong>-->
                     <!--                     <p>Quản lý bán hàng online dành cho người bán hàng trên Sàn và Facebook</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/thiet-ke-website-ban-hang.html?utm_campaign=cpn:themes_web-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-web"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo Web</strong>-->
                     <!--                     <p>Giải pháp thiết kế website bán hàng chuyên nghiệp</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/omnichannel.html?utm_campaign=cpn:themes_omni-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-omni"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo Omnichannel</strong>-->
                     <!--                     <p>Giải pháp quản lý và bán hàng đa kênh từ Online đến Offline</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/ung-dung-so-ghi-no-va-ban-hang-online.html?utm_campaign=cpn:themes_enterprise-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-365"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo 365</strong>-->
                     <!--                     <p>Ứng dụng sổ ghi nợ và bán hàng <br />online miễn phí</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/phan-mem-crm-va-marketing-automation.html?utm_campaign=cpn:themes_crm-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-hub"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo Hub</strong>-->
                     <!--                     <p>Phần mềm CRM 4.0 và Marketing Automation</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/enterprise?utm_campaign=cpn:themes_enterprise-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-enterprise"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo Enterprise</strong>-->
                     <!--                     <p>Giải pháp quản lý bán hàng và phát triển thương hiệu cho doanh nghiệp lớn</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--         </ul>-->
                     <!--      </li>-->
                     <!--      <li class="hasChild express-fin">-->
                     <!--         <a href="javascript:;">Tiện ích <i class="fa fa-angle-down"></i></a>-->
                     <!--         <ul class="childMenu product two-line">-->
                     <!--            <li>-->
                     <!--               <a href="/cong-van-chuyen-sapo-express.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-express"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo Express</strong>-->
                     <!--                     <p>Giải pháp tối ưu vận hành và chi phí chuyển phát</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/sapo-fin.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" class="d-flex align-item-start">-->
                     <!--                  <i class="icon sapo-fin"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo Fin</strong>-->
                     <!--                     <p>Giải pháp tiên phong - Vay vốn tin cậy cho nhà bán hàng</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/sapo-market.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">-->
                     <!--                  <i class="icon sapo-markets"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo Market</strong>-->
                     <!--                     <p>Đầu mối nhập hàng giá tốt cho các tiệm tạp hóa, siêu thị mini</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--            <li>-->
                     <!--               <a href="/sapo-pay.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">-->
                     <!--                  <i class="icon sapo-pays"></i>-->
                     <!--                  <div>-->
                     <!--                     <strong>Sapo Pay</strong>-->
                     <!--                     <p>Giải pháp thanh toán không tiền mặt đa kênh</p>-->
                     <!--                  </div>-->
                     <!--               </a>-->
                     <!--            </li>-->
                     <!--         </ul>-->
                     <!--      </li>-->
                     <!--      <li><a href="/blog/?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Blog</a></li>-->
                     <!--      <li><a href="https://support.sapo.vn/sapo-web/?utm_campaign=cpn:themes_Web-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Trợ giúp</a></li>-->
                     <!--      <li class="hasChild">-->
                     <!--         <a href="javascript:;">Thêm <i class="fa fa-angle-down"></i></a>-->
                     <!--         <ul class="childMenu other">-->
                     <!--            <li><a href="/ve-chung-toi.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Về chúng tôi</a></li>-->
                     <!--            <li><a href="/sapo-la-gi.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Sapo là gì?</a></li>-->
                     <!--            <li><a href="https://shop.sapo.vn/?utm_campaign=cpn%3Athemes_shop-plm%3Aheader&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm%3Atext_link-km%3A-sz%3A&utm_term=&campaign=header_theme_sapo" target="_blank" rel="noopener">Thiết bị bán hàng</a></li>-->
                     <!--            <li class="hasChildLink">-->
                     <!--               <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-pc">Giới thiệu khách hàng</a>-->
                     <!--               <ul class="childMenu chilMenuRight panel-collapse collapse" id="nav-bottom-child-pc">-->
                     <!--                  <li><a href="/sapo-partner.html">Cộng tác viên</a></li>-->
                     <!--                  <li><a href="/sapo-affiliate.html">Khách hàng cũ</a></li>-->
                     <!--               </ul>-->
                     <!--            </li>-->
                     <!--            <li><a href="/bao-chi-noi-ve-sapo.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Báo chí nói về Sapo</a></li>-->
                     <!--            <li><a href="/blog/tin-su-kien-sapo/?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Sapo updates</a></li>-->
                     <!--            <li><a href="//tuyendung.sapo.vn/?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Tuyển dụng</a></li>-->
                     <!--            <li><a href="/lien-he.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Liên hệ</a></li>-->
                     <!--         </ul>-->
                     <!--      </li>-->
                     <!--   </ul>-->
                     <!--   <ul class="d-none d-xl-flex justify-content-end">-->
                     <!--      <li class="login d-none d-lg-inline-block">-->
                     <!--         <a href="/dang-nhap-kenh-ban-hang.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Đăng nhập</a>-->
                     <!--      </li>-->
                     <!--   </ul>-->
                     <!--   <a href="javascript:;" class="d-flex align-items-center d-xl-none btn-menu" onclick="openMenu();" aria-hidden="true">-->
                     <!--   <i class="ti-menu"></i>-->
                     <!--   </a>-->
                     <!--</div>-->
                  </div>
               </div>
            </div>
            <div class="extra-header d-none d-xl-block">
               <div class="container d-xl-flex align-items-center justify-content-between">
                 
                  <div class="menu justify-content-between">
                     <ul class="d-xl-flex align-items-center">
                        
                     </ul>
                     <a href="javascript:;" class="btn-registration">Dùng thử</a>
                  </div>
               </div>
            </div>
         </div>
         <div class="menu-mobile WEB">
            <div class="logo-mobile">
               <a href="/thiet-ke-website-ban-hang.html?utm_campaign=cpn%3Athemes_Web-plm%3Aheader&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm%3Atext_link-km%3A-sz%3A&utm_term=&campaign=header_theme_sapo">
               <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/logo/SapoWeb-logo.svg?v=202111160408')); ?>" alt="Sapo logo" />
               </a>
               <a href="javascript:;" class="btn-close-menu" onclick="closeMenu();" aria-hidden="true">
               <i class="ti-close"></i>
               </a>
            </div>
            <div class="box-scroll">
               <ul class="nav">
                  <li><a href="/tinh-nang-noi-bat-website.html?utm_campaign=cpn:themes_Web-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Tính năng</a></li>
                  <li><a href="/bang-gia-sapo-web.html?utm_campaign=cpn:themes_Web-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Bảng giá <span class="badge d-none">HOT</span></a></li>
                  <li class="active"><a href="/?utm_campaign=cpn:themes_Web-plm:header&utm_source=themes.sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Kho giao diện</a></li>
                  <li><a href="https://apps.sapo.vn/?utm_campaign=cpn:themes_Web-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Kho ứng dụng</a></li>
                  <li><a href="/website-tham-khao.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Khách hàng</a></li>
                  <li class="trial">
                     <a href="javascript:;" class="btn-registration" onclick="showModalTrial(this, 2, false)"><span>Dùng thử</span></a>
                  </li>
               </ul>
               <ul class="nav nav-bottom">
                  <li class="show-sub">
                     <a data-toggle="collapse" href="#nav-bottom-child-1">
                     Sản phẩm khác
                     </a>
                     <div id="nav-bottom-child-1" class="panel-collapse collapse">
                        <ul class="sub-menu">
                           <li>
                              <a href="/phan-mem-quan-ly-ban-hang.html?utm_campaign=cpn:themes_pos-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo POS</strong>
                              <span>Phần mềm quản lý bán hàng</span>
                              </a>
                           </li>
                           <li>
                              <a href="/phan-mem-quan-ly-nha-hang.html?utm_campaign=cpn:themes_fnb-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo FnB</strong>
                              <span>Phần mềm quản lý nhà hàng</span>
                              </a>
                           </li>
                           <li>
                              <a href="/quan-ly-ban-hang-online.html?utm_campaign=cpn:themes_go-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo GO</strong>
                              <span>Quản lý bán hàng online</span>
                              </a>
                           </li>
                           <li>
                              <a href="/omnichannel.html?utm_campaign=cpn:themes_omni-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo Omnichannel</strong>
                              <span>Giải pháp quản lý bán hàng đa kênh</span>
                              </a>
                           </li>
                           <li>
                              <a href="/ung-dung-so-ghi-no-va-ban-hang-online.html?utm_campaign=cpn:themes_enterprise-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo 365</strong>
                              <span>Ứng dụng sổ ghi nợ và bán hàng <br />online miễn phí</span>
                              </a>
                           </li>
                           <li>
                              <a href="/phan-mem-crm-va-marketing-automation.html?utm_campaign=cpn:themes_crm-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo Hub</strong>
                              <span>Phần mềm CRM 4.0 và Marketing Automation</span>
                              </a>
                           </li>
                           <li>
                              <a href="/enterprise?utm_campaign=cpn:themes_enterprise-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo Enterprise</strong>
                              <span>Quản lý và phát triển thương hiệu <br />cho doanh nghiệp lớn</span>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </li>
                  <li class="show-sub">
                     <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-1b">
                     Tiện ích
                     </a>
                     <div id="nav-bottom-child-1b" class="panel-collapse collapse">
                        <ul class="sub-menu">
                           <li>
                              <a href="/cong-van-chuyen-sapo-express.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo Express</strong>
                              <span>Giải pháp tối ưu vận chuyển</span>
                              </a>
                           </li>
                           <li>
                              <a href="/sapo-fin.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo Fin</strong>
                              <span>Giải pháp tiên phong - Vay vốn tin cậy cho nhà bán hàng</span>
                              </a>
                           </li>
                           <li>
                              <a href="/sapo-market.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo Market</strong>
                              <span>Đầu mối nhập hàng giá tốt cho các tiệm tạp hóa, siêu thị mini</span>
                              </a>
                           </li>
                           <li>
                              <a href="/sapo-pay.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">
                              <strong>Sapo Pay</strong>
                              <span>Giải pháp thanh toán không tiền mặt đa kênh</span>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </li>
                  <li><a href="/blog/?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Blog</a></li>
                  <li><a href="https://support.sapo.vn/sapo-web/?utm_campaign=cpn:themes_Web-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Trợ giúp</a></li>
                  <li class="show-sub">
                     <a data-toggle="collapse" href="#nav-bottom-child-2">
                     Thêm
                     </a>
                     <div id="nav-bottom-child-2" class="panel-collapse collapse">
                        <ul class="sub-menu">
                           <li><a href="/ve-chung-toi.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Về chúng tôi</a></li>
                           <li><a href="/sapo-la-gi.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Sapo là gì?</a></li>
                           <li><a href="https://shop.sapo.vn/?utm_campaign=cpn%3Athemes_shop-plm%3Aheader&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm%3Atext_link-km%3A-sz%3A&utm_term=&campaign=header_theme_sapo" target="_blank" rel="noopener">Thiết bị bán hàng</a></li>
                           <li class="show-sub">
                              <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-3">Giới thiệu khách hàng </a>
                              <div id="nav-bottom-child-3" class="panel-collapse collapse">
                                 <ul class="sub-menu" style="margin-bottom:15px">
                                    <li><a href="/sapo-partner.html">Cộng tác viên</a></li>
                                    <li><a href="/sapo-affiliate.html">Khách hàng cũ</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li><a href="/bao-chi-noi-ve-sapo.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Báo chí nói về Sapo</a></li>
                           <li><a href="/blog/tin-su-kien-sapo/?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Sapo updates</a></li>
                           <li><a href="//tuyendung.sapo.vn/?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo" target="_blank">Tuyển dụng</a></li>
                           <li><a href="/lien-he.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Liên hệ</a></li>
                        </ul>
                     </div>
                  </li>
                  <li>
                     <a href="/dang-nhap-kenh-ban-hang.html?utm_campaign=cpn:themes-plm:header&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=header_theme_sapo">Đăng nhập</a>
                  </li>
                  <li class="home">
                     <a href="/">Sapo.vn</a>
                  </li>
               </ul>
            </div>
         </div>
         <div class="overlay-menu" onclick="closeMenu()"></div>
         <script type="text/javascript">
            function openMenu() {
                $('body').css('overflow', 'hidden');
                $('.overlay-menu').fadeIn(300);
                $('.menu-mobile').addClass('show');
            }
            function closeMenu() {
                $('body').css('overflow', '');
                $('.overlay-menu').fadeOut(300);
                $('.menu-mobile').removeClass('show');
            }
            $(window).on('load', function () {
                var itemTop = $('.header .main-header').offset().top + $('.header .main-header').height() + $('.header .extra-header').height();
                if ($(window).scrollTop() > itemTop) {
                    $('.header .extra-header').addClass('sticky');
                }
                $(window).on('scroll', function () {
                    if ($(this).scrollTop() > itemTop) {
                        $('.header .extra-header').addClass('sticky');
                    } else {
                        $('.header .extra-header').removeClass('sticky');
                    }
                });
            });
         </script>
         <div class="index-container">
            <div class="banner">
               <div class="index-title login-box">
                  <div class="container">
                     <h1>400+ template website <br class="d-block d-md-none"/>bán hàng cực đẹp</h1>
                     <p>Giao diện web được thiết kế chuyên nghiệp, chuẩn SEO & phù hợp với mọi ngành nghề</p>
                  </div>
               </div>
               <div class="feature-themes">
                  <div class="container">
                     <div class="slide-feature">
                        <div class="swiper-container">
                           <div class="swiper-wrapper">
                              <div class="swiper-slide feature-item">
                                 <div class="row">
                                    <div class="col-lg-8 col-md-7 col-xs-12 feature-image">
                                       <div class="image-desktop">
                                          <a href="/demo/ega-market" class="action-preview-theme" data-url="https://ega-market.mysapo.net">
                                          <img src="https://bizwebtheme.dktcdn.net/themes/72/themefeatures/017db08a385171255ac38857a91c89fc.jpg?1635742273667" alt="Ega market" />
                                          </a>
                                       </div>
                                       <div class="image-mobile d-none d-md-block">
                                          <a href="/demo/ega-market?mobile=true" class="action-preview-theme" data-url="https://ega-market.mysapo.net">
                                          <img src="https://bizwebtheme.dktcdn.net/themes/72/themefeatures/b9fe755d830ab5844be4a935f6310ea4.jpg?1635742273667" alt="Ega market" />
                                          </a>
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5 col-12 feature-info">
                                       <div class="title">
                                          Giao diện website
                                          <span>Ega market</span>
                                       </div>
                                       <div class="other-info clearfix">
                                          <span class="price has-compare">
                                          <b>1,520,000 <sub>đ</sub></b>
                                          / <i>1,900,000 <sub>đ</sub></i>
                                          </span>
                                       </div>
                                       <div class="button">
                                          <a class="preview action-preview-theme btn-registration" href="/demo/ega-market" data-url="https://ega-market.mysapo.net">Xem thử</a>
                                          <a class="view-detail" href="/ega-market">Chi tiết</a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="swiper-slide feature-item">
                                 <div class="row">
                                    <div class="col-lg-8 col-md-7 col-xs-12 feature-image">
                                       <div class="image-desktop">
                                          <a href="/demo/pocomart" class="action-preview-theme" data-url="https://pocomart.mysapo.net/">
                                          <img src="https://bizwebtheme.dktcdn.net/themes/1080/themefeatures/2a6fc6923e6616bd40c85ae9c491bcd4.jpeg?1635742316977" alt="Pocomart" />
                                          </a>
                                       </div>
                                       <div class="image-mobile d-none d-md-block">
                                          <a href="/demo/pocomart?mobile=true" class="action-preview-theme" data-url="https://pocomart.mysapo.net/">
                                          <img src="https://bizwebtheme.dktcdn.net/themes/1080/themefeatures/88acf7b6c6d4727bd3ff3b84606b13f3.jpeg?1635742316977" alt="Pocomart" />
                                          </a>
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5 col-12 feature-info">
                                       <div class="title">
                                          Giao diện website
                                          <span>Pocomart</span>
                                       </div>
                                       <div class="other-info clearfix">
                                          <span class="price has-compare">
                                          <b>1,360,000 <sub>đ</sub></b>
                                          / <i>1,700,000 <sub>đ</sub></i>
                                          </span>
                                       </div>
                                       <div class="button">
                                          <a class="preview action-preview-theme btn-registration" href="/demo/pocomart" data-url="https://pocomart.mysapo.net/">Xem thử</a>
                                          <a class="view-detail" href="/pocomart">Chi tiết</a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="swiper-slide feature-item">
                                 <div class="row">
                                    <div class="col-lg-8 col-md-7 col-xs-12 feature-image">
                                       <div class="image-desktop">
                                          <a href="/demo/evo-mobile" class="action-preview-theme" data-url="https://evo-mobile.mysapo.net">
                                          <img src="https://bizwebtheme.dktcdn.net/themes/1082/themefeatures/96c8e43b9da73256605529e274e374a5.jpeg?1635742255290" alt="Evo Mobile" />
                                          </a>
                                       </div>
                                       <div class="image-mobile d-none d-md-block">
                                          <a href="/demo/evo-mobile?mobile=true" class="action-preview-theme" data-url="https://evo-mobile.mysapo.net">
                                          <img src="https://bizwebtheme.dktcdn.net/themes/1082/themefeatures/255e19f7255a36432108d441cd0c5c9b.jpeg?1635742255290" alt="Evo Mobile" />
                                          </a>
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-5 col-12 feature-info">
                                       <div class="title">
                                          Giao diện website
                                          <span>Evo Mobile</span>
                                       </div>
                                       <div class="other-info clearfix">
                                          <span class="price ">
                                          <b>1,500,000 <sub>đ</sub></b>
                                          </span>
                                       </div>
                                       <div class="button">
                                          <a class="preview action-preview-theme btn-registration" href="/demo/evo-mobile" data-url="https://evo-mobile.mysapo.net">Xem thử</a>
                                          <a class="view-detail" href="/evo-mobile">Chi tiết</a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="swiper-button-prev"></div>
                           <div class="swiper-button-next"></div>
                        </div>
                     </div>
                  </div>
                  <script type="text/javascript">
                     $(function () {
                         var featureSlide = new Swiper('.slide-feature .swiper-container', {
                             navigation: {
                                 nextEl: '.slide-feature .swiper-button-next',
                                 prevEl: '.slide-feature .swiper-button-prev',
                             },
                             slidesPerView: 1,
                             paginationClickable: true,
                             preventClicks: false,
                             preventClicksPropagation: false,
                             loop: true,
                             autoplay: {
                                 delay: 4000,
                                 disableOnInteraction: false,
                             },
                             effect: 'fade',
                             fade: {
                                 crossFade: true
                             }
                         });
                     });
                  </script>
               </div>
            </div>
            <div class="menu-toolbar">
               <div class="container">
                  <div class="row filter-desktop d-none d-md-flex">
                     <div class="col-lg-8 col-md-11 menu">
                        <ul>
                           <li class="all-theme">
                              <a href="/collections/tat-ca">
                                 <svg xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink"
                                    width="22px" height="22px">
                                    <path fill-rule="evenodd" fill="rgb(18, 210, 136)"
                                       d="M12.000,22.000 L12.000,12.000 L22.000,12.000 L22.000,22.000 L12.000,22.000 ZM12.000,-0.000 L22.000,-0.000 L22.000,10.000 L12.000,10.000 L12.000,-0.000 ZM-0.000,12.000 L10.000,12.000 L10.000,22.000 L-0.000,22.000 L-0.000,12.000 ZM-0.000,-0.000 L10.000,-0.000 L10.000,10.000 L-0.000,10.000 L-0.000,-0.000 Z" />
                                 </svg>
                                 Tất cả
                              </a>
                           </li>
                           <li class="free-theme">
                              <a href="/collections/theme-mien-phi"><img src="<?php echo e(asset('website/Themes/Portal/Default/Styles/images/index/new/free-icon.png')); ?>" alt="Miễn phí" />Miễn phí</a>
                           </li>
                           <li class="promotion-theme">
                              <a href="/collections/khuyen-mai"><img src="<?php echo e(asset('website/Themes/Portal/Default/Styles/images/index/new/khuyenmai-icon.png')); ?>" alt="Khuyễn mãi" />Khuyến mãi</a>
                              <span class="badge ">HOT</span>
                           </li>
                           <li class="has-child sale-theme">
                              <a href="javascript:;"><img src="<?php echo e(asset('website/Themes/Portal/Default/Styles/images/index/new/banhang-icon.png')); ?>" alt="Bán hàng" />Bán hàng<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                              <ul class="sub-menu clearfix">
                                 <li>
                                    <a href="/collections/website-thoi-trang">
                                    <span>Thời trang - Trang sức</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-thuc-pham">
                                    <span>Thực phẩm - Nhà hàng</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-do-gia-dung">
                                    <span>Đồ gia dụng - Sinh hoạt</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-noi-that">
                                    <span>Nội thất - Trang trí</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-van-phong-pham">
                                    <span>Sách - Văn phòng phẩm</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-qua-tang">
                                    <span>Thủ công - Mỹ nghệ - Quà tặng</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-cong-nghe">
                                    <span>Công nghệ - Kỹ thuật số</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-oto-xe-may">
                                    <span>Ô tô - Xe máy</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-thiet-bi-dien">
                                    <span>Thiết bị điện</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-dich-vu">
                                    <span>Thể thao - Dịch vụ</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/khac">
                                    <span>Khác</span>
                                    </a>
                                 </li>
                              </ul>
                           </li>
                           <li class="has-child company-theme">
                              <a href="javascript:;"><img src="<?php echo e(asset('website/Themes/Portal/Default/Styles/images/index/new/congty-icon.png')); ?>" alt="Công ty" />Công ty<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                              <ul class="sub-menu">
                                 <li>
                                    <a href="/collections/website-nha-hang-khach-san">
                                    <span>Khách sạn - Du lịch</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-bat-dong-san">
                                    <span>Bất động sản - Xây dựng</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="/collections/website-doanh-nghiep">
                                    <span>Doanh nghiệp</span>
                                    </a>
                                 </li>
                              </ul>
                           </li>
                           <li class="d-inline-block d-md-none">
                              <form action="/search">
                                 <input type="text" placeholder="Tìm kiếm giao diện ..." name="key" class="search-key" />
                                 <button><i class="fa fa-search" aria-hidden="true"></i></button>
                              </form>
                           </li>
                        </ul>
                     </div>
                     <div class="col-lg-4 col-md-1 d-none d-md-flex justify-content-end">
                        <a class="show-search-tablet d-none d-md-block d-lg-none visible-sm" href="javascript:;">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        <i class="fa fa-times" style="display: none;" aria-hidden="true"></i>
                        </a>
                        <div class="filter-form">
                           <div class="sort-theme d-none d-lg-block">
                              <a href="javascript:;">
                                 <svg xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink"
                                    width="29px" height="27px">
                                    <defs>
                                       <filter id="Filter_0">
                                          <feFlood flood-color="rgb(18, 210, 136)" flood-opacity="1" result="floodOut" />
                                          <feComposite operator="atop" in="floodOut" in2="SourceGraphic" result="compOut" />
                                          <feBlend mode="normal" in="compOut" in2="SourceGraphic" />
                                       </filter>
                                    </defs>
                                    <g filter="url(#Filter_0)">
                                       <path fill-rule="evenodd" fill="rgb(159, 159, 159)"
                                          d="M11.500,3.000 L28.500,3.000 C28.776,3.000 29.000,3.224 29.000,3.500 C29.000,3.776 28.776,4.000 28.500,4.000 L11.500,4.000 C11.224,4.000 11.000,3.776 11.000,3.500 C11.000,3.224 11.224,3.000 11.500,3.000 Z" />
                                       <path fill-rule="evenodd" fill="rgb(159, 159, 159)"
                                          d="M3.500,-0.000 C5.433,-0.000 7.000,1.567 7.000,3.500 C7.000,5.433 5.433,7.000 3.500,7.000 C1.567,7.000 -0.000,5.433 -0.000,3.500 C-0.000,1.567 1.567,-0.000 3.500,-0.000 Z" />
                                       <path fill-rule="evenodd" fill="rgb(159, 159, 159)"
                                          d="M11.500,13.000 L28.500,13.000 C28.776,13.000 29.000,13.224 29.000,13.500 C29.000,13.776 28.776,14.000 28.500,14.000 L11.500,14.000 C11.224,14.000 11.000,13.776 11.000,13.500 C11.000,13.224 11.224,13.000 11.500,13.000 Z" />
                                       <path fill-rule="evenodd" fill="rgb(159, 159, 159)"
                                          d="M3.500,10.000 C5.433,10.000 7.000,11.567 7.000,13.500 C7.000,15.433 5.433,17.000 3.500,17.000 C1.567,17.000 -0.000,15.433 -0.000,13.500 C-0.000,11.567 1.567,10.000 3.500,10.000 Z" />
                                       <path fill-rule="evenodd" fill="rgb(159, 159, 159)"
                                          d="M11.500,23.000 L28.500,23.000 C28.776,23.000 29.000,23.224 29.000,23.500 C29.000,23.776 28.776,24.000 28.500,24.000 L11.500,24.000 C11.224,24.000 11.000,23.776 11.000,23.500 C11.000,23.224 11.224,23.000 11.500,23.000 Z" />
                                       <path fill-rule="evenodd" fill="rgb(159, 159, 159)"
                                          d="M3.500,20.000 C5.433,20.000 7.000,21.567 7.000,23.500 C7.000,25.433 5.433,27.000 3.500,27.000 C1.567,27.000 -0.000,25.433 -0.000,23.500 C-0.000,21.567 1.567,20.000 3.500,20.000 Z" />
                                    </g>
                                 </svg>
                              </a>
                              <div class="sort-by">
                                 <ul>
                                    <li data-sort="id" class="active">Mới nhất</li>
                                    <li data-sort="price-asc">Giá từ thấp đến cao</li>
                                    <li data-sort="price-desc">Giá từ cao đến đến thấp</li>
                                    <li data-sort="alpha-asc">Tên A - Z</li>
                                    <li data-sort="alpha-desc">Tên Z - A</li>
                                    <li data-sort="discount-asc">Bán chạy nhất</li>
                                 </ul>
                              </div>
                           </div>
                           <form action="/search">
                              <input type="text" placeholder="Bạn tìm giao diện gì?" name="key" class="search-key" />
                              <button><i class="fa fa-search" aria-hidden="true"></i></button>
                           </form>
                        </div>
                     </div>
                  </div>
                  <div class="row filter-mobile d-flex d-md-none">
                     <div class="col-12">
                        <div class="title-filter-mobile">Lọc theo...</div>
                        <a class="show-search-form" href="javascript:;">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        <i class="fa fa-times" style="display: none;" aria-hidden="true"></i>
                        </a>
                        <div class="search-form-mobile">
                           <form action="/search">
                              <input type="text" placeholder="Tìm kiếm giao diện ..." name="key" class="search-key" />
                              <button><i class="fa fa-search" aria-hidden="true"></i></button>
                           </form>
                        </div>
                        <div class="filter-by">
                           <ul>
                              <li class="all-theme"><a href="/collections/tat-ca">Tất cả</a></li>
                              <li class="free-theme"><a href="/collections/theme-mien-phi">Miễn phí</a></li>
                              <li class="promotion-theme"><a href="/collections/khuyen-mai">Khuyến mãi</a></li>
                              <li class="has-child sale-theme">
                                 <a>Ngành nghề</a>
                                 <i class="fa fa-angle-down" aria-hidden="true"></i>
                                 <ul class="sub-menu clearfix">
                                    <li>
                                       <a href="/collections/website-thoi-trang">
                                       <span>Thời trang - Trang sức</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-thuc-pham">
                                       <span>Thực phẩm - Nhà hàng</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-do-gia-dung">
                                       <span>Đồ gia dụng - Sinh hoạt</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-noi-that">
                                       <span>Nội thất - Trang trí</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-van-phong-pham">
                                       <span>Sách - Văn phòng phẩm</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-qua-tang">
                                       <span>Thủ công - Mỹ nghệ - Quà tặng</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-cong-nghe">
                                       <span>Công nghệ - Kỹ thuật số</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-oto-xe-may">
                                       <span>Ô tô - Xe máy</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-thiet-bi-dien">
                                       <span>Thiết bị điện</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-dich-vu">
                                       <span>Thể thao - Dịch vụ</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/khac">
                                       <span>Khác</span>
                                       </a>
                                    </li>
                                 </ul>
                              </li>
                              <li class="has-child company-theme">
                                 <a href="javascript:;"><img src="<?php echo e(asset('website/Themes/Portal/Default/Styles/images/index/new/congty-icon.png')); ?>" alt="Công ty" />Công ty<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                 <ul class="sub-menu">
                                    <li>
                                       <a href="/collections/website-nha-hang-khach-san">
                                       <span>Khách sạn - Du lịch</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-bat-dong-san">
                                       <span>Bất động sản - Xây dựng</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="/collections/website-doanh-nghiep">
                                       <span>Doanh nghiệp</span>
                                       </a>
                                    </li>
                                 </ul>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <script type="text/javascript">
                  $(function () {
                      $(".show-search-form").click(function () {
                          $(".search-form-mobile").toggle();
                          $(".show-search-form .fa-search").toggle();
                          $(".show-search-form .fa-times").toggle();
                      });
                  
                      $(".show-search-tablet").click(function () {
                          $(this).parent().find(".filter-form").toggle();
                          $(".show-search-tablet .fa-search").toggle();
                          $(".show-search-tablet .fa-times").toggle();
                      });
                  
                      $(".title-filter-mobile").click(function () {
                          $(".filter-mobile .filter-by").toggle();
                      });
                  
                      $(".filter-mobile .filter-by .has-child").click(function () {
                          $(this).find(".sub-menu").toggle();
                      });
                  
                      var price = '';
                      var discount = '';
                      var collectionId = 0;
                      if (price != null && price != '') {
                          switch (price) {
                              case 'all':
                                  $(".all-theme").addClass("active");
                                  break;
                              case 'free':
                                  $(".free-theme").addClass("active");
                                  break;
                              default:
                                  break;
                          }
                      }
                  
                      if (discount != null && discount != '') {
                          switch (discount) {
                              case 'show':
                                  $(".promotion-theme").addClass("active");
                                  break;
                              default:
                                  break;
                          }
                      }
                      if (collectionId != null && collectionId > 0) {
                          switch (collectionId) {
                              case 23:
                              case 24:
                              case 28:
                              case 29:
                              case 30:
                              case 31:
                              case 32:
                              case 33:
                              case 35:
                              case 36:
                              case 39:
                                  $(".sale-theme").addClass("active");
                                  break;
                              default:
                                  $(".company-theme").addClass("active");
                                  break;
                          }
                      }
                  
                      var sort = getParameterByName("sort");
                      $(".sort-by li").removeClass("active");
                      $(".sort-by li[data-sort='" + sort + "']").addClass("active");
                  
                      $(".sort-by li").click(function () {
                          $(".sort-by li").removeClass("active");
                          $(this).addClass("active");
                          var sort = $(this).attr("data-sort");
                          var queryString = window.location.search;
                          var url = window.location.pathname;
                          url = url + queryString;
                          url = setParameter(url, "sort", sort);
                          window.location.href = url;
                      });
                  
                      var key = getParameterByName("key");
                      if (key != "") {
                          $(".filter-form input[name='key']").val(key);
                      }
                  });
               </script>
            </div>
            <div class="favorite-themes">
               <div class="container">
                  <h2>Top giao diện web</h2>
                  <p class="desc">Những mẫu <a href="/thiet-ke-website-ban-hang.html" style='color: #12d087;' target="_blank">thiết kế web bán hàng</a> được nhiều người dùng nhất</p>
                  <a class="more-theme" href="/website-noi-bat" title="Xem thêm">Xem thêm</a>
                  <div class="row">
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3600/themestores/39b701dba1785f1ef43acafaef6309b8.png?1635820731687" alt="Mew Furniture" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/mew-furniture" class="view-demo action-preview-theme btn-registration" data-url="https://mew-furniture.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/mew-furniture" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/mew-furniture" class="title">Mew Furniture</a></h3>
                              <span class="price has-compare">
                              <b>1,160,000 <sub>đ</sub></b>
                              / <i>1,450,000 <sub>đ</sub></i>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3627/themestores/47b7a931947eeb1145091865ecbd35f9.png?1635735243627" alt="OH! B&#225;ch h&#243;a" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/oh-bach-hoa" class="view-demo action-preview-theme btn-registration" data-url="https://oh-bach-hoa.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/oh-bach-hoa" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/oh-bach-hoa" class="title">OH! B&#225;ch h&#243;a</a></h3>
                              <span class="price has-compare">
                              <b>1,040,000 <sub>đ</sub></b>
                              / <i>1,300,000 <sub>đ</sub></i>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3660/themestores/867c14cdb8190af756eb95fb8d0444c4.jpg?1636425569433" alt="Pocomart" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/pocomart" class="view-demo action-preview-theme btn-registration" data-url="https://pocomart.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/pocomart" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/pocomart" class="title">Pocomart</a></h3>
                              <span class="price has-compare">
                              <b>1,360,000 <sub>đ</sub></b>
                              / <i>1,700,000 <sub>đ</sub></i>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/2457/themestores/b43258e07499b40904e77fe663a0131c.jpg?1630657590017" alt="Ant Construction" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/ant-construction" class="view-demo action-preview-theme btn-registration" data-url="https://ant-construction.mysapo.net" target="_blank">Xem thử</a>
                                    <a href="/ant-construction" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/ant-construction" class="title">Ant Construction</a></h3>
                              <span class="price ">
                              <b>1,299,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/2458/themestores/654653a96d3aaf8a0a50cfebdba005a6.jpg?1636020724220" alt="MiniMart" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/minimart" class="view-demo action-preview-theme btn-registration" data-url="https://template-minimart.mysapo.net" target="_blank">Xem thử</a>
                                    <a href="/minimart" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/minimart" class="title">MiniMart</a></h3>
                              <span class="price ">
                              <b>1,300,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3578/themestores/27acc6b44e32c554b1c2b41c1f97fb19.png?1635816914907" alt="Sea Kitchen" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/sea-kitchen" class="view-demo action-preview-theme btn-registration" data-url="https://sea-kitchen.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/sea-kitchen" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/sea-kitchen" class="title">Sea Kitchen</a></h3>
                              <span class="price ">
                              <b>1,500,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3638/themestores/6d580bac071ca1c4d9f19b18e3aadc22.jpg?1635734385540" alt="EGA Market" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/ega-market" class="view-demo action-preview-theme btn-registration" data-url="https://ega-market.mysapo.net" target="_blank">Xem thử</a>
                                    <a href="/ega-market" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/ega-market" class="title">EGA Market</a></h3>
                              <span class="price has-compare">
                              <b>1,520,000 <sub>đ</sub></b>
                              / <i>1,900,000 <sub>đ</sub></i>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/2402/themestores/2fac13d18095641904d7976488771aba.jpg?1607939643723" alt="Ant Cosmetic" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/ant-cosmetic" class="view-demo action-preview-theme btn-registration" data-url="https://ant-cosmetic.mysapo.net" target="_blank">Xem thử</a>
                                    <a href="/ant-cosmetic" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/ant-cosmetic" class="title">Ant Cosmetic</a></h3>
                              <span class="price ">
                              <b>1,590,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3548/themestores/d95312dcaf73843b752a9e052eafa2c1.jpg?1629777780767" alt="Evo Mỹ Phẩm" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/evo-my-pham" class="view-demo action-preview-theme btn-registration" data-url="https://evo-my-pham.mysapo.net" target="_blank">Xem thử</a>
                                    <a href="/evo-my-pham" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/evo-my-pham" class="title">Evo Mỹ Phẩm</a></h3>
                              <span class="price ">
                              <b>1,500,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/2394/themestores/dedde9473543701e6d801eadab1c2240.png?1627891723967" alt="Pharmacy" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/pharmacy" class="view-demo action-preview-theme btn-registration" data-url="https://template-pharmacy.mysapo.net" target="_blank">Xem thử</a>
                                    <a href="/pharmacy" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/pharmacy" class="title">Pharmacy</a></h3>
                              <span class="price ">
                              <b>999,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3666/themestores/25c63b38125ca8e0e2eae40e46eba0ec.jpg?1630400376893" alt="Stationery" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/template-stationery" class="view-demo action-preview-theme btn-registration" data-url="https://template-stationery.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/template-stationery" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/template-stationery" class="title">Stationery</a></h3>
                              <span class="price ">
                              <b>1,800,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3664/themestores/2a38c4c3138d440500ebb5ba734779f3.jpg?1635838764807" alt="ND Fresh" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/nd-fresh" class="view-demo action-preview-theme btn-registration" data-url="https://nd-fresh-1.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/nd-fresh" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/nd-fresh" class="title">ND Fresh</a></h3>
                              <span class="price ">
                              <b>1,500,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="text-center more-button d-block d-md-none"> <a class="more-collection btn-registration" href="/website-noi-bat">Xem thêm</a></div>
                  </div>
               </div>
            </div>
            <div class="themes-list">
               <div class="container">
                  <h2>Giao diện web mới</h2>
                  <p class="desc">Khám phá những template website bán hàng mới nhất</p>
                  <a class="more-theme" href="/website-moi-nhat" title="Xem thêm">Xem thêm</a>
                  <div class="row list-items">
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3671/themestores/a203b93f7e0659d0f87111af4d03590c.jpg?1635679044797" alt="Fruity Fresh" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/fruity-fresh" class="view-demo btn-registration" data-url="https://fruity-fresh.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/fruity-fresh" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/fruity-fresh" class="title">Fruity Fresh</a></h3>
                              <span class="price ">
                              <b>1,700,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3670/themestores/a9c404136e9b87b0880a5f1e41f2edf2.jpg?1635563752943" alt="Camp" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/template-camp" class="view-demo btn-registration" data-url="https://template-camp.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/template-camp" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/template-camp" class="title">Camp</a></h3>
                              <span class="price ">
                              <b>1,600,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3669/themestores/a38e0adbaa1c2150682039e120ee2454.png?1635734376313" alt="EGA Cosmetic" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/ega-cosmetic" class="view-demo btn-registration" data-url="https://ega-cosmetic.mysapo.net" target="_blank">Xem thử</a>
                                    <a href="/ega-cosmetic" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/ega-cosmetic" class="title">EGA Cosmetic</a></h3>
                              <span class="price has-compare">
                              <b>2,000,000 <sub>đ</sub></b>
                              / <i>2,500,000 <sub>đ</sub></i>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3668/themestores/679d9eeb6018b239de3102774fe64442.jpg?1633077982327" alt="HaluPetcare" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/halupetcare" class="view-demo btn-registration" data-url="https://petcare.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/halupetcare" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/halupetcare" class="title">HaluPetcare</a></h3>
                              <span class="price ">
                              <b>1,600,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3667/themestores/55e7233029d960a78f44a55da52cd5fd.jpg?1633050060523" alt="Claten" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/template-claten" class="view-demo btn-registration" data-url="https://template-claten.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/template-claten" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/template-claten" class="title">Claten</a></h3>
                              <span class="price ">
                              <b>1,700,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3666/themestores/15f2fd4819ffc59fb5a10cc795015d71.jpg?1630400376893" alt="Stationery" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/template-stationery" class="view-demo btn-registration" data-url="https://template-stationery.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/template-stationery" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/template-stationery" class="title">Stationery</a></h3>
                              <span class="price ">
                              <b>1,800,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3665/themestores/e84ea0da1ff7b98c984d98295c4f6d25.jpg?1636684010683" alt="Ego Wear" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/ego-wear" class="view-demo btn-registration" data-url="https://ego-wear.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/ego-wear" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/ego-wear" class="title">Ego Wear</a></h3>
                              <span class="price ">
                              <b>1,800,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="theme-item responsive">
                           <div class="theme-image">
                              <img src="https://bizwebtheme.dktcdn.net/themes/3664/themestores/78ba5fbf2fda9baccbde419268ddfd1a.jpg?1635838764807" alt="ND Fresh" />
                              <div class="theme-action">
                                 <div class="button">
                                    <a href="/demo/nd-fresh" class="view-demo btn-registration" data-url="https://nd-fresh-1.mysapo.net/" target="_blank">Xem thử</a>
                                    <a href="/nd-fresh" class="view-detail btn-registration">Chi tiết</a>
                                 </div>
                              </div>
                           </div>
                           <div class="theme-info">
                              <h3><a href="/nd-fresh" class="title">ND Fresh</a></h3>
                              <span class="price ">
                              <b>1,500,000 <sub>đ</sub></b>
                              </span>
                           </div>
                        </div>
                     </div>
                     <div class="text-center more-button d-block d-md-none"> <a class="more-collection btn-registration" href="/website-moi-nhat">Xem thêm</a></div>
                  </div>
               </div>
            </div>
            <div class="optimize text-center">
               <div class="container">
                  <h2>Mẫu website theo <br class="d-block d-md-none"/>ngành hàng</h2>
                  <p class="otp-link">Khám phá những mẫu website đẹp, phù hợp với ngành hàng của bạn</p>
                  <div class="list_category">
                     <div class="row">
                        <div class="col-lg-3 col-md-4 col-6">
                           <a href="/collections/website-thoi-trang" title="Thời trang">
                           <i class="icon fashion"></i>
                           <span>Tổng quát</span>
                           </a>
                        </div>
                        <div class="col-lg-3 col-md-4 col-6">
                           <a href="/collections/website-my-pham" title="Mỹ phẩm">
                           <i class="icon cosmetic"></i>
                           <span>Chỉnh nha</span>
                           </a>
                        </div>
                        <div class="col-lg-3 col-md-4 col-6">
                           <a href="/collections//website-cong-nghe" title="Công nghệ">
                           <i class="icon congnghe"></i>
                           <span>Phẫu thuật</span>
                           </a>
                        </div>
                        <div class="col-lg-3 col-md-4 col-6">
                           <a href="/collections/website-thuc-pham" title="Thực phẩm">
                           <i class="icon thucpham"></i>
                           <span>Khám định kỳ</span>
                           </a>
                        </div>
                        <div class="col-lg-3 col-md-4 col-6">
                           <a href="/collections/website-noi-that" title="Nội thất">
                           <i class="icon noithat"></i>
                           <span>Răng hàm mặt</span>
                           </a>
                        </div>
                        <div class="col-lg-3 col-md-4 col-6">
                           <a href="/collections/website-do-gia-dung" title="Gia dụng">
                           <i class="icon giadung"></i>
                           <span>Nhi khoa</span>
                           </a>
                        </div>
                        <div class="col-lg-3 col-md-4 col-6">
                           <a href="/collections//website-nha-hang-khach-san" title="Du lịch">
                           <i class="icon dulich"></i>
                           <span>Nội nha</span>
                           </a>
                        </div>
<!--                         <div class="col-lg-3 col-md-4 col-6">
                           <a href="/collections/website-doanh-nghiep" title="Doanh nghiệp">
                           <i class="icon doanhnghiep"></i>
                           <span>Doanh nghiệp</span>
                           </a>
                        </div> -->
                     </div>
                  </div>
                  <div class="more-info more d-block d-lg-none">Xem thêm <i class="ti-angle-down"></i></div>
               </div>
            </div>
         </div>
         <script type="text/javascript">
            $(function () {
                $(".optimize .more-info").click(function () {
                    if ($('.more-info').hasClass('more')) {
                        $(this).removeClass('more').addClass('less');
                        $(this).html('Thu gọn <i class="ti-angle-up"></i>');
                    } else {
                        $(this).removeClass('less').addClass('more');
                        $(this).html('Xem thêm <i class="ti-angle-down"></i>');
                        $('html, body').animate({
                            scrollTop: $('.list_category').offset().top
                        }, 200);
                    }
            
                    jQuery(".optimize .list_category").toggleClass("expand");
                });
            });
         </script>
         <div class="clear"></div>
         <img class="scroll-top" src="<?php echo e(asset('website/Themes/Portal/Default/Images/totop.png')); ?>" style="display:none;cursor :pointer; position : fixed;bottom : 90px;right : 33px;z-index : 99999;" />
         <script>
            $(document).ready(function () {
                $(window).scroll(function () {
                    if ($(window).scrollTop() > 700) {
                        $('.scroll-top').show();
                    }
                    else {
                        $('.scroll-top').hide();
                    }
                });
                $('.scroll-top').click(function () {
                    $("html, body").animate({ scrollTop: 0 }, "slow");
                });
                if ($(window).width() < 768) {
                    $('.scroll-top').css({ 'bottom': '90px', 'right': '8px' });
                }
            });
         </script>
         <div class="quick-registration register-bottom index">
            <div class="container">
               <div class="bg-register">
                  <h2>Bắt đầu dùng thử miễn phí 7 ngày</h2>
                  <p>Để trải nghiệm những tính năng tuyệt vời mà Sapo web mang lại</p>
                  <div class="reg-form">
                     <input id="site_name_bottom" class="input-site-name d-none d-md-inline-block" type="text" value="" placeholder="Nhập tên cửa hàng/doanh nghiệp của bạn" onkeypress="return onInputStoreName(event, this)">
                     <a class="btn-registration banner-home-registration event-Sapo-Free-Trial-form-open" onclick="showModalTrial(this, 2, false);" href="javascript:;">Dùng thử miễn phí</a>
                  </div>
               </div>
            </div>
         </div>
         <div id="footer" class="footer">
            <div class="footer-menu">
               <div class="container">
                  <div class="row">
                     <div class="col-lg col-md-4 col-6">
                        <div class="title">Sapo.vn</div>
                        <ul>
                           <li>
                              <a href="/ve-chung-toi.html?utm_campaign=cpn:ve_chung_toi-plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="dofollow">Về chúng tôi</a>
                           </li>
                           <li>
                              <a href="/sapo-la-gi.html" target="_blank" rel="dofollow">Sapo là gì?</a>
                           </li>
                           <li>
                              <a href="/blog/?utm_campaign=cpn:sapo_blog-plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="dofollow">Blog Sapo</a>
                           </li>
                           <li>
                              <a href="/bang-gia.html?utm_campaign=cpn:bang_gia-plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="dofollow">Bảng giá</a>
                           </li>
                           <li>
                              <a href="//tuyendung.sapo.vn/?utm_campaign=cpn:tuyen_dung-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="noopener dofollow">Tuyển dụng</a>
                           </li>
                        </ul>
                     </div>
                     <div class="col-lg col-md-4 col-6">
                        <div class="title">Sản phẩm</div>
                        <ul>
                           <li>
                              <a href="/phan-mem-quan-ly-ban-hang.html?utm_campaign=cpn:san_pham -plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="dofollow" target="_blank">Phần mềm quản lý bán hàng</a>
                           </li>
                           <li>
                              <a href="/quan-ly-ban-hang-online.html?utm_campaign=cpn:san_pham -plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="dofollow">Phần mềm bán hàng online</a>
                           </li>
                           <li>
                              <a href="/thiet-ke-website-ban-hang.html?utm_campaign=cpn:san_pham -plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="dofollow">Thiết kế website bán hàng</a>
                           </li>
                           <li>
                              <a href="/phan-mem-quan-ly-nha-hang.html?utm_campaign=cpn:san_pham -plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="dofollow">Phần mềm quản lý nhà hàng</a>
                           </li>
                           <li>
                              <a href="/omnichannel.html?utm_campaign=cpn:san_pham -plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="dofollow">Phần mềm bán hàng đa kênh</a>
                           </li>
                           <li>
                              <a href="/enterprise?utm_campaign=cpn:san_pham -plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="dofollow">Quản lý & phát triển thương hiệu</a>
                           </li>
                        </ul>
                     </div>
                     <hr style="border-top-color: #2b2a32; width: 100%; margin: 25px 0 30px;" class="d-block d-md-none" />
                     <div class="col-lg col-md-4 col-6">
                        <div class="title">Thiết kế website bán hàng</div>
                        <ul>
                           <li>
                              <a href="/thiet-ke-web-thoi-trang.html?utm_campaign=cpn:thiet_ke_website_ban_hang-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" rel="dofollow" target="_blank">Thiết kế web thời trang</a>
                           </li>
                           <li>
                              <a href="/thiet-ke-web-doanh-nghiep.html?utm_campaign=cpn:thiet_ke_website_ban_hang-plm:footer&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_theme_sapo" rel="dofollow" target="_blank">Thiết kế web doanh nghiệp</a>
                           </li>
                           <li>
                              <a href="/thiet-ke-web-bat-dong-san.html?utm_campaign=cpn:thiet_ke_website_ban_hang-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" rel="dofollow" target="_blank">Thiết kế website bất động sản</a>
                           </li>
                           <li>
                              <a href="/thiet-ke-web-thuong-mai-dien-tu.html?utm_campaign=cpn:thiet_ke_website_ban_hang-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" rel="dofollow" target="_blank">Thiết kế web thương mại điện tử</a>
                           </li>
                           <li>
                              <a href="/thiet-ke-website-tron-goi.html?utm_campaign=cpn:thiet_ke_website_ban_hang-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" rel="dofollow" target="_blank">Thiết kế website trọn gói</a>
                           </li>
                           <li>
                              <a href="/thiet-ke-website-gia-re.html?utm_campaign=cpn:thiet_ke_website_ban_hang-plm:footer&utm_source=themes.sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_theme_sapo" rel="dofollow" target="_blank">Thiết kế website giá rẻ</a>
                           </li>
                           <li>
                              <a href="//themes.sapo.vn/?utm_campaign=cpn:themes-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="dofollow">Mẫu website đẹp</a>
                           </li>
                        </ul>
                     </div>
                     <div class="col-lg col-md-4 col-6">
                        <div class="title">
                           Giải pháp quản lý
                        </div>
                        <ul>
                           <li>
                              <a href="/quan-ly-sieu-thi-mini.html?utm_campaign=cpn:sieu_thi_mini-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="dofollow">
                              Quản lý siêu thị mini
                              </a>
                           </li>
                           <li>
                              <a href="/quan-ly-cua-hang-tap-hoa.html?utm_campaign=cpn:cua_hang_tap_hoa-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="dofollow">
                              Quản lý cửa hàng tạp hóa
                              </a>
                           </li>
                           <li>
                              <a href="/quan-ly-cua-hang-thoi-trang.html?utm_campaign=cpn:cua_hang_thoi_trang-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="dofollow">
                              Quản lý cửa hàng thời trang
                              </a>
                           </li>
                           <li>
                              <a href="/quan-ly-cua-hang-my-pham.html?utm_campaign=cpn:cua_hang_my_pham-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="dofollow">
                              Quản lý cửa hàng mỹ phẩm
                              </a>
                           </li>
                           <li>
                              <a href="/phan-mem-quan-ly-quan-cafe.html?utm_campaign=cpn:quan_cafe-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="dofollow">
                              Quản lý quán cafe
                              </a>
                           </li>
                        </ul>
                     </div>
                     <hr style="border-top-color: #2b2a32; width: 100%; margin: 25px 0 30px;" class="d-block d-md-none" />
                     <div class="col-lg col-md-4 col-6 d-block d-lg-none">
                        <div class="title">Trợ giúp</div>
                        <ul>
                           <li>
                              <a href="/lien-he.html?utm_campaign=cpn:lien_he-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="noopener nofollow">Trung tâm trợ giúp</a>
                           </li>
                           <li>
                              <a href="https://support.sapo.vn/hinh-thuc-thanh-toan-154.html?utm_campaign=cpn:web_docs-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="noopener nofollow">Hình thức thanh toán</a>
                           </li>
                           <li>
                              <a href="https://support.sapo.vn/huong-dan-dang-nhap-he-thong-sapo?utm_campaign=cpn:web_docs-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="noopener nofollow">Hướng dẫn đăng nhập Sapo</a>
                           </li>
                           <li>
                              <a href="https://support.sapo.vn/quy-dinh-su-dung-87.html?utm_campaign=cpn:web_docs-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="noopener nofollow">Quy định sử dụng</a>
                           </li>
                           <li>
                              <a href="https://support.sapo.vn/chinh-sach-bao-mat-88.html?utm_campaign=cpn:web_docs-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="noopener nofollow">Chính sách bảo mật</a>
                           </li>
                           <li>
                              <a href="/lien-he.html?utm_campaign=cpn:lien_he-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="nofollow">Liên hệ</a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer-address">
               <div class="container">
                  <div class="row">
                     <div class="col-w-20 col-md-4 d-lg-block d-none">
                        <div class="title">Trợ giúp</div>
                        <ul>
                           <li>
                              <a href="https://support.sapo.vn/?utm_campaign=cpn:support_sapo-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="noopener nofollow">Trung tâm trợ giúp</a>
                           </li>
                           <li>
                              <a href="https://support.sapo.vn/cac-hinh-thuc-thanh-toan-khi-su-dung-dich-vu-cua-sapo?utm_campaign=cpn:hinh_thuc_thanh_toan-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="noopener nofollow">Hình thức thanh toán</a>
                           </li>
                           <li>
                              <a href="https://support.sapo.vn/huong-dan-dang-nhap-he-thong-sapo?utm_campaign=cpn:huong_dan_dang_nhap-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="noopener nofollow">Hướng dẫn đăng nhập Sapo</a>
                           </li>
                           <li>
                              <a href="https://support.sapo.vn/quy-dinh-su-dung?utm_campaign=cpn:quy_sinh_su_dung-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="noopener nofollow">Quy định sử dụng</a>
                           </li>
                           <li>
                              <a href="https://support.sapo.vn/chinh-sach-bao-mat?utm_campaign=cpn:chinh_sach_bao_mat-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="noopener nofollow">Chính sách bảo mật</a>
                           </li>
                           <li>
                              <a href="/lien-he.html?utm_campaign=cpn:lien_he-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="nofollow">Liên hệ</a>
                           </li>
                        </ul>
                     </div>
                     <div class="col-w-20 col-md-4">
                        <div class="title">Dịch vụ</div>
                        <ul>
                           <li>
                              <a href="/dang-ky-ten-mien.html?utm_campaign=cpn:dang_ki_ten_mien-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="dofollow">Đăng kí tên miền</a>
                           </li>
                           <li>
                              <a href="/dich-vu-email-doanh-nghiep.html?utm_campaign=cpn:dich_vu_email_doanh_nghiep-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=internal&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="dofollow">Email doanh nghiệp</a>
                           </li>
                        </ul>
                        <div class="title shared-experience">
                           <a href="https://shop.sapo.vn/?utm_campaign=cpn:saposhop-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="nofollow">Thiết bị bán hàng</a>
                        </div>
                        <ul>
                           <li>
                              <a href="https://shop.sapo.vn/may-in-hoa-don-may-in-bill?utm_campaign=cpn:saposhop-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="nofollow">Máy in hóa đơn</a>
                           </li>
                           <li>
                              <a href="https://shop.sapo.vn/may-in-ma-vach?utm_campaign=cpn:saposhop-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="nofollow">Máy in mã vạch</a>
                           </li>
                           <li>
                              <a href="https://shop.sapo.vn/may-quet-ma-vach?utm_campaign=cpn:saposhop-plm:footer&amp;utm_source=sapo.vn%2Fblog&amp;utm_medium=referral&amp;utm_content=fm:text_link-km:-sz:&amp;utm_term=&amp;campaign=footer_blog_sapo" target="_blank" rel="nofollow">Máy quét mã vạch</a>
                           </li>
                        </ul>
                     </div>
                     <div class="col-w-60 col-md-8">
                        <div class="title">Liên hệ</div>
                        <ul class="social">
                           <li>
                              <a href="https://www.facebook.com/sapo.vn/" target="_blank" rel="nofollow"><i class="fa fa-facebook-square"></i></a>
                           </li>
                           <li>
                              <a href="https://www.youtube.com/channel/UCXOMQd_gKgELyY_fhmPjI4w" target="_blank" rel="nofollow"><i class="fa fa-youtube"></i></a>
                           </li>
                           <li>
                              <a href="/blog" target="_blank"><i class="fa fa-weixin"></i></a>
                           </li>
                        </ul>
                        <div class="contact-info">
                           <p class="text-uppercase">Công ty cổ phần công nghệ Sapo (Sapo Technology JSC)</p>
                           <p><span>Trụ sở <i class="fa fa-map-marker"></i> </span>Tầng 6 - Tòa nhà Ladeco - 266 Đội Cấn - Phường Liễu Giai - Quận Ba Đình - TP Hà Nội</p>
                           <p>
                              <span class="d-xl-inline d-block">Chi nhánh </span><i class="fa fa-map-marker"></i> Lầu 3 - Tòa nhà Lữ Gia - Số 70 Lữ Gia - Phường 15 - Quận 11 - TP Hồ Chí Minh
                           </p>
                           <p>
                              <span style="visibility: hidden" class="d-none d-xl-inline">Chi nhánh </span><i class="fa fa-map-marker"></i> 181 đường Huỳnh Tấn Phát, Phường Hoà Cường Nam, Quận Hải Châu, TP Đà Nẵng
                           </p>
                           <p>
                              <span style="visibility: hidden" class="d-none d-xl-inline">Chi nhánh </span><i class="fa fa-map-marker"></i> <a style="text-decoration:underline" href="/lien-he.html" target="_blank">Xem thêm 24 chi nhánh của Sapo trên toàn quốc</a>
                           </p>
                           <p><span>Tổng đài tư vấn và hỗ trợ khách hàng: </span><b>1900 6750</b></p>
                           <p><span>Email: </span><b>support@sapo.vn</b></p>
                           <p>Từ 8h00 – 22h00 các ngày từ thứ 2 đến Chủ nhật</p>
                        </div>
                        <a href="http://online.gov.vn/Home/WebDetails/44190" target="_blank" rel="nofollow" class="footer-bct">
                        <img src="<?php echo e(asset('website/Themes/Portal/Default/Images/bocongthuong.png')); ?>" alt="Chứng nhận Bộ Công Thương" />
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer-copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-7 col-md-6 order-md-1 order-3">
                        <p class="copyright"><span class="d-none d-lg-inline-block">Copyright © 2021&nbsp;</span><a href="" target="_blank">Sapo.vn</a> - Nền tảng bán hàng đa kênh được sử dụng nhiều nhất Việt Nam</p>
                     </div>
                     <hr style="border-top-color: #2b2a32; width: 100%;margin:0;" class="d-block d-sm-none order-2" />
                     <div class="col-lg-5 col-md-6 order-md-2 order-1">
                        <p class="achievement">
                           <span>Sản phẩm đạt giải: <br class="d-block d-lg-none" />Nhân tài Đất Việt 2013 & Sao Khuê  2015</span>
                           <span class="icon-achievement"><img src="<?php echo e(asset('website/Themes/Portal/Default/Styles_New/images/icon-cup.png')); ?>" /></span>
                        </p>
                     </div>
                  </div>
               </div>
               <p class="copyright-mobile d-lg-none d-md-block d-none">© Copyright 2008 - 2021</p>
            </div>
         </div>
         <div id="free-trial" style="display: none;">
            <a class="close"><span class="ti-close"></span></a>
            <iframe id="trial-frame" src="" width="100%" height="100%" frameborder="0"></iframe>
         </div>
         <script>
            $(function () {
                $("#free-trial .close").click(function () {
                    var modal = document.getElementById('free-trial');
                    $('body').removeClass('open');
                    modal.style.display = "none";
                    $("#free-trial iframe").attr("src", "");
                });
                $('[data-toggle="tooltip"]').tooltip();
            });
         </script>
         <script type="text/javascript">
            var LAST_STORE_COOKIE_NAME = "last_store";
            
            $(function () {
                var lastStore = getCookie(LAST_STORE_COOKIE_NAME);
                if (lastStore !== null && lastStore !== "") {
                    $(".subdomain").removeClass("hide");
                    $("#login-form input[name=Subdomain]").val(lastStore);
                    $("#login-form input[name=Subdomain]").attr("aria-required", "true");
                    $("#login-form input[name=Subdomain]").attr("data-val-required", "Nhập vào đường dẫn website");
                    $("#login-form").removeData("validator");
                    $("#login-form").removeData("unobtrusiveValidation");
                    $.validator.unobtrusive.parse($("#login-form"));
                }
            });
            
            $(document).ready(function () {
                //luu thong tin tracking vao cookie
            
                var aff_id_ck = getCookie("aff_id");
                var aff_id = getParameterByName("aff_id");
                var aff_tracking_id = getParameterByName("aff_tracking_id");
                if (aff_id_ck == null || aff_id_ck == "") {
                    if (aff_id !== null && aff_id !== "") {
                        setCookie("aff_id", aff_id, 30);
                    }
            
                    if (aff_tracking_id !== null && aff_tracking_id !== "") {
                        setCookie("aff_tracking_id", aff_tracking_id, 30);
                    }
                }
                else {
                    if (aff_id == aff_id_ck) {
                        if (aff_tracking_id !== null && aff_tracking_id !== "") {
                            setCookie("aff_tracking_id", aff_tracking_id, 30);
                        }
                    }
                }
            
                var kd = getParameterByName("kd");
                if (kd !== null && kd !== "")
                    setCookie("kd", kd, 30);
            
                var ref = getParameterByName("ref");
                if (ref !== null && ref !== "")
                    setCookie("ref", ref, 30);
            
                var campaign = getParameterByName("campaign");
                if (campaign !== null && campaign !== "")
                    setCookie("campaign", campaign, 30);
            
                if (document.referrer && document.referrer != '') {
                    if (document.referrer.indexOf") == -1) {
                        setCookie("referral", document.referrer, 30);
                    }
                }
            
                var partner = getParameterByName("aff_partner_id");
                if (partner !== null && partner !== "")
                    setCookie("partner", partner, 30);
            
                var landingPage = getCookie("landing_page");
                if (landingPage == null || landingPage == "") {
                    setCookie("landing_page", document.location.href, 0.0115);
                }
            
                var startTime = getCookie("start_time");
                if (startTime == null || startTime == "") {
                    setCookie("start_time", "11/16/2021 16:08:59", 0.0115);
                }
            
                var pageview = getCookie("pageview");
                if (pageview == null || pageview == "") {
                    setCookie("pageview", 1, 0.0115);
                }
                else {
                    setCookie("pageview", parseInt(pageview) + 1, 0.0115);
                }
            
                var updateCookie = setInterval(renewFirstPageCookie, 15 * 60 * 1000);
            
                //check orient change
                window.addEventListener("orientationchange", function () {
                }, false)
            
            });
            
            function showTrialForm(e, type, chkOmni) {
                var url = "https://app.sapo.vn/services/signup";
                url = setParameter(url, "Type", type);
            
                if (chkOmni) {
                    url = setParameter(url, "PreferredService", "OMNI");
                }
            
                var storeName = $(e).parent().parent().find(".input-site-name").val();
                if (storeName != null && storeName != "")
                    url = setParameter(url, "StoreName", storeName);
            
                var kd = getParameterByName("kd");
                if (kd !== null && kd !== "")
                    setCookie("kd", kd, 30);
            
                kd = getCookie("kd");
                if (kd !== null && kd !== "")
                    url = setParameter(url, "SaleName", kd);
            
                var ref = getParameterByName("ref");
                if (ref !== null && ref !== "")
                    setCookie("ref", ref, 30);
            
                ref = getCookie("ref");
                if (ref !== null && ref !== "")
                    url = setParameter(url, "Reference", ref);
            
                if (window.location.href && window.location.href != '') {
                    url = setParameter(url, "Source", encodeURIComponent(window.location.href));
                }
            
                var referral = getCookie("referral");
                if (referral !== null && referral !== "")
                    url = setParameter(url, "Referral", encodeURIComponent(referral));
            
                var campaign = getParameterByName("campaign");
                if (campaign !== null && campaign !== "")
                    setCookie("campaign", campaign, 30);
            
                campaign = getCookie("campaign");
                if (campaign !== null && campaign !== "")
                    url = setParameter(url, "Campaign", campaign);
            
                var landingPage = getCookie("landing_page");
                if (landingPage !== null && landingPage !== "")
                    url = setParameter(url, "LandingPage", encodeURIComponent(landingPage));
            
                var startTime = getCookie("start_time");
                if (startTime !== null && startTime !== "")
                    url = setParameter(url, "StartTime", encodeURIComponent(startTime));
            
                var endTime = "11/16/2021 16:08:59";
                if (endTime !== null && endTime !== "")
                    url = setParameter(url, "EndTime", encodeURIComponent(endTime));
            
                var pageview = getCookie("pageview");
                if (pageview !== null && pageview !== "")
                    url = setParameter(url, "Pageview", pageview);
            
                var aff_id = getCookie("aff_id");
                if (aff_id !== null && aff_id !== "") {
                    url = setParameter(url, "AffId", aff_id);
                }
            
                var aff_tracking_id = getCookie("aff_tracking_id");
                if (aff_tracking_id !== null && aff_tracking_id !== "") {
                    url = setParameter(url, "AffTrackingId", aff_tracking_id);
                }
            
                var partner = getCookie("partner");
                if (partner !== null && partner !== "") {
                    url = setParameter(url, "partner", partner);
                }
            
                $('#free-trial iframe').attr("src", url);
                $('body').addClass('open');
                $('#free-trial').fadeIn('fast');
            }
            
            function renewFirstPageCookie() {
                var landingPage = getCookie("landing_page");
                if (landingPage !== null && landingPage !== "") {
                    setCookie("landing_page", landingPage, 0.0115);
                }
            
                var startTime = getCookie("start_time");
                if (startTime !== null && startTime !== "") {
                    setCookie("start_time", startTime, 0.0115);
                }
            
                var pageview = getCookie("pageview");
                if (pageview !== null || pageview !== "") {
                    setCookie("pageview", pageview, 0.0115);
                }
            }
            
            function bodauTiengViet(str) {
                str = str.toLowerCase();
                str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
                str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
                str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
                str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
                str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
                str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
                str = str.replace(/đ/g, "d");
                return str;
            }
            
            var mobile = false;
            $(window).resize(function () {
                var ww = $(window).width();
                if (ww < 768) {
                    if (!$('#login-div br').length > 0)
                        $('#login-div .popup-login-text').before('<br/>');
                }
                else {
                    $('#login-div br').remove();
                }
            })
            $(window).trigger('resize');
            
            function getParameterByName(name) {
                name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
                var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                    results = regex.exec(location.search);
                return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
            }
            
            function onInputStoreName(e, element) {
                if (e.keyCode == 13) {
            
                    return false;
                }
            }
            
            function generateAlias(text) {
                text = text.toLowerCase();
                text = text.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
                text = text.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
                text = text.replace(/ì|í|ị|ỉ|ĩ/g, "i");
                text = text.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
                text = text.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
                text = text.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
                text = text.replace(/đ/g, "d");
                text = text.replace(/'|\"|\(|\)|\[|\]/g, "");
                text = text.replace(/\W+/g, "-");
                if (text.slice(-1) === "-")
                    text = text.replace(/-+$/, "");
            
                if (text.slice(0, 1) === "-")
                    text = text.replace(/^-+/, "");
            
                return text;
            }
            
            function setCookie(cname, cvalue, exdays) {
                if (!exdays)
                    exdays = 30;
            
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires=" + d.toGMTString();
                document.cookie = cname + "=" + cvalue + "; " + expires + ";domain=.sapo.vn;path=/";
            }
            
            function newSetCookie(cname, cvalue) {
                document.cookie = cname + "=" + cvalue;
            }
            
            function getUrlWithoutDomain(url) {
                return url.replace(/^.*\/\/[^\/]+/, '');
            }
            
            function getCookie(cname) {
                var name = cname + "=";
                var ca = document.cookie.split(';');
                for (var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') c = c.substring(1);
                    if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
                }
                return null;
            }
            
            function getSessionStorage(sname) {
                return window.sessionStorage.getItem(sname);
            }
            
            function setSessionStorage(sname, svalue) {
                window.sessionStorage.setItem(sname, svalue);
            }
            
            function guid() {
                return 'xxxxxxxx-xxxx-4xxx-yxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                }).toUpperCase();
            }
            
            function setParameter(url, paramName, paramValue) {
                if (url.indexOf(paramName + "=") >= 0) {
                    var prefix = url.substring(0, url.indexOf(paramName));
                    var suffix = url.substring(url.indexOf(paramName));
                    suffix = suffix.substring(suffix.indexOf("=") + 1);
                    suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix.indexOf("&")) : "";
                    url = prefix + paramName + "=" + paramValue + suffix;
                }
                else {
                    if (url.indexOf("?") < 0)
                        url += "?" + paramName + "=" + paramValue;
                    else
                        url += "&" + paramName + "=" + paramValue;
                }
            
                return url;
            }
         </script>
      </div>
   </body>
</html><?php /**PATH C:\Users\cuong123\Desktop\blog\resources\views/theme.blade.php ENDPATH**/ ?>
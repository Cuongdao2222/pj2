<div class="table-responsive">
    <table class="table" id="products-table">
        <thead>
        <tr>
            <th>Image</th>
        <th>Tên sản phẩm</th>
        <th>Productsku</th>
        <th>Link</th>
         <th>Nhóm sản phẩm</th>
        <th>Số lượng trong kho</th>
        <th>Sản phẩm Hot</th>
        <th>Sản phẩm Sale</th>
        
        <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>

        <?php
            //cắt chuỗi khi dài quá
            function substrwords($text, $maxchar, $end='...') {
                if (strlen($text) > $maxchar || $text == '') {
                    $words = preg_split('/\s/', $text);      
                    $output = '';
                    $i      = 0;
                    while (1) {
                        $length = strlen($output)+strlen($words[$i]);
                        if ($length > $maxchar) {
                            break;
                        } 
                        else {
                            $output .= " " . $words[$i];
                            ++$i;
                        }
                    }
                    $output .= $end;
                } 
                else {
                    $output = $text;
                }
                return $output;
            }
        
        ?>    

        <?php  

            $list_hot = App\Models\hotProduct::select('product_id')->get();
            $list_sale = App\Models\saleProduct::select('product_id')->get();

            function convertListToArray($list)
            {   
                $ar_list = [];

                if(count($list)){
                    foreach($list as $value){
                        array_push($ar_list, $value['product_id']);
                    }    
                }
                
                return $ar_list;
            }

            $list_hot = convertListToArray($list_hot);
            $list_sales = convertListToArray($list_sale);
            
            
           
        ?>


        
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><img src="/<?php echo e($product->Image); ?>" width="150px" height="150px"></td>
            <td><?php echo e($product->Name); ?></td>
            <td><?php echo e($product->ProductSku); ?></td>
            <td>/<?php echo e($product->Link); ?></td>
            <td><?php echo e($product->Group_id); ?></td>
            <td><?php echo e($product->Quantily); ?></td>


            <td><input type="checkbox" id="hot<?php echo e($product->id); ?>" name="hot"  onclick='handleClick(<?php echo e($product->id); ?>);' data-id ="<?php echo e($product->Group_id); ?>" <?php echo e(in_array($product->id, $list_hot)?'checked':''); ?>></td>
            <td><input type="checkbox" id="sale<?php echo e($product->id); ?>" name="sale"  onclick='saleClick(<?php echo e($product->id); ?>);' data-id ="<?php echo e($product->Group_id); ?>" <?php echo e(in_array($product->id, $list_sales)?'checked':''); ?>></td>
            
                <td width="120">
                    <?php echo Form::open(['route' => ['products.destroy', $product->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('products.show', [$product->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('products.edit', [$product->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>

                         <a href="<?php echo e(route('images.create', [$product->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="fas fa-image"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<script type="text/javascript">

    function handleClick(id) {

        var checked = $('#hot'+id).is(':checked'); 

        const group_id = $('#hot'+id).attr('data-id');

        

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        if(checked == true)
        $.ajax({
           
            type: 'POST',
            url: "<?php echo e(route('add-hot-product')); ?>",
            data: {
                product_id: id,
                group_id: group_id,
                   
            },
            success: function(result){
                console.log(result);
            }
        });
        else
        $.ajax({
           
            type: 'POST',
            url: "<?php echo e(route('remove-hot-product')); ?>",
            data: {
                product_id: id,
                group_id: group_id,
                   
            },
            success: function(result){
                console.log(result);
            }
        });

        
    }

    function saleClick(id) {

         var checked = $('#sale'+id).is(':checked'); 

        const group_id = $('#sale'+id).attr('data-id');


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        if(checked == true)
        $.ajax({
           
            type: 'POST',
            url: "<?php echo e(route('add-sale-product')); ?>",
            data: {
                product_id: id,
                group_id: group_id,
                   
            },
            success: function(result){
                console.log(result);
            }
        });
        else
        $.ajax({
           
            type: 'POST',
            url: "<?php echo e(route('remove-sale-product')); ?>",
            data: {
                product_id: id,
                group_id: group_id,
                   
            },
            success: function(result){
                console.log(result);
            }
        });


    }     
    
</script>
<?php /**PATH C:\Users\APC-LTN\Desktop\project\mediass\resources\views/products/table.blade.php ENDPATH**/ ?>
<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control','maxlength' => 1000]); ?>

</div><?php /**PATH C:\Users\APC-LTN\Desktop\project\media\resources\views/group_products/fields.blade.php ENDPATH**/ ?>
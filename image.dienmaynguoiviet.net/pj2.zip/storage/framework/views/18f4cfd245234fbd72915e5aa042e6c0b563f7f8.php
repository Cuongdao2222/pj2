<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH /home/dthdenta/public_html/media/resources/views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>
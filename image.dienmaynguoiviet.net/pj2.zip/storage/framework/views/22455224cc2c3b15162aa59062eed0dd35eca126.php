<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH C:\Users\cuong123\Desktop\New folder (2)\blog\resources\views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="box_breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="/">Trang chủ</a></li>
            <li><a href="/chinh-nha" title="Chỉnh nha">Chỉnh nha</a></li>
        </ul>
    </div>
</div>
<div class="wrapper">
    <div class="container">
        <div class="box_module">
            <div class="box_title">
                <h1 class="title"><a href="/chinh-nha" title="Chỉnh nha">Chỉnh nha</a></h1>
            </div>
            <div class="box_content">
                <div class="layout_category_product">
                    <div class="productGrid service">
                        <div class="row">
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/nieng-rang-mac-cai-kim-loai" title="Niềng răng mắc cài kim loại"><img src="<?php echo e(asset('public/files/upload/default/medium/images/nieng-rang/anh-nho-nieng-rang-mac-cai.jpg')); ?>" alt="Niềng răng mắc cài kim loại"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/nieng-rang-mac-cai-kim-loai" title="Niềng răng mắc cài kim loại">Niềng răng mắc cài kim loại</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/nieng-rang-mac-cai-kim-loai-tu-buoc" title="Niềng răng mắc cài kim loại tự buộc"><img src="<?php echo e(asset('public/files/upload/default/medium/images/nieng-rang/anh-nho-nieng-rang-kim-loai-tu-dong.jpg')); ?>" alt="Niềng răng mắc cài kim loại tự buộc"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/nieng-rang-mac-cai-kim-loai-tu-buoc" title="Niềng răng mắc cài kim loại tự buộc">Niềng răng mắc cài kim loại tự buộc</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/nieng-rang-mac-cai-su" title="Niềng răng mắc cài sứ"><img src="<?php echo e(asset('public/files/upload/default/medium/images/nieng-rang/anh-nho-nieng-rang-mac-cai-su.jpg')); ?>" alt="Niềng răng mắc cài sứ"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/nieng-rang-mac-cai-su" title="Niềng răng mắc cài sứ">Niềng răng mắc cài sứ</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/nieng-rang-mac-cai-su-tu-buoc" title="Niềng răng mắc cài sứ tự buộc"><img src="<?php echo e(asset('public/files/upload/default/medium/images/nieng-rang/anh-nho-nieng-rang-mac-cai-su-tu-dong.jpg')); ?>" alt="Niềng răng mắc cài sứ tự buộc"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/nieng-rang-mac-cai-su-tu-buoc" title="Niềng răng mắc cài sứ tự buộc">Niềng răng mắc cài sứ tự buộc</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/nieng-rang-mac-cai-pha-le" title="Niềng răng mắc cài Pha Lê"><img src="<?php echo e(asset('public/files/upload/default/medium/images/nieng-rang/anh-nho-nieng-rang-mac-cai-pha-le.jpg')); ?>" alt="Niềng răng mắc cài Pha Lê"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/nieng-rang-mac-cai-pha-le" title="Niềng răng mắc cài Pha Lê">Niềng răng mắc cài Pha Lê</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/nieng-rang-mat-luoi" title="Niềng răng mặt lưỡi"><img src="<?php echo e(asset('public/files/upload/default/medium/images/nieng-rang/anh-nho-nieng-rang-mat-luoi.jpg')); ?>" alt="Niềng răng mặt lưỡi"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/nieng-rang-mat-luoi" title="Niềng răng mặt lưỡi">Niềng răng mặt lưỡi</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/nieng-rang-invisalign-tham-my" title="Niềng răng invisalign thẩm mỹ"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/nieng-rang-invisalign.jpg')); ?>" alt="Niềng răng invisalign thẩm mỹ"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/nieng-rang-invisalign-tham-my" title="Niềng răng invisalign thẩm mỹ">Niềng răng invisalign thẩm mỹ</a></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/nieng-rang" title="Niềng răng"><img src="<?php echo e(asset('public/files/upload/default/medium/images/4-loi-ich-tu-nieng-rang-mac-cai-ban-nen-biet-h1.jpg')); ?>" alt="Niềng răng"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/nieng-rang" title="Niềng răng">Niềng răng</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="box_feedbackCategoryHome">
    <div class="container">
        <div class="box_title">
            <h2 class="title"><a href="/cam-nhan-khach-hang" title="Khách hàng nói gì về D'media?">Khách hàng nói gì về D'media?</a></h2>
            <a href="/cam-nhan-khach-hang" class="view_all">Xem tất cả</a>
        </div>
        <div class="box_desc"></div>
        <div class="box_content">
            <div class="slide">
                <div class="item">
                    <div class="item_content">Làm xong cũng chẳng đau gì chỉ thấy đẹp thôi, mình tự tin hát và trước ống kính lắm rồi.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/thuong-cin" title="THƯƠNG CIN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/thuong-cin-2.png')); ?>" alt="THƯƠNG CIN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/thuong-cin" title="THƯƠNG CIN">THƯƠNG CIN</a></h3>
                            <div class="desc">Diễn viên <span></span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Răng của Huyền trước đây khá đều, tuy nhiên lại không được trắng sáng. Dù không tự ti nhưng là 1 Boss của hệ thống hơn 1000 người thì hình ảnh nụ cười rạng rỡ chính là yếu tố khiến Huyền luôn được yêu mến và tin tưởng.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/hoang-phi-huyen.png')); ?>" alt="HOÀNG PHI HUYỀN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN">HOÀNG PHI HUYỀN</a></h3>
                            <div class="desc">Boss <span>Huyền Phi Comestic</span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Hiện tại Nụ cười rạng rỡ mà Win Smile mang lại cho tôi đó chính là niềm tin yêu của học viên và sự quý trọng của đối tác. Cám ơn Win Smile luôn đồng hành cùng tôi trên con đường thành công.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-tat-kiem.png')); ?>" alt="NGUYỄN TẤT KIỂM"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM">NGUYỄN TẤT KIỂM</a></h3>
                            <div class="desc">CEO <span>TAKA ACADEMY</span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Bây giờ mình luôn tự tin , thoải mái mỗi khi cười và nhận được rất nhiều lời khen từ bạn bè và đối tác.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/nguyen-quyen" title="NGUYỄN QUYÊN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-quyen.png')); ?>" alt="NGUYỄN QUYÊN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/nguyen-quyen" title="NGUYỄN QUYÊN">NGUYỄN QUYÊN</a></h3>
                            <div class="desc">Boss <span>Mỹ phẩm Herrin Care</span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Răng của Giang trước đây gặp rất nhiều vấn đề, răng khấp khểnh, cười hở lợi và không được trắng sáng. </div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-tra-giang3.png')); ?>" alt="NGUYỄN TRÀ GIANG"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG">NGUYỄN TRÀ GIANG</a></h3>
                            <div class="desc">Boss <span>Mint beauty</span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content"> Ai cũng khen răng mình đẹp, đi làm gặp nhiều anh chị nghệ sĩ đã làm răng rồi mà mọi người vẫn hỏi mình làm răng ở đâu, Mình cảm ơn Win Smile rất nhiều.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/pong-chuan" title="PÔNG CHUẨN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/pong-chuan.png')); ?>" alt="PÔNG CHUẨN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/pong-chuan" title="PÔNG CHUẨN">PÔNG CHUẨN</a></h3>
                            <div class="desc">Style list <span></span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Một người khó tính và sợ đau như Tùng mà sau khi bọc răng sứ tại Win Smile còn cảm thấy hài lòng thì Tùng nghĩ dịch vụ tại Win Smile rất đáng để trải nghiệm.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/tung-min" title="TÙNG MIN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/tung-min.png')); ?>" alt="TÙNG MIN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/tung-min" title="TÙNG MIN">TÙNG MIN</a></h3>
                            <div class="desc">Diễn viên <span></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/frontend/niengrang.blade.php ENDPATH**/ ?>
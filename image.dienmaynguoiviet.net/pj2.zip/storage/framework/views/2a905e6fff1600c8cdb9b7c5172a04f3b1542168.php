<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <div class="input-group">
        <div class="custom-file">
            <?php echo Form::file('image', ['class' => 'custom-file-input']); ?>

            <?php echo Form::label('image', 'Choose file', ['class' => 'custom-file-label']); ?>

        </div>
    </div>
</div>
<div class="clearfix"></div>


<!-- Order Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('order', 'Stt:'); ?>

    <?php echo Form::text('order', null, ['class' => 'form-control']); ?>

</div>

<?php  
    $start = stripos($_SERVER['REQUEST_URI'],'?');
    
    $result = substr($_SERVER['REQUEST_URI'], $start);

    $product_id = str_replace('?', '', $result);

?>
<div class="form-group col-sm-6" style="display:none">
    <?php echo Form::label('product_id', 'Product_id:'); ?>

    <?php echo Form::text('product_id', $product_id, ['class' => 'form-control']); ?>

</div>


<?php /**PATH C:\Users\APC-LTN\Desktop\project\media\resources\views/images/fields.blade.php ENDPATH**/ ?>
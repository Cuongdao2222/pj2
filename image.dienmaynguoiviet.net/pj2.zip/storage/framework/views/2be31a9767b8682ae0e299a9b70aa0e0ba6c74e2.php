<!DOCTYPE html>
<html lang="vi-VN">
   <head>
      <title>Bảng b&#225;o gi&#225; c&#225;c dịch vụ qu&#225;n l&#253; b&#225;n h&#224;ng Sapo</title>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
   
      <meta content="D'media" />
      <link rel="canonical" href="./bang-gia.html" />
   
      <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
        <link rel="icon" href="images/favicon.png" type="image/x-icon">
      <script type="text/javascript">
         function addLoadEvent(e) { if (document.readyState === "complete") { e() } else { var t = window.onload; if (typeof window.onload != "function") { window.onload = e } else { window.onload = function () { if (t) { t() } e() } } } }
      </script>
      <script src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/lib/tom-select/tom-select.complete.js')); ?>" async></script>
      <script src="<?php echo e(asset('website/Themes/Portal/Default/Scripts/dist/defaultV2.min.js?v=637720665631753465')); ?>" async></script>
      <link href="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/dist/price.min.css?v=637711847685536089')); ?>" rel="preload" as="style" type="text/css" />
      <link href="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/dist/price.min.css?v=637711847685536089')); ?>" rel="stylesheet" />
      <script src="./variable-trial.js" async></script>

      <meta property="og:title" content="Bảng b&#225;o gi&#225; c&#225;c dịch vụ qu&#225;n l&#253; b&#225;n h&#224;ng Sapo" />
      <meta property="og:description" content="Bảng gi&#225; thiết kế website b&#225;n h&#224;ng, phần mềm quản l&#253; b&#225;n h&#224;ng online đến offline. Quản l&#253; b&#225;n h&#224;ng chuy&#234;n nghiệp - Gia tăng lợi nhuận. Chỉ từ 3,900đ/ ng&#224;y." />

      <meta name="twitter:card" content="Bảng gi&#225; thiết kế website b&#225;n h&#224;ng, phần mềm quản l&#253; b&#225;n h&#224;ng online đến offline. Quản l&#253; b&#225;n h&#224;ng chuy&#234;n nghiệp - Gia tăng lợi nhuận. Chỉ từ 3,900đ/ ng&#224;y.">
      <meta name="twitter:site" content="Bảng b&#225;o gi&#225; c&#225;c dịch vụ qu&#225;n l&#253; b&#225;n h&#224;ng Sapo">
      <meta name="twitter:creator" content="Bảng b&#225;o gi&#225; c&#225;c dịch vụ qu&#225;n l&#253; b&#225;n h&#224;ng Sapo">
      <meta name="twitter:url" content="./bang-gia.html">
      <meta name="twitter:title" content="Bảng b&#225;o gi&#225; c&#225;c dịch vụ qu&#225;n l&#253; b&#225;n h&#224;ng Sapo">
      <meta name="twitter:description" content="Bảng gi&#225; thiết kế website b&#225;n h&#224;ng, phần mềm quản l&#253; b&#225;n h&#224;ng online đến offline. Quản l&#253; b&#225;n h&#224;ng chuy&#234;n nghiệp - Gia tăng lợi nhuận. Chỉ từ 3,900đ/ ng&#224;y.">
      <meta name="twitter:image" content="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/social-banner/Prices.jpg?v=2')); ?>">
      <meta name="twitter:image:width" content="500">
      <meta name="twitter:image:height" content="300">
      <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
      <style type="text/css">
            .sapo-shop{
               display: none;
            }
            .selling-machine{
               display: none;
            }
      </style>
     
   </head>
   <body>
      <div id="container">
         <div id="header" class=" header">
            <div class="main-header d-flex align-items-center flex-wrap">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-2 col-8 d-flex align-items-center ">
                        <a id="logo" class="main-logo" href="/">
                        <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/logo/Sapo-logo.svg?v=202111160233')); ?>" alt="Sapo logo" />
                        </a>
                     </div>
                     <div class="col-xl-10 col-4 d-flex justify-space-beetwen">
                        <ul class="main-menu d-none d-xl-flex align-items-center update-menu">
                          
                        <a aria-label="button" href="javascript:;" class="d-inline-block d-xl-none btn-menu" onclick="openMenu();">
                        <i class="ti-menu"></i>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="menu-mobile">
            <div class="logo-mobile">
               <a href="/">
               <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/logo/Sapo-logo.svg?v=202111160233')); ?>" alt="Sapo logo" />
               </a>
               <a aria-label="Intermdiate JavaScript" href="javascript:;" class="btn-close-menu" onclick="closeMenu();">
               <i class="ti-close"></i>
               </a>
            </div>
            <div class="box-scroll">
               <ul class="nav nav-bottom">
                  <li class="show-sub">
                     <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-1">
                     Sản phẩm
                     </a>
                     <div id="nav-bottom-child-1" class="panel-collapse collapse">
                        <ul class="sub-menu">
                           <li>
                              <a href="/phan-mem-quan-ly-ban-hang.html">
                              <strong>Sapo POS</strong>
                              <span>Phần mềm quản lý bán hàng</span>
                              </a>
                           </li>
                           <li>
                              <a href="/phan-mem-quan-ly-nha-hang.html">
                              <strong>Sapo FnB</strong>
                              <span>Phần mềm quản lý nhà hàng</span>
                              </a>
                           </li>
                           <li>
                              <a href="/quan-ly-ban-hang-online.html">
                              <strong>Sapo GO</strong>
                              <span>Quản lý tăng trưởng bán hàng online</span>
                              </a>
                           </li>
                           <li>
                              <a href="/thiet-ke-website-ban-hang.html">
                              <strong>Sapo Web</strong>
                              <span>Giải pháp thiết kế website bán hàng</span>
                              </a>
                           </li>
                           <li>
                              <a href="/omnichannel.html">
                              <strong>Sapo Omnichannel</strong>
                              <span>Giải pháp quản lý bán hàng đa kênh</span>
                              </a>
                           </li>
                           <li>
                              <a href="/ung-dung-so-ghi-no-va-ban-hang-online.html">
                              <strong>Sapo 365 <span class="badge">Free</span></strong>
                              <span>Ứng dụng sổ ghi nợ và bán hàng <br />online miễn phí </span>
                              </a>
                           </li>
                           <li>
                              <a href="/phan-mem-crm-va-marketing-automation.html">
                              <strong>Sapo Hub</strong>
                              <span>Phần mềm CRM 4.0 và Marketing Automation</span>
                              </a>
                           </li>
                           <li>
                              <a href="/enterprise">
                              <strong>Sapo Enterprise</strong>
                              <span>Quản lý và phát triển thương hiệu <br />cho doanh nghiệp lớn</span>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </li>
                  <li class="show-sub">
                     <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-1b">
                     Tiện ích
                     </a>
                     <div id="nav-bottom-child-1b" class="panel-collapse collapse">
                        <ul class="sub-menu">
                           <li>
                              <a href="/sapo-express.html">
                              <strong>Sapo Express</strong>
                              <span>Giải pháp tối ưu vận chuyển</span>
                              </a>
                           </li>
                           <li>
                              <a href="/sapo-fin.html">
                              <strong>Sapo Fin</strong>
                              <span>Giải pháp tiên phong - Vay vốn tin cậy cho nhà bán hàng</span>
                              </a>
                           </li>
                           <li>
                              <a href="/sapo-market.html">
                              <strong>Sapo Market</strong>
                              <span>
                              Đầu mối nhập hàng giá tốt cho các tiệm tạp hóa, siêu thị mini
                              </span>
                              </a>
                           </li>
                           <li>
                              <a href="/sapo-pay.html">
                              <strong>Sapo Pay</strong>
                              <span>
                              Giải pháp thanh toán không tiền mặt đa kênh
                              </span>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </li>
                  <li>
                     <a href="/bang-gia.html">
                     Bảng giá <span class="badge">SALE</span>                    </a>
                  </li>
                  <li><a href="/khach-hang.html">Khách hàng</a></li>
                  <li><a href="//www.sapo.vn/blog" rel="noopener" target="_blank">Blog</a></li>
                  <li>
                     <a href="https://support.sapo.vn" target="_blank" rel="noopener">Trợ giúp</a>
                  </li>
                  <li class="show-sub">
                     <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-2">
                     Thêm
                     </a>
                     <div id="nav-bottom-child-2" class="panel-collapse collapse">
                        <ul class="sub-menu">
                           <li><a href="/ve-chung-toi.html">Về chúng tôi</a></li>
                           <li><a href="/sapo-la-gi.html">Sapo là gì?</a></li>
                           <li><a href="https://shop.sapo.vn/" target="_blank" rel="noopener">Thiết bị bán hàng</a></li>
                           <li class="show-sub">
                              <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-3">Giới thiệu khách hàng </a>
                              <div id="nav-bottom-child-3" class="panel-collapse collapse">
                                 <ul class="sub-menu" style="margin-bottom:15px">
                                    <li><a href="/sapo-partner.html">Cộng tác viên</a></li>
                                    <li><a href="/sapo-affiliate.html">Khách hàng cũ</a></li>
                                 </ul>
                              </div>
                           </li>
                           <li><a href="/bao-chi-noi-ve-sapo.html">Báo chí nói về Sapo</a></li>
                           <li><a href="//www.sapo.vn/blog/tin-su-kien-sapo/" rel="noopener" target="_blank">Sapo updates</a></li>
                           <li><a href="//tuyendung.sapo.vn/" rel="noopener" target="_blank">Tuyển dụng</a></li>
                           <li><a href="/lien-he.html">Liên hệ</a></li>
                        </ul>
                     </div>
                  </li>
                  <li   class="login"  >
                     <a href="/dang-nhap-kenh-ban-hang.html">Đăng nhập</a>
                  </li>
                  <li class="trial">
                     <a class="btn-registration" onclick="showModalTrial(this, 1, false);" href="javascript:;">
                     <span>Dùng thử</span>
                     </a>
                  </li>
               </ul>
            </div>
         </div>
         <div class="overlay-menu" onclick="closeMenu()"></div>
         <script type="text/javascript">
            function openMenu() {
                $('body').css('overflow', 'hidden');
                $('.overlay-menu').fadeIn(300);
                $('.menu-mobile').addClass('show');
            }
            function closeMenu() {
                $('body').css('overflow', '');
                $('.overlay-menu').fadeOut(300);
                $('.menu-mobile').removeClass('show');
            }
            addLoadEvent(function () {
            });
         </script>
         <div id="wrapper" class="clearfix">
            <div class="home-price">
               <div class="packages text-center">
                  <div class="container">
                     <h1>Bảng giá thiết kế website nha khoa</h1>
                     <p>Lực chọn giải pháp phù hợp với quy mô phòng khám</p>
                     <div class="row justify-content-center">
                        <div class="col-xl-10">
                           <div class="block-promotion">
                              <a onclick="showModalTrial(this, 1, false)" href="javascript:;">
                              <img class="img-desktop d-none d-lg-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/img-promotion-price-pc.png?v=10')); ?>" alt="Phục hồi kinh doanh sau dịch" style="
    display: none !important"/>
                              <img class="img-desktop d-block d-lg-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/img-promotion-price-m.png?v=10')); ?>" alt="Phục hồi kinh doanh sau dịch" style="
    display: none !important"/>
                              </a>
                           </div>
                           <div class="item pos">
                              <span class="tag-promotion pos price-pos-covid" onclick="location.href='/bang-gia-sapo-pos.html';"></span>
                              <div class="name-price">
                                 <h2><a href="/phan-mem-quan-ly-ban-hang.html">Sapo POS</a></h2>
                                 <p>Phần mềm quản lý bán hàng</p>
                                 <div class="price">
                                    <div>
                                       <span class="price-regular"><sup class="tu">Từ</sup><span class="price-inline">160.000</span><sup class="d">đ</sup><span class="date">/tháng</span></span>
                                    </div>
                                 </div>
                                 <a href="javascript:;" class="btn-registration" onclick="showModalTrial(this, 4, false)">Dùng thử</a>
                                 <div class="view-detail-xs d-block d-md-none"><a href="/bang-gia-sapo-pos.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></div>
                              </div>
                              <div class="extra-info">
                                 <strong>Gói dịch vụ bao gồm:<i class="d-block d-md-none fa fa-minus"></i></strong>
                                 <ul>
                                    <li>Sản phẩm không giới hạn</li>
                                    <li>Bán hàng trên Facebook</li>
                                    <li>Mã VNPay QR độc quyền</li>
                                    <li>Báo cáo bán hàng</li>
                                    <li>Quản lý cửa hàng, kho hàng</li>
                                    <li class="no-icon d-md-block d-none"><a href="/bang-gia-sapo-pos.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></li>
                                 </ul>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-4">
                                 <div class="item fnb">
                                    <span class="tag-promotion fnb price-fnb-covid" onclick="location.href='/bang-gia-sapo-fnb.html';"></span>
                                    <h2><a href="/phan-mem-quan-ly-nha-hang.html">Sapo FNB</a></h2>
                                    <p>Quản lý nhà hàng, quán cafe</p>
                                    <div class="price">
                                       <div>
                                          <span class="price-regular"><sup class="tu">Từ</sup><span class="price-inline">119.000</span><sup class="d">đ</sup><span class="date">/tháng</span></span>
                                       </div>
                                    </div>
                                    <a href="javascript:;" class="btn-registration" onclick="showModalTrialFnB(this)">Dùng thử</a>
                                    <div class="view-detail-xs d-block d-md-none"><a href="/bang-gia-sapo-fnb.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></div>
                                    <strong>Gói dịch vụ bao gồm:<i class="d-block d-md-none fa fa-plus"></i></strong>
                                    <ul>
                                       <li>1 nhà hàng</li>
                                       <li>10 thiết bị</li>
                                       <li>Không giới hạn món</li>
                                       <li>Quản lý thực đơn</li>
                                       <li>Báo cáo bán hàng</li>
                                       <li class="no-icon d-md-block d-none"><a href="/bang-gia-sapo-fnb.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="item go">
                                    <span class="tag-promotion go price-go-covid" onclick="location.href='/bang-gia-sapo-go.html';"></span>
                                    <h2><a href="/quan-ly-ban-hang-online.html">Sapo GO</a></h2>
                                    <p>Quản lý bán hàng online</p>
                                    <div class="price">
                                       <div>
                                          <span class="price-regular"><sup class="tu">Từ</sup><span class="price-inline">160.000</span><sup class="d">đ</sup><span class="date">/tháng</span></span>
                                       </div>
                                    </div>
                                    <a href="javascript:;" class="btn-registration" onclick="showModalTrial(this, 6, false)">Dùng thử</a>
                                    <div class="view-detail-xs d-block d-md-none"><a href="/bang-gia-sapo-go.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></div>
                                    <strong>Gói dịch vụ bao gồm:<i class="d-block d-md-none fa fa-plus"></i></strong>
                                    <ul>
                                       <li>Bán hàng trên Facebook</li>
                                       <li>Bán hàng trên Sàn TMĐT</li>
                                       <li>Ứng dụng chat đa sàn</li>
                                       <li>Đăng sản phẩm đa sàn chuẩn SEO</li>
                                       <li>Tự động chốt đơn livestream</li>
                                       <li class="no-icon d-md-block d-none"><a href="/bang-gia-sapo-go.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="item web">
                                    <span class="tag-promotion web-covid" onclick="location.href='/bang-gia-sapo-web.html';"></span>
                                    <h2><a href="/thiet-ke-website-ban-hang.html">Sapo Web</a></h2>
                                    <p>Thiết kế website bán hàng</p>
                                    <div class="price">
                                       <div>
                                          <span class="price-regular"><span class="price-inline">299.000</span><sup class="d">đ</sup><span class="date">/tháng</span></span>
                                       </div>
                                    </div>
                                    <a href="javascript:;" class="btn-registration" onclick="showModalTrial(this, 2, false)">Dùng thử</a>
                                    <div class="view-detail-xs d-block d-md-none"><a href="/bang-gia-sapo-web.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></div>
                                    <strong>Gói dịch vụ bao gồm:<i class="d-block d-md-none fa fa-plus"></i></strong>
                                    <ul>
                                       <li>Sản phẩm không giới hạn</li>
                                       <li>1 website bán hàng</li>
                                       <li>Dung lượng 5GB</li>
                                       <li>5 email tên miền</li>
                                       <li>Thanh toán trực tuyến</li>
                                       <li class="no-icon d-md-block d-none"><a href="/bang-gia-sapo-web.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="item omni">
                                    <span class="tag-promotion omni price-omni-covid" onclick="location.href='/bang-gia-sapo-omnichannel.html';"></span>
                                    <div class="name-price">
                                       <h2><a href="/omnichannel.html">V.I.P</a></h2>
                                       <p>Chuỗi phòng khám lớn</p>
                                       <div class="price">
                                          <div>
                                             <span class="price-regular"><span class="price-inline">599.000</span><sup class="d">đ</sup><span class="date">/tháng</span></span>
                                          </div>
                                       </div>
                                       <a href="javascript:;" class="btn-registration" onclick="showModalTrial(this, 5, true)">Dùng thử</a>
                                       <div class="view-detail-xs d-block d-md-none"><a href="/bang-gia-sapo-omnichannel.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></div>
                                    </div>
                                    <div class="extra-info">
                                       <strong>Gói dịch vụ bao gồm:<i class="d-block d-md-none fa fa-plus"></i></strong>
                                       <ul>
                                          <li>CRM và Marketing Automation</li>
                                          <li>Bán hàng trên Sàn TMĐT</li>
                                          <li>1 cửa hàng</li>
                                          <li>Bán hàng trên Facebook</li>
                                          <li>1 website bán hàng</li>
                                          <li class="no-icon d-md-block d-none"><a href="/bang-gia-sapo-omnichannel.html" class="icon">Xem chi tiết bảng giá <i class="fa fa-angle-double-right"></i></a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <p class="notice">
                        <b>* Lưu ý</b>: Bảng giá trên chưa bao gồm phí khởi tạo 1.500.000đ cho gói Sapo web và 2.000.000đ cho gói Sapo Omni.<br />
                        Quý khách sẽ được miễn phí chi phí khởi tạo khi đăng ký sử dụng dịch vụ Sapo Web, Sapo Omnichannel từ 2 năm trở lên.
                     </p>
                  </div>
               </div>
               <div class="advisory">
                  <div class="container">
                     <h2>Bạn chưa chọn được gói dịch vụ phù hợp ?</h2>
                     <p class="desc">
                        Hãy đăng ký dùng thử để trải nghiệm phần mềm để có lựa chọn phù hợp nhé
                     </p>
                     <a class="btn-registration" href="javascript:;" onclick="showModalTrial(this, 1, false)">Dùng thử miễn phí</a>
                  </div>
               </div>
               <div class="selling-machine text-center">
                  <div class="container">
                     <h2>Nếu bạn muốn sở hữu những thiết bị tăng tốc bán hàng</h2>
                     <p class="d-none d-md-block">Tham khảo ngay dòng máy bán hàng <br class="d-block d-md-none" />đã tích hợp sẵn cả phần cứng <br class="d-block d-md-none" />và phần mềm Sapo</p>
                     <p class="d-block d-md-none">
                        Tham khảo ngay thiết bị bán hàng <br class="d-block d-md-none" />đã tích hợp sẵn cả phần cứng <br class="d-block d-md-none" /> và phần mềm Sapo dành cho
                     </p>
                     <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                           <a class="nav-link active" data-toggle="tab" href="#machine-retail" role="tab" aria-controls="machine-retail" aria-selected="true">
                              <div class="d-md-block d-none">Bộ thiết bị <br class="d-block d-sm-none" />dành riêng cho</div>
                              <span>CỬA HÀNG <br class="d-block d-sm-none" />BÁN LẺ</span>
                           </a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" data-toggle="tab" href="#machine-fnb" role="tab" aria-controls="profile" aria-selected="false">
                              <div class="d-md-block d-none">Bộ thiết bị <br class="d-block d-sm-none" />chuyên dụng cho</div>
                              <span>NHÀ HÀNG, <br class="d-block d-sm-none" />QUÁN CAFE</span>
                           </a>
                        </li>
                     </ul>
                     <div class="tab-content">
                        <div class="tab-pane fade show active" id="machine-retail" role="tabpanel">
                           <div class="swiper-container">
                              <div class="swiper-wrapper">
                                 <div class="swiper-slide item s2-basic">
                                    <h3>Sapo S2</h3>
                                    <p>Thiết bị bán hàng chuyên nghiệp cho chuỗi <br class="d-none d-xl-block" />cửa hàng bán lẻ</p>
                                    <p class="price">Giá: <span>15.900.000đ</span></p>
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/machine-sapo-s2-update.png')); ?>" alt="Sapo S2" />
                                    <div class="content-detail">
                                       <ul>
                                          <li>Bán hàng trên màn hình cảm ứng 15.6 inch</li>
                                          <li>Khách hàng theo dõi đơn hàng trên màn hình phụ</li>
                                          <li>Tích hợp máy in nhiệt khổ 80mm ngay trên thân máy</li>
                                          <li>Tích hợp sẵn phần mềm quản lý bán hàng Sapo POS gói 1 năm **</li>
                                       </ul>
                                       <div class="view-detail-selling-machine-xs d-block d-md-none">
                                          <span class="more-text">Xem chi tiết <i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                          <span class="less-text">Thu gọn <i class="fa fa-angle-up" aria-hidden="true"></i></span>
                                       </div>
                                    </div>
                                    <a href="javascript:;" class="btn-registration" onclick="loadViewPopupMachine('Sapo S2')">Tư vấn miễn phí</a>
                                 </div>
                                 <div class="swiper-slide item s2-mini">
                                    <h3>Sapo S2 Mini</h3>
                                    <p>
                                       Thiết bị bán hàng lý tưởng sử dụng cho các <br class="d-none d-xl-block" />cửa hàng bán lẻ
                                    </p>
                                    <p class="price">Giá: <span>11.500.000đ</span></p>
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/machine-sapo-s2mini-update.png')); ?>" alt="Sapo S2 Mini" />
                                    <div class="content-detail">
                                       <ul>
                                          <li>Màn hình cảm ứng mượt mà 15.6 inch hỗ trợ thao tác nhanh gọn</li>
                                          <li>Tích hợp máy in hóa đơn trên thân máy có tốc độ 200mm/s và khổ in lớn K80</li>
                                          <li>Đa dạng cổng kết nối với các thiết bị:  máy quét mã vạch, két đựng tiền, bàn phím,...</li>
                                          <li>Miễn phí 12 tháng sử dụng phần mềm quản lý bán hàng Sapo POS **</li>
                                       </ul>
                                       <div class="view-detail-selling-machine-xs d-block d-md-none">
                                          <span class="more-text">Xem chi tiết <i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                          <span class="less-text">Thu gọn <i class="fa fa-angle-up" aria-hidden="true"></i></span>
                                       </div>
                                    </div>
                                    <a href="javascript:;" class="btn-registration" onclick="loadViewPopupMachine('Sapo S2 mini')">Tư vấn miễn phí</a>
                                 </div>
                                 <div class="swiper-slide item sm-basic">
                                    <h3>Sapo SM Plus</h3>
                                    <p>Máy bán hàng nhỏ gọn dành riêng cho <br class="d-none d-xl-block" />cửa hàng bán lẻ vừa và nhỏ</p>
                                    <p class="price">Giá: <span>4.900.000đ</span></p>
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/machine-sapo-sm-update.png?v=1')); ?>" alt="Sapo SM" />
                                    <div class="content-detail">
                                       <ul>
                                          <li>Thiết bị nhỏ gọn giúp bạn bán hàng nhanh chóng, linh hoạt</li>
                                          <li>Tích hợp sẵn máy in hóa đơn, in 5000 hóa đơn liên tục và sắc nét</li>
                                          <li>Quét mã vạch bằng camera sau thân máy tiện lợi</li>
                                          <li>Miễn phí trọn đời ứng dụng quản lý bán hàng Sapo **</li>
                                       </ul>
                                       <div class="view-detail-selling-machine-xs d-block d-md-none">
                                          <span class="more-text">Xem chi tiết <i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                          <span class="less-text">Thu gọn <i class="fa fa-angle-up" aria-hidden="true"></i></span>
                                       </div>
                                    </div>
                                    <a href="javascript:;" class="btn-registration" onclick="loadViewPopupMachine('Sapo SM')">Tư vấn miễn phí</a>
                                 </div>
                              </div>
                              <div class="swiper-pagination d-block d-lg-none"></div>
                           </div>
                        </div>
                        <div class="tab-pane fade" id="machine-fnb" role="tabpanel">
                           <div class="swiper-container">
                              <div class="swiper-wrapper">
                                
                                 <div class="swiper-slide item s2-fnb">
                                    <h3>Sapo FnB S2</h3>
                                    <p>Lựa chọn lý tưởng cho chuỗi <br class="d-none d-xl-block" />nhà hàng, quán cafe</p>
                                    <p class="price">Giá: <span>15.900.000đ</span></p>
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/machine-fnb-s2.png')); ?>" alt="Sapo FnB S2" />
                                    <div class="content-detail">
                                       <ul>
                                          <li>Màn hình cảm ứng 15.6 inch siêu nhạy với tốc độ xử  lý cực nhanh.</li>
                                          <li>Màn hình phụ giúp khách hàng theo dõi đơn hàng dễ dàng.</li>
                                          <li>Tích hợp máy in hóa đơn nhiệt khổ 80mm ngay trên thân máy.</li>
                                          <li>1.5 năm sử dụng phần mềm quản lý nhà hàng, quán cafe Sapo FnB **</li>
                                       </ul>
                                       <div class="view-detail-selling-machine-xs d-block d-md-none">
                                          <span class="more-text">Xem chi tiết <i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                          <span class="less-text">Thu gọn <i class="fa fa-angle-up" aria-hidden="true"></i></span>
                                       </div>
                                    </div>
                                    <a href="javascript:;" class="btn-registration" onclick="loadViewPopupMachine('Sapo FnB S2')">Tư vấn miễn phí</a>
                                 </div>
                                 <div class="swiper-slide item s2-fnb">
                                    <h3>Sapo FnB S2 Mini</h3>
                                    <p>Máy bán hàng chuyên dụng cho <br class="d-none d-xl-block" />nhà hàng, quán cafe</p>
                                    <p class="price">Giá: <span>11.500.000đ</span></p>
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/machine-fnb-s2mini.png')); ?>" alt="Sapo FnB S2 Mini" />
                                    <div class="content-detail">
                                       <ul>
                                          <li>Thao tác tạo đơn hàng đơn giản với màn hình cảm ứng siêu nhạy.</li>
                                          <li>Máy in hóa đơn tốc độ 200mm/s khổ giấy 80mm trên thân máy.</li>
                                          <li>Máy bán hàng kết nối được nhiều thiết bị ngoại vi: két đựng tiền, loa...</li>
                                          <li>Tích hợp sẵn 18 tháng sử dụng phần mềm quản lý nhà hàng Sapo FnB **</li>
                                       </ul>
                                       <div class="view-detail-selling-machine-xs d-block d-md-none">
                                          <span class="more-text">Xem chi tiết <i class="fa fa-angle-down" aria-hidden="true"></i></span>
                                          <span class="less-text">Thu gọn <i class="fa fa-angle-up" aria-hidden="true"></i></span>
                                       </div>
                                    </div>
                                    <a href="javascript:;" class="btn-registration" onclick="loadViewPopupMachine('Sapo FnB S2 mini')">Tư vấn miễn phí</a>
                                 </div>
                                
                              </div>
                              <div class="swiper-pagination d-block d-xl-none"></div>
                           </div>
                        </div>
                     </div>
                     <div class="cs">** Chính sách tặng phần mềm chỉ áp dụng với khách hàng ký mới</div>
                  </div>
               </div>
               <div class="sapo-shop">
                  <div class="container">
                     <p>Ngoài ra, bạn có thể tham khảo thêm</p>
                     <h2>Những thiết bị bán hàng riêng lẻ của Sapo Shop</h2>
                     <div class="bg-slide">
                        <div class="swiper-container">
                           <div class="swiper-wrapper">
                             
                              <div class="item swiper-slide">
                                 <div class="product-box product-grid-item">
                                    <div class="product-thumbnail">
                                       <a href="#" target="_blank" title="Máy in hóa đơn Bluetooth APOS P100" rel="nofollow">
                                       <img class="img-fluid swiper-lazy" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/Images/image-transparent.png')); ?>" data-src="//bizweb.dktcdn.net/100/091/193/products/may-in-hoa-don-bluetooth-p100-chinh-hang-saposhop-9.jpg?v=1601631987000" alt="may-in-hoa-don-bluetooth-apos-p100" />
                                       </a>
                                    </div>
                                    <div class="product-info">
                                       <h3 class="product-name text1line">
                                          <a href="https://shop.sapo.vn/may-in-hoa-don-apos-p100-1" target="_blank" title="Máy in hóa đơn Bluetooth APOS P100" rel="nofollow">
                                          Máy in hóa đơn Bluetooth APOS P100
                                          </a>
                                       </h3>
                                       <div class="price-box price-loop-style">
                                          <span class="special-price">
                                          <span class="price">2.200.000đ</span>
                                          </span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="item swiper-slide">
                                 <div class="product-box product-grid-item">
                                    <div class="product-thumbnail">
                                       <a href="https://shop.sapo.vn/may-in-hoa-don-sapo-printer-sp03-lan" target="_blank" title="Máy in hóa đơn Sapo Printer SP03 (LAN)" rel="nofollow">
                                       <img class="img-fluid swiper-lazy" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/Images/image-transparent.png')); ?>" data-src="https://bizweb.dktcdn.net/thumb/large/100/091/193/products/may-in-hoa-don-sapo-printer-sp03-lan-saposhop-3.jpg?v=1596772736897" alt="may-in-hoa-don-sapo-printer-sp03-lan" />
                                       </a>
                                    </div>
                                    <div class="product-info">
                                       <h3 class="product-name text1line">
                                          <a href="https://shop.sapo.vn/may-in-hoa-don-sapo-printer-sp03-lan" target="_blank" title="Máy in hóa đơn Sapo Printer SP03 (LAN)" rel="nofollow">
                                          Máy in hóa đơn Sapo Printer SP03 (LAN)
                                          </a>
                                       </h3>
                                       <div class="price-box price-loop-style">
                                          <span class="special-price">
                                          <span class="price">1.900.000đ</span>
                                          </span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="item swiper-slide">
                                 <div class="product-box product-grid-item">
                                    <div class="product-thumbnail">
                                       <a href="https://shop.sapo.vn/may-quet-ma-vach-sapo-scanner-ss1" target="_blank" title="Máy quét mã vạch Sapo Scanner SS1" rel="nofollow">
                                       <img class="img-fluid swiper-lazy" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/Images/image-transparent.png')); ?>" data-src="//bizweb.dktcdn.net/thumb/medium/100/091/193/products/may-quet-ma-vach-1.jpg?v=1559550412000" alt="may-quet-ma-vach-sapo-scanner-ss1" />
                                       </a>
                                    </div>
                                    <div class="product-info">
                                       <h3 class="product-name text1line">
                                          <a href="https://shop.sapo.vn/may-quet-ma-vach-sapo-scanner-ss1" target="_blank" title="Máy quét mã vạch Sapo Scanner SS1" rel="nofollow">
                                          Máy quét mã vạch Sapo Scanner SS1
                                          </a>
                                       </h3>
                                       <div class="price-box price-loop-style">
                                          <span class="special-price">
                                          <span class="price">1.450.000đ</span>
                                          </span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="item swiper-slide">
                                 <div class="product-box product-grid-item">
                                    <div class="product-thumbnail">
                                       <a href="https://shop.sapo.vn/may-in-ma-vach-sapo-printer-spl01" target="_blank" title="Máy in mã vạch Sapo Printer SPL01" rel="nofollow"> 
                                       <img class="img-fluid swiper-lazy" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/Images/image-transparent.png')); ?>" data-src="//bizweb.dktcdn.net/thumb/medium/100/091/193/products/may-in-tem-nhan-1.jpg?v=1562208180000" alt="may-in-ma-vach-sapo-printer-spl01" />
                                       </a>
                                    </div>
                                    <div class="product-info">
                                       <h3 class="product-name text1line">
                                          <a href="https://shop.sapo.vn/may-in-ma-vach-sapo-printer-spl01" target="_blank" title="Máy in mã vạch Sapo Printer SPL01" rel="nofollow">
                                          Máy in mã vạch Sapo Printer SPL01
                                          </a>
                                       </h3>
                                       <div class="price-box price-loop-style">
                                          <span class="special-price">
                                          <span class="price">2.850.000đ</span>
                                          </span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="item swiper-slide">
                                 <div class="product-box product-grid-item">
                                    <div class="product-thumbnail">
                                       <div class="product-label">
                                          <span class="sale-flash">-12% </span>
                                       </div>
                                       <a href="https://shop.sapo.vn/bo-san-pham-pro" target="_blank" title="Bộ sản phẩm Pro" rel="nofollow">
                                       <img class="img-fluid swiper-lazy" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/Images/image-transparent.png')); ?>" data-src="//bizweb.dktcdn.net/100/091/193/products/combo-2.jpg?v=1562811603140" alt="bo-san-pham-pro" />
                                       </a>
                                    </div>
                                    <div class="product-info">
                                       <h3 class="product-name text1line">
                                          <a href="https://shop.sapo.vn/bo-san-pham-pro" target="_blank" title="Bộ sản phẩm Pro" rel="nofollow">
                                          Bộ sản phẩm Pro
                                          </a>
                                       </h3>
                                       <div class="price-box price-loop-style">
                                          <span class="special-price">
                                          <span class="price">9.148.000đ</span>
                                          </span>
                                          <span class="old-price">
                                          <span> | </span>
                                          <span class="price">
                                          10.396.000đ
                                          </span>
                                          </span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="swiper-pagination d-block d-lg-none"></div>
                        </div>
                        <div class="swiper-button-prev d-none d-lg-block"><i class="fa fa-angle-left"></i></div>
                        <div class="swiper-button-next d-none d-lg-block"><i class="fa fa-angle-right"></i></div>
                     </div>
                     <a href="https://shop.sapo.vn" class="btn-registration" target="_blank" rel="nofollow">Xem thêm thiết bị khác</a>
                  </div>
               </div>
               <div class="faq">
                  <div class="container">
                     <h2>Một số câu hỏi thường gặp</h2>
                     <div class="box-question">
                        <div class="question active">
                           <h4 data-number="1.">
                              1. Tôi được dùng thử dịch vụ trong vòng bao lâu? Nếu tôi muốn mua gói dịch vụ chính thức thì tôi phải làm gì?
                              <i class="icon"></i>
                           </h4>
                           <p>
                              Bạn có thể đăng ký để được trải nghiệm miễn phí Sapo trong vòng 7 ngày. Chuyên viên tư vấn của Sapo sẽ luôn đồng hành với bạn trong suốt thời gian dùng thử để giải đáp các yêu cầu, thắc mắc của bạn cũng như hỗ trợ bạn khi mua gói dịch vụ chính thức. Ngoài ra, đội ngũ chăm sóc khách hàng của chúng tôi luôn sẵn sàng hỗ trợ bạn qua hotline 1900 6750.
                           </p>
                        </div>
                        <div class="question">
                           <h4 data-number="2.">
                              2. Phí khởi tạo có bao gồm trong giá gói dịch vụ không? Phí này được thu 1 lần duy nhất đúng không?
                              <i class="icon"></i>
                           </h4>
                           <p>
                              Bạn thân mến, trong giá gói dịch vụ chưa bao gồm phí khởi tạo. Phí khởi tạo sẽ được tính duy nhất 1 lần khi bạn ký hợp đồng chính thức sử dụng dịch vụ.  Đặc biệt, nếu bạn ký hợp đồng dịch vụ 2 năm trở lên sẽ được miễn phí khởi tạo.
                           </p>
                        </div>
                        <div class="question">
                           <h4 data-number="3.">
                              3. Nếu tôi đang dùng Sapo Web mà muốn dùng thêm tính năng quản lý bán hàng thì tính phí như thế nào?
                              <i class="icon"></i>
                           </h4>
                           <p>
                              Nếu bạn đang dùng Sapo Web và muốn dùng thêm tính năng quản lý bán hàng, bạn có thể dùng đồng thời 2 gói POS và Web hoặc có thể sử dụng gói Omnichannel chỉ với 599,000đ/tháng (đã bao gồm thiết kế website và phần mềm quản lý bán hàng).
                           </p>
                        </div>
                        <div class="question">
                           <h4 data-number="4.">
                              4. Tôi đang dùng gói Sapo POS với 1 cửa hàng, nay tôi muốn mở rộng và mua thêm cửa hàng thì tính phí như thế nào?
                              <i class="icon"></i>
                           </h4>
                           <p>
                              Với các khách hàng đang sử dụng gói Sapo POS hoặc Sapo Omnichannel, chi phí để mua thêm cửa hàng là 150,000đ/cửa hàng/tháng. <br />
                              Đặc biệt, nếu mua thêm cửa hàng từ 2 năm trở lên sẽ được chiết khấu từ 10% đến 22%.
                           </p>
                        </div>
                        <div class="question">
                           <h4 data-number="5.">
                              5. Khi hết thời gian sử dụng dịch vụ, tôi muốn gia hạn dịch vụ thì chi phí như thế nào?
                              <i class="icon"></i>
                           </h4>
                           <p>
                              Tùy vào thời điểm bạn gia hạn dịch vụ mà % chiết khấu sẽ khác nhau. Bạn gia hạn càng sớm sẽ càng được chiết khấu nhiều. Chiết khấu tối đa lên tới 55%.
                           </p>
                        </div>
                        <div class="question">
                           <h4 data-number="6.">
                              6. Nếu website hết dung lượng, tôi muốn mua thêm dung lượng thì có được không và chi phí như thế nào?
                              <i class="icon"></i>
                           </h4>
                           <p>
                              Bạn hoàn toàn có thể mua thêm dung lượng cho Website với mức phí là 120.000VND/1GB/tháng . Nếu mua dung lượng từ 2 năm trở lên sẽ được chiết khấu từ 10% - 22%.
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="register-bottom clearfix">
                  <div class="container">
                     <h2>Bắt đầu đăng ký landing page miễn phí</h2>
                     <p>Tạo website chuẩn nha khoa miễn phí ngay hôm nay</p>
                     <div class="reg-form">
                        <input id="site_name_bottom" class="input-site-name d-none d-md-inline-block" type="text" value="" placeholder="Nhập tên cửa hàng/doanh nghiệp của bạn" onkeypress="return onInputStoreName(event, this)">
                        <a class="btn-registration banner-home-registration event-Sapo-Free-Trial-form-open" onclick="showModalTrial(this, 1, false);" href="javascript:;">Dùng thử miễn phí</a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal fade" id="PopupPromotion" role="dialog" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-body">
                        <button type="button" class="close close-covid" data-dismiss="modal" aria-label="Close">&times;</button>
                        <a href="javascript:;" onclick="showTrialPromotion()">
                        <img class="d-none d-md-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-pos-web.png?v=9')); ?>" alt="Sapo trợ giá giúp nhà bán hàng vượt qua mùa Cô Vy" />
                        <img class="d-block d-md-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-pos-m.png?v=9')); ?>" alt="Sapo trợ giá giúp nhà bán hàng vượt qua mùa Cô Vy" />
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal fade" id="PopupPromotionWeb" role="dialog" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-body">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
                        <a href="javascript:;" onclick="showTrialPromotionWeb()">
                        <img class="d-none d-md-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-webcovid-web.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" />
                        <img class="d-block d-md-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-webcovid-m.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" style=" width: 100%;" />
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal fade" id="PopupPromotionWebCovid" role="dialog" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-body">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
                        <a href="javascript:;" onclick="showTrialPromotionWebCovid()">
                        <img class="d-none d-md-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-webcovid-web.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" />
                        <img class="d-block d-md-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-webcovid-m.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" style="width: 100%;" />
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal fade" id="PopupPromotionGo" role="dialog" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-body">
                        <button type="button" class="close close-covid" data-dismiss="modal" aria-label="Close">&times;</button>
                        <a href="javascript:;" onclick="showTrialPromotionGo()">
                        <img class="d-none d-md-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-go-web.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" />
                        <img class="d-block d-md-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-go-m.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" style="width: 100%;" />
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal fade" id="PopupPromotionFnb" role="dialog" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-body">
                        <button type="button" class="close close-covid" data-dismiss="modal" aria-label="Close">&times;</button>
                        <a href="javascript:;" onclick="showTrialPromotionFnb(this)">
                        <img class="d-none d-md-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-fnb-web.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" />
                        <img class="d-block d-md-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-fnb-m.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" style="width: 100%;" />
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal fade" id="PopupPromotionOmni" role="dialog" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                     <div class="modal-body">
                        <button type="button" class="close close-covid" data-dismiss="modal" aria-label="Close">&times;</button>
                        <a href="javascript:;" onclick="showTrialPromotionOmni()">
                        <img class="d-none d-md-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-omni-web.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" />
                        <img class="d-block d-md-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/home/price/popup-promotion-omni-m.png?v=9')); ?>" alt="Chung tay cùng nhà bán hàng vượt qua bão Covid-19" style="width: 100%;" />
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <script>
               function popupPromotion() {
                   $('#PopupPromotion').modal({ backdrop: 'static', keyboard: false });
               }
               function showTrialPromotion() {
                   $('#PopupPromotion').modal('hide');
                   showModalTrial(this, 4, false);
               }
               
               function popupPromotionWeb() {
                   $('#PopupPromotionWeb').modal({ backdrop: 'static', keyboard: false });
               }
               function showTrialPromotionWeb() {
                   $('#PopupPromotionWeb').modal('hide');
                   showModalTrial(this, 2, false);
               }
               
               function popupPromotionWebCovid() {
                   $('#PopupPromotionWebCovid').modal({ backdrop: 'static', keyboard: false });
               }
               function showTrialPromotionWebCovid() {
                   $('#PopupPromotionWebCovid').modal('hide');
                   showModalTrial(this, 2, false);
               }
               
               
               function popupPromotionGo() {
                   $('#PopupPromotionGo').modal({ backdrop: 'static', keyboard: false });
               }
               function showTrialPromotionGo() {
                   $('#PopupPromotionGo').modal('hide');
                   showModalTrial(this, 6, false);
               }
               
               function popupPromotionFnb() {
                   $('#PopupPromotionFnb').modal('hide');
                   $('#PopupPromotionFnb').modal({ backdrop: 'static', keyboard: false });
               }
               function showTrialPromotionFnb() {
                   $('#PopupPromotionFnb').modal('hide');
                   showModalTrialFnB(this);
               }
               
               function popupPromotionOmni() {
                   $('#PopupPromotionOmni').modal({ backdrop: 'static', keyboard: false });
               }
               function showTrialPromotionOmni() {
                   $('#PopupPromotionOmni').modal('hide');
                   showModalTrial(this, 5, false);
               }
            </script>
            <div id="myModal-tuvan-advisory" class="modal fade modal-register modal-register-sso" role="dialog"></div>
            <div id="modalRegisterSuccess-advisory" class="modal fade modal-register modal-register-success-default" role="dialog"></div>
            <div id="myModal-tuvan-machine" class="modal fade modal-register modal-register-sso" role="dialog"></div>
            <div id="modalRegisterSuccess-machine" class="modal fade modal-register modal-register-success-default" role="dialog"></div>
            <script type="text/javascript">
               addLoadEvent(function () {
                   $('.packages .item strong').on('click', function () {
                       if ($(window).width() < 768) {
                           var button = $(this),
                               item = button.parent().find('li');
                           console.log(button);
                           if (button.find('.fa-minus').length > 0) {
                               item.hide();
                               button.find('.fa').removeClass('fa-minus').addClass('fa-plus');
                           } else {
                               item.show();
                               button.find('.fa').addClass('fa-minus').removeClass('fa-plus');
                           }
                       }
                   });
               
                   var sapoShopSwiper = new Swiper('.sapo-shop .swiper-container', {
                       slidesPerView: 4,
                       spaceBetween: 30,
                       autoplay: {
                           delay: 5000,
                       },
                       loop: true,
                       preventClicks: false,
                       preventClicksPropagation: false,
                       simulateTouch: true,
                       preloadImages: false,
                       lazy: true,
                       pagination: {
                           el: '.sapo-shop .swiper-pagination',
                           clickable: true,
                       },
                       navigation: {
                           nextEl: '.sapo-shop .swiper-button-next',
                           prevEl: '.sapo-shop .swiper-button-prev',
                       },
                       breakpoints: {
                           767: {
                               slidesPerView: 2
                           },
                           991: {
                               slidesPerView: 3
                           },
                           1199: {
                               slidesPerView: 4
                           }
                       }
                   });
               
                   var machineRetailSwiper = new Swiper('#machine-retail .swiper-container', {
                       slidesPerView: 3,
                       preventClicks: false,
                       preventClicksPropagation: false,
                       simulateTouch: false,
                       observer: true,
                       observeParents: true,
                       pagination: {
                           el: '#machine-retail .swiper-pagination',
                           clickable: true,
                       },
                       breakpoints: {
                           767: {
                               slidesPerView: 1
                           },
                           991: {
                               slidesPerView: 2
                           },
                           1199: {
                               slidesPerView: 3
                           }
                       }
                   });
               
                   var machineFnbSwiper = new Swiper('#machine-fnb .swiper-container', {
                       slidesPerView: 2,
                       preventClicks: false,
                       preventClicksPropagation: false,
                       simulateTouch: false,
                       observer: true,
                       observeParents: true,
                       pagination: {
                           el: '#machine-fnb .swiper-pagination',
                           clickable: true,
                       },
                       breakpoints: {
                           767: {
                               slidesPerView: 1
                           },
                           991: {
                               slidesPerView: 2
                           },
                           1199: {
                               slidesPerView: 2
                           }
                       }
                   });
               
                   $(".faq h4").click(function () {
                       if ($(this).parent().hasClass('active')) {
                           $(this).parent().removeClass("active");
                       } else {
                           $(".faq .question").removeClass("active");
                           $(this).parent().addClass("active");
                       }
                   });
               
                   $('.view-detail-selling-machine-xs').on('click', function (e) {
                       e.preventDefault();
                       var $this = $(this);
                       $this.parents('.content-detail').toggleClass('expanded');
                       return false;
                   });
               
                   sapoShopSwiper.on('slideChangeTransitionEnd', function () {
                       $(".swiper-slide").not('.swiper-slide-active').find(".content-detail").removeClass('expanded');
                   });
               });
               
               // Popup Advisory
               function showAdvisoryForm() {
                   $.get("/ConsultingRequests/AdvisoryContact/Register", function (data, status) {
                       if (status == 'success') {
                           $('.modal-register').html('');
                           var modalAdvisory = $('#myModal-tuvan-advisory');
                           modalAdvisory.html(data);
                           modalAdvisory.modal({ backdrop: false, keyboard: false });
                           modalAdvisory.modal('show');
                           modalAdvisory.find('input[type="text"], input[type="tel"], input[type="email"], input[type="password"]').on('change keyup input', function () {
                               var input = $(this);
                               if (input.val() == '') {
                                   input.removeClass('has-value');
                               } else {
                                   input.addClass('has-value');
                               }
                           });
                       }
                   });
               }
               
               function loadViewPopupSuccess() {
                   $.get("/ConsultingRequests/AdvisoryContact/RegisterSuccess", function (data, status) {
                       if (status == 'success') {
                           $('.modal-register').html('');
                           var modalAdvisory = $('#myModal-tuvan-advisory');
                           var modalAdvisorySuccess = $('#modalRegisterSuccess-advisory');
                           modalAdvisory.modal('hide');
                           modalAdvisorySuccess.html(data);
                           setTimeout(function () { modalAdvisorySuccess.modal({ backdrop: false, keyboard: false }); }, 500);
                       }
                   });
               }
               
               function submitDataAdvisory() {
                   var $form = $('form#form-request-advisory');
                   $form.find('.field-validation-valid[data-valmsg-for="Captcha"]').html("");
                   if (!$form.valid()) {
                       return false;
                   }
               
                   $.post($form.attr('action'), $form.serialize(), function (data, status) {
                       if (status == 'success') {
                           if (data.status == "Ok") {
                               loadViewPopupSuccess();
                           }
                           else if (data.status == "Error") {
                               console.log('lỗi');
                           }
                           else if (data.status == "ValidateCapcha") {
                               $form.find('.field-validation-valid[data-valmsg-for="Captcha"]').html("Sai mã an toàn");
                               $form.find('.field-validation-valid[data-valmsg-for="Captcha"]').css('color', '#a94442');
                           }
                       }
                   });
               }
               //=========================================//
               
               // Popup Machine
               function loadViewPopupMachine(type) {
                   $.get("/ConsultingRequests/SellingMachine/Register", function (data, status) {
                       if (status == 'success') {
                           $('.modal-register').html('');
                           var modalMachine = $('#myModal-tuvan-machine');
                           modalMachine.html(data);
                           modalMachine.modal({ backdrop: false, keyboard: false });
                           modalMachine.modal('show');
                           modalMachine.find('#Service').val(type);
                           modalMachine.find('input[type="text"], input[type="tel"], input[type="email"], input[type="password"]').on('change keyup input', function () {
                               var input = $(this);
                               if (input.val() == '') {
                                   input.removeClass('has-value');
                               } else {
                                   input.addClass('has-value');
                               }
                           });
                       }
                   });
               }
               
               function loadViewPopupSuccessMachine() {
                   $.get("/ConsultingRequests/SellingMachine/RegisterSuccess", function (data, status) {
                       if (status == 'success') {
                           $('.modal-register').html('');
                           var modalMachine = $('#myModal-tuvan-machine');
                           modalMachine.modal('hide');
                           var modalMachineSuccess = $('#modalRegisterSuccess-machine');
                           modalMachineSuccess.html(data);
                           setTimeout(function () { modalMachineSuccess.modal({ backdrop: false, keyboard: false }); }, 500);
                       }
                   });
               }
               
               function submitDataMachine() {
                   var $form = $('form#form-request-machine');
                   $form.find('.field-validation-valid[data-valmsg-for="Captcha"]').html("");
                   var validate = false;
               
                   if (!$form.valid()) validate = true;
               
                   if ($form.find('#CityDistrict').val() != '') {
                       $form.find('span.field-validation-valid[data-valmsg-for="CityDistrict"]').html('');
                   } else {
                       $form.find('span.field-validation-valid[data-valmsg-for="CityDistrict"]').html('Nhập vào Quận/huyện');
                       $form.find('span.field-validation-valid[data-valmsg-for="CityDistrict"]').css('color', '#a94442');
                       validate = true;
                   }
               
                   if (validate) return false;
                   $.post($form.attr('action'), $form.serialize(), function (data, status) {
                       if (status == 'success') {
                           if (data.status == "Ok") {
                               loadViewPopupSuccessMachine();
                           }
                           else if (data.status == "Error") {
                               console.log('lỗi');
                           }
                           else if (data.status == "ValidateCapcha") {
                               $form.find('.field-validation-valid[data-valmsg-for="Captcha"]').html("Sai mã an toàn");
                               $form.find('.field-validation-valid[data-valmsg-for="Captcha"]').css('color', '#a94442');
                           }
                       }
                   });
               }
               //=========================================//
            </script>
         </div>
         <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- Banner marketing -->
         <style type="text/css">
            .sapo-advertiser {
            position: fixed;
            bottom: 0;
            left: 0;
            z-index: 999;
            }
            .sapo-advertiser a {
            outline: none;
            }
            .sapo-advertiser .popup-adv {
            position: relative;
            }
            .sapo-advertiser .popup-adv i {
            z-index: 99;
            color: #333;
            font-size: 24px;
            cursor: pointer;
            height: 15px;
            width: 15px;
            line-height: 15px;
            }
            .sapo-advertiser .popup-adv .hide-popup {
            position: absolute;
            right: -15px;
            top: 0;
            }
            .sapo-advertiser .popup-adv .hide-popup.active {
            top: 0;
            right: 0;
            }
         </style>
         <script type="text/javascript">
            addLoadEvent(function () {
                var checkHide = sessionStorage.getItem("hide_banner");
                if (checkHide == null) {
                    $(".sapo-advertiser").show();
                }
            
                $(".sapo-advertiser .popup-adv .hide-popup").click(function () {
                    $(".sapo-advertiser").hide();
                    sessionStorage.setItem("hide_banner", "true");
                });
            });
         </script>
         <
      </div>
      <img class="scroll-top" data-src="<?php echo e(asset('website/Themes/Portal/Default/Images/totop.png')); ?>" alt="Lên đầu trang" style="display:none;cursor :pointer; position : fixed;bottom : 90px;right : 33px;z-index : 99;" />
      
      
      
     
   </body>
</html><?php /**PATH /home/dthdenta/public_html/media/resources/views/frontend/banggia.blade.php ENDPATH**/ ?>
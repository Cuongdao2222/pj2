<!-- Namecategory Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('namecategory', 'Namecategory:'); ?>

    <?php echo Form::text('namecategory', null, ['class' => 'form-control']); ?>

</div><?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/categories/fields.blade.php ENDPATH**/ ?>
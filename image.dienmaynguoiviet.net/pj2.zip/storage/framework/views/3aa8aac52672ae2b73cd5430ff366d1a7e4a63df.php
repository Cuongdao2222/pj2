<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH C:\Users\cuong123\Desktop\demo1.dthdental.vn\resources\views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>
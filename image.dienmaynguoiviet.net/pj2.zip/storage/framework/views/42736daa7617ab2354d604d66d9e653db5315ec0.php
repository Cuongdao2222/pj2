

<?php $__env->startSection('content'); ?>

<div class="box_breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="/">Trang chủ</a></li>
            <li><a href="/chinh-nha" title="Chỉnh nha">Chỉnh nha</a></li>
        </ul>
    </div>
</div>
<div class="wrapper">
    <div class="container">
        <div class="box_module">
            <div class="box_title">
                <h1 class="title"><a href="/chinh-nha" title="Chỉnh nha">Chỉnh nha</a></h1>
            </div>
            <div class="box_content">
                <div class="layout_category_product">
                    <div class="productGrid service">
                        <div class="row">
                             <?php 

                        		$feedback = App\Models\post::where('category', 10)->take(2)->get();
                        	?>
                        	<?php if(count($feedback)>0): ?>
                        	<?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><img src="<?php echo e(@url($newss['image'])); ?>" alt="<?php echo e(@$newss['title']); ?>"><span>Xem thêm</span></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><?php echo e(@$newss['title']); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('frontend.khachhangdanhgia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/frontend/chinhnha.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
 <!--End Main Header --><!-- InstanceBeginEditable name="maincontent" -->
    <!-- Banner Section Two -->
    <section class="banner-section-two-inner " id="page">
        <div class="pattern-layer" style="background-image: url(images/background/18-short-col1.png)"></div>
        <div class="pattern-layer-twob" style="background-image: url(images/background/19-shortb-col1.png)"></div>
        <div class="auto-container">
            <div class="row clearfix">
                <!-- Content Column -->
                <div class="content-column col-lg-12 col-md-12 col-sm-12">
                    <div class="wow fadeInLeft pt-3" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <h1 contenteditable="true">About Dental Media</h1>
                        <div  class="text text-center">
                            <div class="featured-block-vrj  wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="bigtext" contenteditable="true">We are a team of dedicated web design and marketing experts. We specialise in digital marketing for dentists. </div>
                            </div>
                            <a href="contact-dental-media.html" class="theme-btn btn-style-five text-white mt-1"><span class="txt" contenteditable="true">get a quote</span></a>
                        </div>
                    </div>
                </div>
                <!-- Services Block  -->
                <div class="col-12 text-center">
                    <div class="headingstyle">
                        <h3 class="text-primary" contenteditable="true">Find out more about dental media.....</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <!-- Featured Block Three -->
                    <div class="featured-block-three">
                        <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <a href="dentist-websites-testimonials.html">
                                <div class="icon-box">
                                    <span class="icon"><img src="images/services-testimonials.svg" width="110" alt="Testimonials" /></span>
                                </div>
                                <h3 class="minheight1" contenteditable="true">Testimonials</h3>
                                <div  class="theme-btn btn-style-five text-white mt-1"><span class="txt" contenteditable="true">Read More</span></div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Services Block  -->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <!-- Featured Block Three -->
                    <div class="featured-block-three">
                        <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <a href="dental-marketing.html">
                                <div class="icon-box">
                                    <span class="icon"><img src="images/marketing-seo.svg" width="110" alt="Online Marketing" /></span>
                                </div>
                                <h3 class="minheight1" contenteditable="true">Marketing</h3>
                                <div  class="theme-btn btn-style-five text-white mt-1"><span class="txt" contenteditable="true">Read More</span></div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Services Block  -->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <!-- Featured Block Three -->
                    <div class="featured-block-three">
                        <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <a href="dental-websites.html">
                                <div class="icon-box">
                                    <span class="icon"><img src="images/dm-img3.svg" width="110" alt="Dental Websites" /></span>
                                </div>
                                <h3 class="minheight1" contenteditable="true">Websites</h3>
                                <div  class="theme-btn btn-style-five text-white mt-1"><span class="txt" contenteditable="true">Read More</span></div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Services Block  -->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <!-- Featured Block Three -->
                    <div class="featured-block-three">
                        <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <a href="marketing/index.html">
                                <div class="icon-box">
                                    <span class="icon"><img src="images/services-blog.svg" width="110" alt="Blog" /></span>
                                </div>
                                <h3 class="minheight1" contenteditable="true">Dental Media Blog</h3>
                                <div  class="theme-btn btn-style-five text-white mt-1"><span class="txt" contenteditable="true">Read More</span></div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="content-column col-lg-12 col-md-12 col-sm-12">
                    <div class="wow fadeInLeft pt-3" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div  class="text">
                            <p contenteditable="true">
                                At our heart is the creation of beautiful websites which attract more patients to your dental practice. By building a mutually beneficial partnership between ourselves and our clients, we strive to ensure long-standing relationships. Our business started back in the late 90's when we began website design and marketing for clinicians at The Eastman Dental Hospital and in Harley Street. However, this has grown considerably and we are now proud to support hundreds of dentists nation wide. 
                            </p>
                            <p contenteditable="true">
                                Many of our clients come by word-of-mouth recommendation or by transfer from other dental design companies.
                            </p>
                            <p> <a href="dentist-websites-testimonials.html" contenteditable="true">Read our client testimonials</a> </p>
                            <h3 contenteditable="true"> Some of our core values: </h3>
                            <div class="vrjlist">
                                <ul class="fa-ul">
                                    <li contenteditable="true"><span class="fa-li text-secondary "><i class="fa fa-check-square"></i></span>We strive to build the best-looking, hardest working dental websites  most cost effectively for you.</li>
                                    <li contenteditable="true"><span class="fa-li text-secondary "><i class="fa fa-check-square"></i></span>We do not force sell unnecessary &ldquo;add-on&rdquo;  services that deliver little other than additional cost. We aim to keep your  cost-of-ownership realistic.</li>
                                    <li contenteditable="true"><span class="fa-li text-secondary "><i class="fa fa-check-square"></i></span>We don&rsquo;t just work &ldquo;9 to 5&rdquo; &ndash; we understand that our clients are busy people and sometimes need to contact us outside of normal working hours. This is all part of our service.</li>
                                    <li contenteditable="true"><span class="fa-li text-secondary "><i class="fa fa-check-square"></i></span>We understand business and in particular the dental business. When we build websites we understand exactly what is necessary to  attract patients to you.</li>
                                    <li contenteditable="true"><span class="fa-li text-secondary "><i class="fa fa-check-square"></i></span>We stay ahead of our competitors by researching and understanding leading web technologies, whether optimisation for Google or accessibility to meet DDA laws.</li>
                                </ul>
                            </div>
                            <h3 contenteditable="true">Beautiful dentist websites are only part of our portfolio. We also provide: </h3>
                            <div class="vrjlist">
                                <ul class="fa-ul">
                                    <li contenteditable="true"><span class="fa-li text-primary "><i class="fa fa-check-square"></i></span>Full practice branding</li>
                                    <li contenteditable="true"><span class="fa-li text-primary "><i class="fa fa-check-square"></i></span>Practice literature including business cards, logos and promotional packs</li>
                                    <li contenteditable="true"><span class="fa-li text-primary "><i class="fa fa-check-square"></i></span>Promotional email campaigns</li>
                                    <li contenteditable="true"><span class="fa-li text-primary "><i class="fa fa-check-square"></i></span>Business class hosting services supporting  email, data back-ups and website visit statistics</li>
                                    <li contenteditable="true"><span class="fa-li text-primary "><i class="fa fa-check-square"></i></span>Search engine optimisation &ndash; our websites are prominent in Google</li>
                                    <li contenteditable="true"><span class="fa-li text-primary "><i class="fa fa-check-square"></i></span>Pay-per-Click set up and management</li>
                                    <li contenteditable="true"><span class="fa-li text-primary "><i class="fa fa-check-square"></i></span>Practice photography &ndash; don't get stuck with cheesy &quot;stock&quot; images; let us  manage a bespoke photo shoot at your practice</li>
                                    <li contenteditable="true"><span class="fa-li text-primary "><i class="fa fa-check-square"></i></span>Practice video and treatment animations</li>
                                </ul>
                            </div>
                        </div>
                        <a href="contact-dental-media.html" class="theme-btn btn-style-five text-white mt-1"><span class="txt" contenteditable="true">get a quote</span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class=" general-section">
        <div class="auto-container">
            <div class="row clearfix">
                <!-- Content Column -->
                <div class="content-column col-lg-12 col-md-12 col-sm-12">
                    <hr>
                    <div class="tagcloud01">
                        <ul>
                            <li contenteditable="true"><a href="services.html" class="tagtitle">About Us:</a></li>
                            <li contenteditable="true"><a href="dental-media.html" class="up">About Dental Media</a></li>
                            <li contenteditable="true"><a href="dentist-websites-testimonials.html">Testimonials</a></li>
                            <li contenteditable="true"><a href="marketing/index.html">Dental Media Blog</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <button class="click">click</button>
    <!-- Call To Action Section -->
    <section class="call-to-action-section bg2">
        <!-- Section Icons -->
        <div class="section-icons parallax-scene-2">
            <!-- Icon One -->
            <div data-depth="0.80" class="icon-one parallax-layer"></div>
            <!-- Icon Two -->
            <div data-depth="0.50" class="icon-two parallax-layer" style="background-image:url(images/icons/icon-22.png)"></div>
            <!-- Icon Three -->
            <div data-depth="0.50" class="icon-three parallax-layer"></div>
            <!-- Icon Four -->
            <div data-depth="0.30" class="icon-four parallax-layer"></div>
            <!-- Icon Five -->
            <div data-depth="0.20" class="icon-five parallax-layer" style="background-image:url(images/icons/icon-23.png)"></div>
            <!-- Icon Six -->
            <div data-depth="0.20" class="icon-six parallax-layer" style="background-image:url(images/icons/icon-24.png)"></div>
            <!-- Icon Seven -->
            <div data-depth="0.50" class="icon-seven parallax-layer" style="background-image:url(images/icons/icon-25.png)"></div>
            <!-- Icon Eight -->
            <div data-depth="0.40" class="icon-eight parallax-layer"></div>
            <!-- Icon Nine -->
            <div data-depth="0.10" class="icon-nine parallax-layer"></div>
        </div>
        <div class="auto-container">
            <!-- Sec Title -->
            <div class="sec-title light centered">
                <h2 contenteditable="true">Ready To Get Started?</h2>
                <div class="text limitwidth" contenteditable="true">Contact us today and we can chat about your requirements and how best we can help you achieve your dental marketing aims</div>
                <div class="mt-3"><a href="contact-dental-media.html" class="theme-btn btn-style-five text-white"><span class="txt" contenteditable="true">Contact Us</span></a></div>
            </div>
        </div>
    </section>

    <script type="text/javascript">
    	window.onload = function() {
		    var anchors = document.getElementsByTagName("a");
		    for (var i = 0; i < anchors.length; i++) {
		        anchors[i].onclick = function() {return false;};
		    }
		};
    </script>


<script type="text/javascript">
  
    $(document).ready(function () {
        $(".click").click(function(){
            var data = $('html').html();
            const namefile = 'test';

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });

            jQuery.ajax({
                url: "http://localhost:8000/testview",
                method: 'post',
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "data": data,
                    "namefile": namefile,
                },
                success: function(result){
                    console.log(result);
                    
                }
            });
        });   
        
    });
</script>
    <!-- InstanceEndEditable -->
    <!--Main Footer-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\New folder (7)\media\resources\views/frontend/home.blade.php ENDPATH**/ ?>



<li class="nav-item">
    <a href="<?php echo e(route('menus.index')); ?>"
       class="nav-link <?php echo e(Request::is('menus*') ? 'active' : ''); ?>">
        <p>Menus</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('posts.index')); ?>"
       class="nav-link <?php echo e(Request::is('posts*') ? 'active' : ''); ?>">
        <p>Posts</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('banners.index')); ?>"
       class="nav-link <?php echo e(Request::is('banners*') ? 'active' : ''); ?>">
        <p>Banners</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('categories.index')); ?>"
       class="nav-link <?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
        <p>Categories</p>
    </a>
</li>


<?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/layouts/menu.blade.php ENDPATH**/ ?>
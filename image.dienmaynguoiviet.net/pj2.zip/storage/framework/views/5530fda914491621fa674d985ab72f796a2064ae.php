<li class="nav-item">
    <a href="<?php echo e(route('metaSeos.index')); ?>"
       class="nav-link <?php echo e(Request::is('metaSeos*') ? 'active' : ''); ?>">
        <p>Meta Seos</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('menus.index')); ?>"
       class="nav-link <?php echo e(Request::is('menus*') ? 'active' : ''); ?>">
        <p>Menus</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('posts.index')); ?>"
       class="nav-link <?php echo e(Request::is('posts*') ? 'active' : ''); ?>">
        <p>Posts</p>
    </a>
</li>


<?php /**PATH C:\Users\cuong123\Desktop\blog\resources\views/layouts/menu.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="box_breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="/">Trang chủ</a></li>
            <li><a href="/blog" title="Blog kiến thức">Tin tức</a></li>
            <li><a href="<?php echo e(route('single', @$datas['link'])); ?>" title="<?php echo e(@$datas['title']); ?>"><?php echo e(@$datas['title']); ?></a></li>
          
        </ul>
    </div>
</div>
<div class="container">
    <div class="wrapper">
        <div class="row">
            <div class="col-sm-8">
                <div class="box_module">
                    <div class="box_title">
                        <h1 class="title"><a href="<?php echo e(route('single', @$datas['link'])); ?>" title="Tiết lộ bí mật ít người biết về chỉnh nha không mắc cài Invisalign"><?php echo e(@$datas['title']); ?></a></h1>
                    </div>
                    <div class="box_content">
                        <div class="layout_item_default">
                            <?php echo @$datas['content']; ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 hidden-xs">
                <div style="padding-left: 20px;">
                    <div class="box_adsRight" id="box_adsRight">
                        <a href="" title="Ảnh 1"><img src="/public/files/upload/default/images/quang-cao/ads-right.jpg" alt="Ảnh 1"></a>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div class="box_defaultCategoryHot">
    <div class="container">
        <div class="box_title">
            <h2 class="title">Kiến thức khác</h2>
        </div>
        <div class="box_content">
            <div class="row">
                <div class="col-sm-4 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/cham-soc-rang-boc-su-giup-tang-tuoi-tho-va-do-ben-dep" title="Chăm sóc răng bọc sứ giúp tăng tuổi thọ và độ bền đẹp"><img src="/public/files/upload/default/medium/images/cham-soc-rang-boc-su-1.jpg" alt="Chăm sóc răng bọc sứ giúp tăng tuổi thọ và độ bền đẹp"><span>Xem thêm</span></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/cham-soc-rang-boc-su-giup-tang-tuoi-tho-va-do-ben-dep" title="Chăm sóc răng bọc sứ giúp tăng tuổi thọ và độ bền đẹp">Chăm sóc răng bọc sứ giúp tăng tuổi thọ và độ bền đẹp</a></h3>
                            <span class="category">Chuyên mục <a href="/kien-thuc" title="Kiến thức">Kiến thức</a></span><span class="date">Ngày 30/07/2020</span>
                            <div class="desc">Chăm sóc răng bọc sứ không chỉ để vệ sinh răng miệng, loại bỏ vi khuẩn mà còn làm tăng độ bền đẹp, tuổi thọ. Chuyên gia sẽ chia sẻ ... <a href="/cham-soc-rang-boc-su-giup-tang-tuoi-tho-va-do-ben-dep">Xem thêm</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/bien-chung-sau-nho-rang-so-8-nguy-hiem-hon-ban-nghi" title="Biến chứng sau nhổ răng số 8 nguy hiểm hơn bạn nghĩ"><img src="/public/files/upload/default/medium/images/bien-chung-sau-nho-rang-so-8-1.jpg" alt="Biến chứng sau nhổ răng số 8 nguy hiểm hơn bạn nghĩ"><span>Xem thêm</span></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/bien-chung-sau-nho-rang-so-8-nguy-hiem-hon-ban-nghi" title="Biến chứng sau nhổ răng số 8 nguy hiểm hơn bạn nghĩ">Biến chứng sau nhổ răng số 8 nguy hiểm hơn bạn nghĩ</a></h3>
                            <span class="category">Chuyên mục <a href="/kien-thuc" title="Kiến thức">Kiến thức</a></span><span class="date">Ngày 29/07/2020</span>
                            <div class="desc">Biến chứng sau nhổ răng số 8 rất nguy hiểm mà có thể chính bạn là nạn nhân trong trường hợp không mong muốn đó. Hãy khoan lo lắng và ... <a href="/bien-chung-sau-nho-rang-so-8-nguy-hiem-hon-ban-nghi">Xem thêm</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/bi-ho-co-nen-boc-rang-su-bien-phap-phu-hop-de-khac-phuc-tinh-trang-nay" title="Bị hô có nên bọc răng sứ? - Biện pháp phù hợp để khắc phục tình trạng này"><img src="/public/files/upload/default/medium/images/bi-ho-co-nen-boc-rang-su-1.jpg" alt="Bị hô có nên bọc răng sứ? - Biện pháp phù hợp để khắc phục tình trạng này"><span>Xem thêm</span></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/bi-ho-co-nen-boc-rang-su-bien-phap-phu-hop-de-khac-phuc-tinh-trang-nay" title="Bị hô có nên bọc răng sứ? - Biện pháp phù hợp để khắc phục tình trạng này">Bị hô có nên bọc răng sứ? - Biện pháp phù hợp để khắc phục tình trạng này</a></h3>
                            <span class="category">Chuyên mục <a href="/kien-thuc" title="Kiến thức">Kiến thức</a></span><span class="date">Ngày 28/07/2020</span>
                            <div class="desc">Đã có biện pháp khắc phục tình trạng bị hô khiến bạn thiếu tự tin trong thời gian mà chỉ mất 3 ngày để giải quyết triệt để. Liệu phương ... <a href="/bi-ho-co-nen-boc-rang-su-bien-phap-phu-hop-de-khac-phuc-tinh-trang-nay">Xem thêm</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/chinh-nha-co-dinh-bi-quyet-cho-ham-rang-deu-dep-chuan-vi-tri%C2%A0" title="Chỉnh nha cố định - Bí quyết cho hàm răng đều đẹp chuẩn vị trí "><img src="/public/files/upload/default/medium/images/chinh-nha-co-dinh-1.jpg" alt="Chỉnh nha cố định - Bí quyết cho hàm răng đều đẹp chuẩn vị trí "><span>Xem thêm</span></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/chinh-nha-co-dinh-bi-quyet-cho-ham-rang-deu-dep-chuan-vi-tri%C2%A0" title="Chỉnh nha cố định - Bí quyết cho hàm răng đều đẹp chuẩn vị trí ">Chỉnh nha cố định - Bí quyết cho hàm răng đều đẹp chuẩn vị trí </a></h3>
                            <span class="category">Chuyên mục <a href="/kien-thuc" title="Kiến thức">Kiến thức</a></span><span class="date">Ngày 27/07/2020</span>
                            <div class="desc">Chỉnh nha cố định luôn là phương pháp truyền thống được khách hàng tin dùng vì sự hiệu quả khách hàng nhận được trên hàm răng của mình. Để hiểu ... <a href="/chinh-nha-co-dinh-bi-quyet-cho-ham-rang-deu-dep-chuan-vi-tri%C2%A0">Xem thêm</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/bo-tui-nhung-thong-tin-huu-ich-ve-chinh-nha-trong-suot" title="Bỏ túi những thông tin hữu ích về chỉnh nha trong suốt"><img src="/public/files/upload/default/medium/images/chinh-nha-trong-suot-1.jpg" alt="Bỏ túi những thông tin hữu ích về chỉnh nha trong suốt"><span>Xem thêm</span></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/bo-tui-nhung-thong-tin-huu-ich-ve-chinh-nha-trong-suot" title="Bỏ túi những thông tin hữu ích về chỉnh nha trong suốt">Bỏ túi những thông tin hữu ích về chỉnh nha trong suốt</a></h3>
                            <span class="category">Chuyên mục <a href="/kien-thuc" title="Kiến thức">Kiến thức</a></span><span class="date">Ngày 26/07/2020</span>
                            <div class="desc">Chỉnh nha trong suốt được khuyên dùng trong nhiều trường hợp và là phương pháp hiện đại, với nhiều tiện ích, được khách hàng ưa chuộng. Cùng tìm hiểu kỹ ... <a href="/bo-tui-nhung-thong-tin-huu-ich-ve-chinh-nha-trong-suot">Xem thêm</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/top-4-dieu-nhat-dinh-phai-biet-ve-boc-rang-tham-my" title="TOP 4 điều nhất định phải biết về bọc răng thẩm mỹ"><img src="/public/files/upload/default/medium/images/boc-rang-1.jpg" alt="TOP 4 điều nhất định phải biết về bọc răng thẩm mỹ"><span>Xem thêm</span></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/top-4-dieu-nhat-dinh-phai-biet-ve-boc-rang-tham-my" title="TOP 4 điều nhất định phải biết về bọc răng thẩm mỹ">TOP 4 điều nhất định phải biết về bọc răng thẩm mỹ</a></h3>
                            <span class="category">Chuyên mục <a href="/kien-thuc" title="Kiến thức">Kiến thức</a></span><span class="date">Ngày 25/07/2020</span>
                            <div class="desc">Bọc răng thẩm mỹ là phương pháp hiện đại, cho hiệu quả nhanh chóng và khắc phục hoàn toàn khuyết điểm răng. Nhưng hãy thực hiện dịch vụ này khi ... <a href="/top-4-dieu-nhat-dinh-phai-biet-ve-boc-rang-tham-my">Xem thêm</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cuong123\Desktop\New folder (2)\blog\resources\views/frontend/blogdetail.blade.php ENDPATH**/ ?>
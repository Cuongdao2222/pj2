
<li class="nav-item">
    <a href="<?php echo e(route('banners.index')); ?>"
       class="nav-link <?php echo e(Request::is('banners*') ? 'active' : ''); ?>">
        <p>Banners</p>
    </a>
</li>


<li class="nav-item" style="display: flex; height:44px;"  >

    <a href="<?php echo e(route('groupProducts.index')); ?>"
       class="nav-link <?php echo e(Request::is('groupProducts*') ? 'active' : ''); ?>" style="width: 68%;">
        <p>Group Products</p>
        
    </a>

    <?php
        $listGroup = App\Models\groupProduct::select('name','id')->get();

    ?>

    <?php if(count($listGroup)>0): ?>
     <span class="btn btn-link open" style="width: 32%;">+</span>
     <?php endif; ?> 
    
    
</li>

<ul style="width: 68%;">
    <?php if(count($listGroup)>0): ?>
    <?php $__currentLoopData = $listGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="child-nav">
        <a href="<?php echo e(route('select-category',[$value->id])); ?>"
           class="nav-link">
            <p><?php echo e($value->name); ?></p>
        </a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</ul>


<li class="nav-item">
    <a href="<?php echo e(route('makers.index')); ?>"
       class="nav-link <?php echo e(Request::is('makers*') ? 'active' : ''); ?>">
        <p>Hãng phân phối</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('products.index')); ?>"
       class="nav-link <?php echo e(Request::is('products*') ? 'active' : ''); ?>">
        <p>Products</p>
    </a>
</li>

<style type="text/css">
    
    .child-nav a{
        width: 100%;
    }
</style>

<script type="text/javascript">
    $('.child-nav').hide();

    $(".open").bind("click", function(){

        var acction = $(".open").text();

        if(acction =='+'){
            $('.child-nav').show();
            $('.open').text('-');
        }
        else{
            $('.child-nav').hide();
            $('.open').text('+');
        }
    });
    
</script>



<?php /**PATH C:\xampp\htdocs\pj2\resources\views/layouts/menu.blade.php ENDPATH**/ ?>
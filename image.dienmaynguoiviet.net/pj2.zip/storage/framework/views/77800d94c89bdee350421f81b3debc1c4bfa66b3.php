<div class="table-responsive">
    <table class="table" id="products-table">
        <thead>
        <tr>
            <th>Image</th>
        <th>Tên sản phẩm</th>
        <th>Productsku</th>
        <th>Link</th>
         <th>Nhóm sản phẩm</th>
        <th>Số lượng trong kho</th>
        <th>Sản phẩm Hot</th>
        
        
        <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>

        <?php
            //cắt chuỗi khi dài quá
            function substrwords($text, $maxchar, $end='...') {
                if (strlen($text) > $maxchar || $text == '') {
                    $words = preg_split('/\s/', $text);      
                    $output = '';
                    $i      = 0;
                    while (1) {
                        $length = strlen($output)+strlen($words[$i]);
                        if ($length > $maxchar) {
                            break;
                        } 
                        else {
                            $output .= " " . $words[$i];
                            ++$i;
                        }
                    }
                    $output .= $end;
                } 
                else {
                    $output = $text;
                }
                return $output;
            }
        
        ?>    

        <?php  
            // $products = $products->all(); 

            // $products = array_reverse($products);
         ?>
        
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><img src="/<?php echo e($product->Image); ?>" width="150px" height="150px"></td>
            <td><?php echo e($product->Name); ?></td>
            <td><?php echo e($product->ProductSku); ?></td>
            <td>/<?php echo e($product->Link); ?></td>
            <td><?php echo e($product->Group_id); ?></td>
            <td><?php echo e($product->Quantily); ?></td>

            <td><input type="checkbox" id="hot" name="hot"  onclick='handleClick(<?php echo e($product->Group_id); ?>);'></td>
            
                <td width="120">
                    <?php echo Form::open(['route' => ['products.destroy', $product->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('products.show', [$product->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('products.edit', [$product->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>

                         <a href="<?php echo e(route('images.create', [$product->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="fas fa-image"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<script type="text/javascript">

    function handleClick(id) {
        // if(id.checked){
        //     console.log(id);
        // }

        console.log(id.checked)
        
    }
    // if($("#hot").is(':checked')){
    //     let value = $("#hot").prop("checked");

    //     console.log(value);

    // } 



</script>
<?php /**PATH C:\Users\APC-LTN\Desktop\project\media\resources\views/products/table.blade.php ENDPATH**/ ?>
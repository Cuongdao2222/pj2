<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH C:\Users\APC-LTN\Desktop\project\mediass\resources\views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>
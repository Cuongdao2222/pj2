<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Image:'); ?>

    <div class="input-group">
        <div class="custom-file">
            <?php echo Form::file('image', ['class' => 'custom-file-input']); ?>

            <?php echo Form::label('image', 'Choose file', ['class' => 'custom-file-label']); ?>

        </div>
    </div>
</div>
<div class="clearfix"></div>


<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('title', 'Title:'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

</div>

<?php 
    $category =    DB::table('categories')->select('namecategory', 'id')->get();
    $new_category = [];
    if(count($category)>0){
        foreach ($category as  $value) {
           $new_category[$value->id] = $value->namecategory;
        }
    }
    
    $categoryselected = !empty($post)?$post['category']:'1';
    
?>

<div class="form-group col-sm-12">
    <?php echo Form::label('category', 'category:'); ?>

   <?php echo e(Form::select('category', $new_category, $categoryselected, ['id' => 'category', 'class' => 'form-control'])); ?>

</div>





<!-- Content Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('content', 'Content:'); ?>

    <?php echo Form::textarea('content', null, ['class' => 'form-control content-input']); ?>

</div>


<script>
    CKEDITOR.replace( 'content' );
</script>

<?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/posts/fields.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="box_breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="/">Trang chủ</a></li>
            <li><a href="/rang-su-tham-my" title="Răng sứ thẩm mỹ">Răng sứ thẩm mỹ</a></li>
        </ul>
    </div>
</div>
<div class="wrapper">
    <div class="container">
        <div class="box_module">
            <div class="box_title">
                <h1 class="title"><a href="/rang-su-tham-my" title="Răng sứ thẩm mỹ">Răng sứ thẩm mỹ</a></h1>
            </div>
            <div class="box_content">
                <div class="layout_category_product">
                    <div class="productGrid">
                        <div class="row">
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/dan-su-veneer" title="Dán sứ Veneer Emax Laminate"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/ngo-lan-huong.jpg')); ?>" alt="Dán sứ Veneer Emax Laminate"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/dan-su-veneer" title="Dán sứ Veneer Emax Laminate">Dán sứ Veneer Emax Laminate</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('155845435524m6n537cl00');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-lava-3m" title="Răng sứ Lava 3M Plus"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/quynh-kool.jpg')); ?>" alt="Răng sứ Lava 3M Plus"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-lava-3m" title="Răng sứ Lava 3M Plus">Răng sứ Lava 3M Plus</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('157512952808ka709z8t02');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-orodent" title="Răng sứ Orodent"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/bui-bich-uyen.jpg')); ?>" alt="Răng sứ Orodent"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-orodent" title="Răng sứ Orodent">Răng sứ Orodent</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1634183110d0908l255qb9');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-biodiamond" title="Răng sứ Bio Diamond"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/hoang-phi-huyen.jpg')); ?>" alt="Răng sứ Bio Diamond"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-biodiamond" title="Răng sứ Bio Diamond">Răng sứ Bio Diamond</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('15751293923517581568iv');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-nacera" title="Răng sứ Nacera"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-tat-kiem.jpg')); ?>" alt="Răng sứ Nacera"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-nacera" title="Răng sứ Nacera">Răng sứ Nacera</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1634183868985c08i0x0w5');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-nacera-q3" title="Răng sứ Nacera Q3"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/tran-quang-minh.jpg')); ?>" alt="Răng sứ Nacera Q3"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-nacera-q3" title="Răng sứ Nacera Q3">Răng sứ Nacera Q3</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('16341839525872u2465cz0');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-ceramill" title="Răng sứ Ceramill"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-quyen.jpg')); ?>" alt="Răng sứ Ceramill"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-ceramill" title="Răng sứ Ceramill">Răng sứ Ceramill</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1575129354233875b1t9ks');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/dan-su-veneer-lisi" title="Dán sứ Veneer Lisi"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-kieu-my.jpg')); ?>" alt="Dán sứ Veneer Lisi"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/dan-su-veneer-lisi" title="Dán sứ Veneer Lisi">Dán sứ Veneer Lisi</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('16341807446g1k3460841b');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-venus" title="Răng sứ Venus"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/lan-phuong.jpg')); ?>" alt="Răng sứ Venus"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-venus" title="Răng sứ Venus">Răng sứ Venus</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1575129319nhzy3ir852g8');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-ht-smile" title="Răng sứ HT Smile"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/thuong-cin.jpg')); ?>" alt="Răng sứ HT Smile"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-ht-smile" title="Răng sứ HT Smile">Răng sứ HT Smile</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('157512946012g623l19459');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-katana" title="Răng sứ Katana"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/hai-van.jpg')); ?>" alt="Răng sứ Katana"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-katana" title="Răng sứ Katana">Răng sứ Katana</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1634184004p424966o0w21');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-emax" title="Răng sứ Emax"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/san-pham/Rang-su-Emax.jpg')); ?>" alt="Răng sứ Emax"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-emax" title="Răng sứ Emax">Răng sứ Emax</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1575129423me0897790jy3');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-lava-3m-esthetic" title="Rắng sứ Lava 3m Esthetic"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/CA-SI-LAN-HUONG.jpg')); ?>" alt="Rắng sứ Lava 3m Esthetic"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-lava-3m-esthetic" title="Rắng sứ Lava 3m Esthetic">Rắng sứ Lava 3m Esthetic</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1575129558s965e3r04175');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/rang-su-siladent" title="Răng sứ Siladent"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/san-pham/rang-su-Siladent.jpg')); ?>" alt="Răng sứ Siladent"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/rang-su-siladent" title="Răng sứ Siladent">Răng sứ Siladent</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1575129587h0v20147q7g3');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="item">
                                    <div class="image">
                                        <a href="/dan-su-suon-ziconia" title="Dán sứ sườn Ziconia"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/san-pham/Dan-suon-su-Ziconia.jpg')); ?>" alt="Dán sứ sườn Ziconia"></a>
                                    </div>
                                    <div class="info">
                                        <h3 class="title"><a href="/dan-su-suon-ziconia" title="Dán sứ sườn Ziconia">Dán sứ sườn Ziconia</a></h3>
                                        <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                    </div>
                                    <div class="control">
                                        <a href="javascript:;" onclick="javascript:addCart('1575129266810072348735');" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="box_pagination">
                            <a href="javascript:;" class="active">1</a> <a href="/rang-su-tham-my/page/2">2</a> <a href="/rang-su-tham-my/page/2" class="next">Next</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="box_feedbackCategoryHome">
    <div class="container">
        <div class="box_title">
            <h2 class="title"><a href="/cam-nhan-khach-hang" title="Khách hàng nói gì về D'media?">Khách hàng nói gì về D'media?</a></h2>
            <a href="/cam-nhan-khach-hang" class="view_all">Xem tất cả</a>
        </div>
        <div class="box_desc"></div>
        <div class="box_content">
            <div class="slide">
                <div class="item">
                    <div class="item_content">Làm xong cũng chẳng đau gì chỉ thấy đẹp thôi, mình tự tin hát và trước ống kính lắm rồi.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/thuong-cin" title="THƯƠNG CIN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/thuong-cin-2.png')); ?>" alt="THƯƠNG CIN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/thuong-cin" title="THƯƠNG CIN">THƯƠNG CIN</a></h3>
                            <div class="desc">Diễn viên <span></span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Răng của Huyền trước đây khá đều, tuy nhiên lại không được trắng sáng. Dù không tự ti nhưng là 1 Boss của hệ thống hơn 1000 người thì hình ảnh nụ cười rạng rỡ chính là yếu tố khiến Huyền luôn được yêu mến và tin tưởng.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/hoang-phi-huyen.png')); ?>" alt="HOÀNG PHI HUYỀN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN">HOÀNG PHI HUYỀN</a></h3>
                            <div class="desc">Boss <span>Huyền Phi Comestic</span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Hiện tại Nụ cười rạng rỡ mà Win Smile mang lại cho tôi đó chính là niềm tin yêu của học viên và sự quý trọng của đối tác. Cám ơn Win Smile luôn đồng hành cùng tôi trên con đường thành công.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-tat-kiem.png')); ?>" alt="NGUYỄN TẤT KIỂM"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM">NGUYỄN TẤT KIỂM</a></h3>
                            <div class="desc">CEO <span>TAKA ACADEMY</span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Bây giờ mình luôn tự tin , thoải mái mỗi khi cười và nhận được rất nhiều lời khen từ bạn bè và đối tác.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/nguyen-quyen" title="NGUYỄN QUYÊN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-quyen.png')); ?>" alt="NGUYỄN QUYÊN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/nguyen-quyen" title="NGUYỄN QUYÊN">NGUYỄN QUYÊN</a></h3>
                            <div class="desc">Boss <span>Mỹ phẩm Herrin Care</span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Răng của Giang trước đây gặp rất nhiều vấn đề, răng khấp khểnh, cười hở lợi và không được trắng sáng. </div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-tra-giang3.png')); ?>" alt="NGUYỄN TRÀ GIANG"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG">NGUYỄN TRÀ GIANG</a></h3>
                            <div class="desc">Boss <span>Mint beauty</span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content"> Ai cũng khen răng mình đẹp, đi làm gặp nhiều anh chị nghệ sĩ đã làm răng rồi mà mọi người vẫn hỏi mình làm răng ở đâu, Mình cảm ơn Win Smile rất nhiều.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/pong-chuan" title="PÔNG CHUẨN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/pong-chuan.png')); ?>" alt="PÔNG CHUẨN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/pong-chuan" title="PÔNG CHUẨN">PÔNG CHUẨN</a></h3>
                            <div class="desc">Style list <span></span></div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="item_content">Một người khó tính và sợ đau như Tùng mà sau khi bọc răng sứ tại Win Smile còn cảm thấy hài lòng thì Tùng nghĩ dịch vụ tại Win Smile rất đáng để trải nghiệm.</div>
                    <div class="item_info">
                        <div class="image">
                            <a href="/tung-min" title="TÙNG MIN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/tung-min.png')); ?>" alt="TÙNG MIN"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/tung-min" title="TÙNG MIN">TÙNG MIN</a></h3>
                            <div class="desc">Diễn viên <span></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\New folder (5)\demo1.dthdental.vn\resources\views/frontend/rangsuthammy.blade.php ENDPATH**/ ?>